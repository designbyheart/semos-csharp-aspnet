﻿using System;

namespace AttributeConstructor {
  class MySpecialAttribute : Attribute {
    private string Data;
    public MySpecialAttribute(string data) {
      Data = data;
    }
    public MySpecialAttribute():this("") {
    }
  }

  [MySpecial("MyData")]
  class MyClass1 {

  }

  [MySpecial]
  class MyClass2 {

  }

  class Program {
    static void Main(string[] args) {
    }
  }
}

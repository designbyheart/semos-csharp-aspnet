﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
/*
 Attributes act as metadata. Without some outward force, 
   they won't actually do anything.
*/
namespace UseAttributes {
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
  class MySpecialAttribute : Attribute {
  }

  [AttributeUsage(AttributeTargets.Class)]
  class MyAnotherSpecialAttribute : Attribute {
  }


  [MySpecial]
  [MyAnotherSpecial]
  [Obsolete]
  class MyClass {

  }

  [MySpecial]
  struct MyStruct {

  }
  class Program {
    static void Main(string[] args) {
      TypeInfo typeInfo = typeof(MyClass).GetTypeInfo();
      Console.WriteLine("The assembly qualified name of MyClass is " + typeInfo.AssemblyQualifiedName);

      var attrs = typeInfo.GetCustomAttributes();
      foreach (var attr in attrs)
        Console.WriteLine("Attribute on MyClass: " + attr.GetType().Name);

      Console.ReadKey();
    }
  }
}

﻿using System;

namespace CustomAttribute {
  class MySpecialAttribute : Attribute {

  }

  [MySpecialAttribute]
  class MyClass1 {

  }

  [MySpecial]
  class MyClass2 {

  }

  class Program {
    static void Main(string[] args) {
    }
  }
}

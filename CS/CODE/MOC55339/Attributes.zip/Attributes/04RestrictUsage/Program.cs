﻿using System;
/*
  Attributes can be used on a number of "targets":
  - Assembly
  - Class
  - Constructor
  - Delegate
  - Enum
  - Event
  - Field
  - GenericParameter
  - Interface
  - Method
  - Module
  - Parameter
  - Property
  - ReturnValue
  - Struct
 */
namespace RestrictUsage {
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
  class MySpecialAttribute : Attribute {
  }

  [MySpecial]
  class MyClass {

  }

  [MySpecial]
  struct MyStruct {

  }

  class Program {
    static void Main(string[] args) {
    }
  }
}

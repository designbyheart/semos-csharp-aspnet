﻿using System;

namespace Intro {

  [Obsolete]
  class OldClass1 {

  }

  [Obsolete("This class will no longer supported in near future")]
  class OldClass2 {

  }

  class Program {
    static void Main(string[] args) {
    }
  }
}

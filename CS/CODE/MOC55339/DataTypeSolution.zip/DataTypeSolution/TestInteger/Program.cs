﻿using System;

namespace TestInteger {
  class Program {
    static void Main(string[] args) {

      ushort n = 65535; // -128..127

      int x = 22, y = 7;
      double d = x / y;

      Console.WriteLine("{0:f2}", d);
      Console.ReadKey();
    }
  }
}

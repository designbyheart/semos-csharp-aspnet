﻿using System;

namespace NullableType {
  class Program {
    static void Main(string[] args) {
      float? examResult=null;
      //float result = examResult.HasValue ? examResult.Value : 0.0F;
      float result = examResult??0.0F;
      Console.ReadKey();
    }
  }
}

﻿using System;

namespace Bank {
  internal class Program {
    static void MainLoan(string[] args) {
      double LoanAmount = 1_000_000.0;
      float AnnualRate = 0.046F;
      int DurationInYears = 30;
      //Financial f = new Financial();
      double MonthlyInstallment = Financial.Pmt(LoanAmount,AnnualRate/12,DurationInYears*12);

      Console.WriteLine("Monthly Installment:{0:c}", MonthlyInstallment);
      Console.WriteLine("Min. Net Income:{0:c}", 3 * MonthlyInstallment);
      Console.WriteLine("Total Payment:{0:c}", MonthlyInstallment*DurationInYears*12);
      Console.ReadKey();
    }
    static void MainFV(string[] args) {
      double Saving = 100.0;
      float AnnualRate = 0.05F;
      //Financial f = new Financial();

      Console.WriteLine("  Year     FV");
      for (int year = 0; year <= 10; year++) {
        Console.WriteLine("{0,8} {1:c}", year, Financial.FV(Saving, AnnualRate, year));
      }
      Console.ReadKey();
    }
    static void Main(string[] args) {
Console.WriteLine("---0");
      Console.WriteLine("The interest rate is {0:f2}%",Account.InterestRate*100);
Console.WriteLine("---1");
      Account acc1 = new Account(2000);
Console.WriteLine("---2");
      Account acc2 = new Account();
Console.WriteLine("---3");
      acc1.Withdraw(200);
      acc2.Deposit(100);
      //Account.InterestRate = 0.1F;
      
      acc1.Update();
      acc2.Update();
      Console.WriteLine(acc1);
      Console.WriteLine(acc2);
      Console.ReadKey();
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank {
  internal static class Financial {//Utility Class
    //private Financial() { }
    static public double FV(double pv, double r, int n) { 
      return pv * Math.Pow(1+r, n);
    }
    static public double Pmt(double p, double r, int n) {
      double subExp = Math.Pow(1+r, n);
      return p * (r * subExp)/(subExp - 1);
    }
  }
}

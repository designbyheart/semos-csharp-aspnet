﻿using System;

namespace Univeristy {
  class Student {
    public readonly string Name;
    public float CGPA;
    public Student(string name, float cgpa) {
      Name = name;
      CGPA = cgpa;
    }
  }
}

﻿using System;
using BayanLepas;

namespace Ipoh {
    //Earth.Asia.SEA.Malaysia.Penang.BayanLepas.House
    class AuntHouse:House {
        void Auntie() {
        }
    }
}

﻿using System;
using HomeTown=BayanLepas;

namespace Ipoh {
    class JohnHouse {
        void John() {
            HomeTown.House h = new HomeTown.House();
        }
    }
}

﻿using System;

namespace Ipoh {
    class House {
        public int SpartCar;
    }
}

﻿using System;

namespace BayanLepas {
    class UncleHouse:House {
        void Uncle() {
        }
    }
}

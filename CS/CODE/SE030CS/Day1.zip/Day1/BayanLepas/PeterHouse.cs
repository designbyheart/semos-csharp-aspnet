﻿using System;

namespace BayanLepas {
    public class PeterHouse {
        void Peter() {
            House h = new House();
        }
    }
}

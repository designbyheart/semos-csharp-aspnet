﻿using System;

namespace BayanLepas {
    public class House {
        //Bedroom
        private int Bed;
        private void Sister() { }

        //Dinning Room
        protected int Table;
        protected void Mother() { }

        //Garden
        public int Flower;
        public void Father() { }

        //Backyard
        internal int Bonsai;
        internal void Brother() { }

        //Home Theatre
        protected internal int OLED100InchTV;
        internal protected int BlurayPlayer;
    }
}

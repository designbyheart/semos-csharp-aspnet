﻿using System;

namespace University {
    interface ISortable {
        bool Swap(object obj, object sortCriteria);
    }
}

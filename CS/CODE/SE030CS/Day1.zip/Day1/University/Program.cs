﻿using System;

namespace University {
    class AgeException:Exception {
        public AgeException(string msg) : base(msg) { }
    }
    class AgeTooLowException:AgeException {
        public AgeTooLowException(string msg) : base(msg) { }
    }
    class AgeTooHighException : AgeException {
        public AgeTooHighException(string msg) : base(msg) { }
    }


    class Person {
        public readonly string Name;

        //public void ChangeName(string newName) {
        //    Name = newName;
        //}

        private int _Age;
        virtual public int Age {
            get {
                return _Age;
            }
            set {
                if (value < 1) throw new AgeTooLowException("Age must be>0!");
                if (value > 128) throw new AgeTooHighException("Is this human?!");
                _Age = value;
            }
        }
        public Person(string name) {
            Name = name;
        }
    }
    class Student:Person, ISortable {
        public float CGPA;
        public Student(string name, float cgpa) : base(name) {
            CGPA = cgpa;
            //Another 100 lines of common initialization
        }
        public Student() : this("", 0.0F) { }


        public enum SortCriteria { 
            ByName, ByNameDesc,
            ByCGPA, ByCGPADesc
        }
        public bool Swap(object obj, object sortCriteria) {
            Student lhs = this;
            Student rhs = obj as Student;
            switch ((SortCriteria)sortCriteria) {
                case SortCriteria.ByName:
                    return lhs.Name.CompareTo(rhs.Name) > 0;
                case SortCriteria.ByNameDesc:
                    return lhs.Name.CompareTo(rhs.Name) < 0;
                case SortCriteria.ByCGPA:
                    return lhs.CGPA > rhs.CGPA;
                case SortCriteria.ByCGPADesc:
                    return lhs.CGPA < rhs.CGPA;
            }
            throw new NotImplementedException("Missed case:" + sortCriteria);
        }
    }
    abstract class Staff:Person,ISortable {
        public double Salary;
        protected double EPF_CONTRIBUTION = 0.11;
        public Staff(string name, double salary):base(name) {
            Salary = salary;
        }

        abstract public double MonthlySalary { get; }  // Operation (WHAT) 

        override public int Age {
            set {
                if (value < 16) throw new AgeTooLowException("Too young to be Staff!");
                if (value > 60) throw new AgeTooHighException(
                    "Give chance to the young one-lah!");
                base.Age = value;
            }
        }

        public enum SortCriteria {
            ByName,ByNameDesc,
            ByMonthlySalary,ByMonthlySalaryDesc,
        }
        public bool Swap(object obj, object sortCriteria) {
            Staff lhs = this;
            Staff rhs = obj as Staff;
            switch ((SortCriteria)sortCriteria) {
                case SortCriteria.ByName:
                    return lhs.Name.CompareTo(rhs.Name) > 0;
                case SortCriteria.ByNameDesc:
                    return lhs.Name.CompareTo(rhs.Name) < 0;
                case SortCriteria.ByMonthlySalary:
                    return lhs.MonthlySalary > rhs.MonthlySalary;
                case SortCriteria.ByMonthlySalaryDesc:
                    return lhs.MonthlySalary < rhs.MonthlySalary;
            }
            throw new NotImplementedException("Missed case:" + sortCriteria);
        }
    }
    class Lecturer:Staff {
        public float Allowance;
        public Lecturer(string name, double salary, float allowance):
            base(name, salary) {
            Allowance = allowance;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + Allowance; // Method (HOW)
            }
        }
    }
    class Clerk:Staff {
        public float OTRate;
        public ushort OTHours;
        public Clerk(string name, double salary, float otRate):
            base(name, salary){
            OTRate = otRate;
            OTHours = 0;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + (OTHours * OTRate); // Method (HOW)
            }
        }
    }

    class Manager : Staff {
        public float CarAllowance;
        public Manager(string name, double salary, float carAllowance):
            base(name, salary) {
            CarAllowance = carAllowance;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + CarAllowance; // Method (HOW)
            }
        }
    }

    class HRManager: Manager {
        public HRManager(string name, double salary) :
            base(name, salary, 500) { }
    }

    class SalesManager: Manager {
        public float PetrolAllowance;
        public double MonthlySales;
        public SalesManager(string name, double salary, float carAllowance,
            float petrolAllowance):base(name, salary, carAllowance) {
            PetrolAllowance = petrolAllowance;
            MonthlySales = 0.0;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * (0.6 * Salary) +
                    (0.1 * MonthlySales) + CarAllowance + PetrolAllowance; // Method (HOW)
            }
        }
    }

    class Program {
        static void ShowAllStaffInfo(Staff[] allStaff) {
            foreach (Staff staff in allStaff)
                Console.WriteLine("Name:{0,-20} Monthly Salary:{1:c}",
                    staff.Name,staff.MonthlySalary);
            Console.WriteLine();
        }
        static void ShowAllStudentsInfo(Student[] students) {
            foreach (Student student in students)
                Console.WriteLine("Name:{0,-20} CGPA:{1:f2}",
                    student.Name, student.CGPA);
            Console.WriteLine();
        }
        static void Sort(ISortable[] items, object sortCriteria) {
            int n = items.Length;
            for(int x = 0; x < (n - 1); x++) {
                for (int y = 0; y < (n - 1 - x); y++) {
                    if (items[y].Swap(items[y + 1], sortCriteria)) {
                        ISortable item = items[y];
                        items[y] = items[y + 1];
                        items[y + 1] = item;
                    }
                }
            }
        }

        static void Main(string[] args) {
            Student[] students = {
                new Student("Steven", 3.1F),
                new Student("Peter", 2.7F),
                new Student("Afendi", 1.8F),
                new Student("Mary", 3.4F),
                new Student("Panda", 3.2F),
            };
            ShowAllStudentsInfo(students);

            Sort(students, Student.SortCriteria.ByName);
            ShowAllStudentsInfo(students);

            Sort(students, Student.SortCriteria.ByNameDesc);
            ShowAllStudentsInfo(students);

            Sort(students, Student.SortCriteria.ByCGPA);
            ShowAllStudentsInfo(students);

            Sort(students, Student.SortCriteria.ByCGPADesc);
            ShowAllStudentsInfo(students);
            Console.ReadKey();
        }

        static void Main4(string[] args) {
            Staff[] staff2022 = new Staff[] {
                new Lecturer("Afendi", 3500, 550),
                new Clerk("Abu Bakar", 2000, 15),
                new Manager("Ahmad", 5000, 550),
                new HRManager("Abu", 4500),
                new SalesManager("Ali", 4000, 600, 800),
            };
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, Staff.SortCriteria.ByMonthlySalary);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, Staff.SortCriteria.ByMonthlySalaryDesc);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, Staff.SortCriteria.ByName);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, Staff.SortCriteria.ByNameDesc);
            ShowAllStaffInfo(staff2022);
            Console.ReadKey();
        }

        static void Main3(string[] args) {
            Lecturer lec = new Lecturer("Yong Tau Foo", 3500, 550);

            //lec.Name = "Alibaba";

            while (true) {
                Console.Write("Age?>>");
                try {
                    int age = int.Parse(Console.ReadLine());
                    lec.Age = age;
                    break;
                } catch (AgeTooLowException ex) {
                    Console.WriteLine("AgeTooLowException:" + ex.Message);
                } catch (AgeException ex) {
                    Console.WriteLine("AgeException:" + ex.Message);
                } catch (FormatException ex) {
                    Console.WriteLine("FormatException:" + ex.Message);
                } catch (OverflowException ex) {
                    Console.WriteLine("OverflowException:" + ex.Message);
                } catch (Exception ex) {
                    Console.WriteLine("Exception:" + ex.Message);
                }
                Console.WriteLine("Try again....");
            }
            Console.WriteLine("{0}'s age is {1}", lec.Name, lec.Age);
            Console.ReadKey();
        }



        //Refactor to Method
        static void ShowManagerInfo(Manager m) {
            Console.WriteLine("Name:{0,-20} Monthly Salary:{1:c}",
                    m.Name, m.MonthlySalary);
        }

        static void Main2(string[] args) {
            Manager m = new Manager("Ahmad", 5000, 600);
            HRManager hrm = new HRManager("Abu", 5000);
            SalesManager sm = new SalesManager("Ali", 5000, 400, 800);

            ShowManagerInfo(m);

            ShowManagerInfo(hrm);

            sm.MonthlySales = 100_000.00;

            m = sm;

            m = hrm;
            /*
            //Approach-#1
            try {
                SalesManager sm2 = (SalesManager)m; //Unsafe Casting
                Console.WriteLine("The Monthly Sales for {0} is {1:c}",
                    sm2.Name,sm2.MonthlySales);
            } catch (Exception) {
                Console.WriteLine("Not Sales Manager-lah!");
            }
            */

            /*
            //Approach-#2 (Not thread safe!)
            if (m is SalesManager) {
                SalesManager sm2 = (SalesManager)m; //Unsafe Casting
                Console.WriteLine("The Monthly Sales for {0} is {1:c}",
                    sm2.Name, sm2.MonthlySales);
            } else {
                Console.WriteLine("Not Sales Manager-lah!");
            }
            */
            //Approach-#3
            SalesManager sm2 = m as SalesManager;
            if (sm2 != null) { 
                Console.WriteLine("The Monthly Sales for {0} is {1:c}",
                    sm2.Name, sm2.MonthlySales);
            } else {
                Console.WriteLine("Not Sales Manager-lah!");
            }


            //ShowManagerInfo(sm);

            Console.ReadKey();
        }
    }
}

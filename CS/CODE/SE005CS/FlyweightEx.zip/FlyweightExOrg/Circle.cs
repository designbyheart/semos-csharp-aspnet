﻿using System;
using System.Drawing;

namespace FlyweightExOrg {
  class Circle : Shape {
    int cx, cy;
    int radius;
    Color color;
    public Circle(int x,int y, int r, Color color) {
      cx = x;
      cy = y;
      radius = r;
      this.color = color;
    }
    public override void Show(Graphics g) {
      Rectangle r = new Rectangle(cx - radius, cy - radius, 2 * radius, 2 * radius);
      g.DrawEllipse(new Pen(color), r);
    }
  }
}

﻿using System;
using System.Drawing;

namespace FlyweightExOrg {
  abstract class Shape {
    abstract public void Show(Graphics g);
  }
}

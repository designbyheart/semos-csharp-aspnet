﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlyweightExOrg {
  public partial class Form1 : Form {
    List<Shape> shapes = new List<Shape>();
    public Form1() {
      InitializeComponent();
      for(int i=0; i<12; i++) {
        shapes.Add(new Circle(50 * i + 40, 20, 20, Color.Red));
      }
      for (int i = 0; i < 8; i++) {
        shapes.Add(new Circle(50 * i + 40, 70, 20, Color.Magenta));
      }
      for (int i = 0; i < 15; i++) {
        shapes.Add(new Rect(i*30+10,150,20,15,Color.Blue));
      }
    }

    private void Form1_Load(object sender, EventArgs e) {

    }

    private void Form1_Paint(object sender, PaintEventArgs e) {
      foreach(Shape s in shapes) {
        s.Show(e.Graphics);
      }
    }
  }
}

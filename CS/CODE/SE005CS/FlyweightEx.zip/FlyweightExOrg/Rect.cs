﻿using System;
using System.Drawing;

namespace FlyweightExOrg {
  class Rect : Shape {
    int x, y;
    int w, h;
    Color color;
    public Rect(int x, int y, int w, int h, Color color) {
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
      this.color = color;
    }
    public override void Show(Graphics g) {
      g.DrawRectangle(new Pen(color), new Rectangle(x, y, w, h));
    }
  }
}

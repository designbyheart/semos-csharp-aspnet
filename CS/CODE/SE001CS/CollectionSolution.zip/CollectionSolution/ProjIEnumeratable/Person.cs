﻿using System;

namespace ProjIEnumeratable {
  public class Person {
    public Person(string fName, string lName) {
      this.firstName = fName;
      this.lastName = lName;
    }

    public string firstName;
    public string lastName;
  }
}
﻿//Abstract class and Abstract Method
//Key concepts:
//  1) Abstract class
//  2) Absract Method
//  3) Constant
//  4) 
using System;

namespace OOP5 {
  class Person : Object {
    public string Name;
    public Person(string name) {
      if (name.Length > 50) throw new Exception("Name too long!");
      Name = name;
    }
  }
  class Student : Person {
    public float CGPA;
    public Student(string name, float cgpa) : base(name) {
      CGPA = cgpa;
      /*
       * Another 100 lines of common initialization logic
       */
    }
    public Student() : this("", 0.0F) {
    }
  }
  abstract class Staff : Person {
    public const double EPF_CONTRIBUTION = 0.13;
    public double Salary;
    public Staff(string name, double salary) : base(name) {
      if (salary < 1500) throw new Exception("Salary too low!");
      Salary = salary;
    }
    abstract public double getMonthlySalary(); //Operation (WHAT)
  }
  class Lecturer : Staff {
    public float Allowance;
    public Lecturer(string name, double salary, float allowance) : base(name, salary) {
      Allowance = allowance;
    }
    override public double getMonthlySalary() //Operation (WHAT)
    {
      return (1.0 - EPF_CONTRIBUTION) * Salary + Allowance; //Method (HOW)
    }
  }

  class Clerk : Staff {
    public float OTRate;
    public ushort OTHours;
    public Clerk(string name, double salary, float oTRate, ushort oTHours = 0) : base(name, salary) {
      OTRate = oTRate;
      OTHours = oTHours;
    }
    override public double getMonthlySalary() //Operation (WHAT)
    {
      return (1.0 - EPF_CONTRIBUTION) * Salary + (OTHours * OTRate); //Method (HOW)
    }
  }

  class Manager : Staff {
    public float CarAllowance;
    public Manager(string name, double salary, float carAllowance) : base(name, salary) {
      CarAllowance = carAllowance;
    }
    override public double getMonthlySalary()  //Operation (WHAT) 
    {
      return (1.0 - EPF_CONTRIBUTION) * Salary + CarAllowance;  //Method (HOW)
    }
  }

  class HRManager : Manager {
    public HRManager(string name, double salary) : base(name, salary, 500) { }
  }

  class SalesManager : Manager {
    public float PetrolAllowance;
    public double MonthlySales;
    public SalesManager(string name, double salary, float carAllowance,
      float petrolAllowance, double monthlySales = 0.0) : base(name, salary, carAllowance) {
      PetrolAllowance = petrolAllowance;
      MonthlySales = monthlySales;
    }

    override public double getMonthlySalary()  //Operation (WHAT) 
    {
      return (1.0 - EPF_CONTRIBUTION) * (0.6 * Salary) + CarAllowance +
        PetrolAllowance + (0.1 * MonthlySales);  //Method (HOW)
    }
  }


  internal class Program {
    static void ShowManagerInfo(Manager m) {
      Console.WriteLine("Name:{0,-12} Monthly Salary:{1:c}",
          m.Name, m.getMonthlySalary());
    }
    static void Main(string[] args) {
      //Staff staff = new Staff("Alibaba", 5000);

      Console.ReadKey();
    }
  }
}

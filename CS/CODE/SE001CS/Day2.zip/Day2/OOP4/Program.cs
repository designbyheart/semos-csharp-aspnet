﻿//Specialization
//Key concepts:
//  1) Polymorphism
//  2) Late Binding
//  3) Superclass reference refer to subclass instance
//  4) is and as operators
using System;

namespace OOP4 {
  class Person : Object {
    public string Name;
    public Person(string name) {
      if (name.Length > 50) throw new Exception("Name too long!");
      Name = name;
    }
  }
  class Student : Person {
    public float CGPA;
    public Student(string name, float cgpa) : base(name) {
      CGPA = cgpa;
      /*
       * Another 100 lines of common initialization logic
       */
    }
    public Student() : this("", 0.0F) {
    }
  }
  class Staff : Person {
    public double Salary;
    public Staff(string name, double salary) : base(name) {
      if (salary < 1500) throw new Exception("Salary too low!");
      Salary = salary;
    }
  }
  class Lecturer : Staff {
    public float Allowance;
    public Lecturer(string name, double salary, float allowance) : base(name, salary) {
      Allowance = allowance;
    }
  }

  class Clerk : Staff {
    public float OTRate;
    public ushort OTHours;
    public Clerk(string name, double salary, float oTRate, ushort oTHours = 0) : base(name, salary) {
      OTRate = oTRate;
      OTHours = oTHours;
    }
  }

  class Manager: Staff {
    public float CarAllowance;
    public Manager(string name, double salary, float carAllowance):base(name, salary) {
      CarAllowance = carAllowance;
    }
    virtual public double getMonthlySalary()  //Operation (WHAT) 
    {
      return (1.0 - 0.11) * Salary + CarAllowance;  //Method (HOW)
    }
  }

  class HRManager : Manager {
    public HRManager(string name, double salary) : base(name, salary, 500) { }
  }

  class SalesManager : Manager {
    public float PetrolAllowance;
    public double MonthlySales;
    public SalesManager(string name, double salary, float carAllowance,
      float petrolAllowance, double monthlySales=0.0):base(name, salary, carAllowance) {
      PetrolAllowance = petrolAllowance;
      MonthlySales = monthlySales;
    }

    override public double getMonthlySalary()  //Operation (WHAT) 
    {
      return (1.0 - 0.11) * (0.6 * Salary) + CarAllowance +
        PetrolAllowance + (0.1 * MonthlySales);  //Method (HOW)
    }
  }


  internal class Program {
    static void ShowManagerInfo(Manager m) {
      Console.WriteLine("Name:{0,-12} Monthly Salary:{1:c}",
          m.Name, m.getMonthlySalary());
    }
    static void Main(string[] args) {
      Manager m = new Manager("Ahmad", 5000, 650);
      HRManager hrm = new HRManager("Abu", 5000);
      SalesManager sm = new SalesManager("Ali", 5000, 550, 800, 100_000);

      ShowManagerInfo(m);

      ShowManagerInfo(hrm);

      ShowManagerInfo(sm);

      m = sm;
      //m = hrm;

      //if (m is SalesManager) {
      //  SalesManager sm2 = (SalesManager)m;
      //  ShowManagerInfo(sm2);
      //} else Console.WriteLine("Not Sales Manager-lah!");

      SalesManager sm2 = m as SalesManager;
      if (sm2 != null) { 
        ShowManagerInfo(sm2);
      } else Console.WriteLine("Not Sales Manager-lah!");

      Console.ReadKey();
    }
  }
}

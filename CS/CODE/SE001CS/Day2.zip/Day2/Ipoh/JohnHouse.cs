﻿using System;
using Hometown=BayanLepas;

namespace Ipoh {
  internal class JohnHouse {
    void John() {
      Hometown.House h = new Hometown.House();
      
    }
  }
}

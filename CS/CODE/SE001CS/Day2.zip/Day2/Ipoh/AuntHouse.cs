﻿using System;
using BayanLepas;

namespace Ipoh {
  internal class AuntHouse:House {
    void Auntie() {
     
    }
  }
}

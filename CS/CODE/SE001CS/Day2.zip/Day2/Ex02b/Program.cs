﻿using System;

namespace Ex02b {
  class Circle {
    private double r;
    public Circle(double radius) {
      Radius = radius;
    }

    public double Radius {
      get { return r; }
      set {
        if (value < 0) throw new Exception("Radius must be +ve!");
        r = value;
      }
    }
    public double Area {
      get { 
        return Math.PI * r * r;
      }
    }
    public double Circumference {
      get {
        return 2 * Math.PI * r;
      }
    }
  }
  internal class Program {
    static void Main(string[] args) {
      Console.Write("Radius?>>");
      Circle c = new Circle(double.Parse(Console.ReadLine()));
      //c.Radius = -10;  //This will cause Exception
      Console.WriteLine("Radius:{0:f4}", c.Radius);
      Console.WriteLine("Area:{0:f4}", c.Area);
      Console.WriteLine("Circumference:{0:f4}", c.Circumference);
      Console.ReadKey();
    }
  }
}

﻿//Initial Model
using System;

namespace OOP1 {
  class Student {
    public string Name;
    public float CGPA;
  }

  class Lecturer {
    public string Name;
    public double Salary;
    public float  Allowance;
  }

  class Clerk {
    public string Name;
    public double Salary;
    public float  OTRate;
    public ushort OTHours;
  }

  internal class Program {
    static void Main(string[] args) {
      Student s1 = new Student(); //Instantiation
      s1.Name = "Yong Tau Foo";
      s1.CGPA = 3.15F;

      Student s2 = s1;

      Lecturer lec = new Lecturer();
      lec.Name = "Tong Sam Pah";
      lec.Salary = 4500;
      lec.Allowance = 880;

    }
  }
}

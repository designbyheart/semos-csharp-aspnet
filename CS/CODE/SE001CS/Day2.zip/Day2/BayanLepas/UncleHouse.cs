﻿using System;

namespace BayanLepas {
  public class UncleHouse: House {
    private void Uncle() {
    }
  }
}

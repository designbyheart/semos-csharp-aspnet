﻿using System;

namespace BayanLepas {
  internal class PeterHouse {
    void Peter() {
      House h = new House();      
    }
  }
}

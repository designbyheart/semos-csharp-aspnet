﻿using System;

namespace BayanLepas {
  public class House {
    //Bed room
    private int Bed;
    private void Sister() { }

    //Dinning room
    protected int Table;
    protected void Mother() { }

    //Garden
    public int Flower;
    public void Father() { }

    //Backyard
    internal int Bonsai;
    internal void Brother() { }

    //Home Threatre
    protected internal int OLEDTV100Inch;
    internal protected int BlurayPayer;
  }
}

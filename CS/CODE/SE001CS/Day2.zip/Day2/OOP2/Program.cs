﻿//Custom Constructor
using System;

namespace OOP2 {
  class Student {
    public string Name;
    public float CGPA;
    public Student(string name, float cgpa) {
      Name = name;
      CGPA = cgpa;
    }
    public Student() {
      Name = "";
      CGPA = 0.0F;
    }
  }

  class Lecturer {
    public string Name;
    public double Salary;
    public float  Allowance;
    public Lecturer(string name, double salary, float allowance) {
      Name = name;
      Salary = salary;
      Allowance = allowance;
    }
  }

  class Clerk {
    public string Name;
    public double Salary;
    public float  OTRate;
    public ushort OTHours;
    public Clerk(string name, double salary, float oTRate, ushort oTHours=0) {
      Name = name;
      Salary = salary;
      OTRate = oTRate;
      OTHours = oTHours;
    }
  }

  internal class Program {
    static void Main(string[] args) {
      Student s1 = new Student("Yong Tau Foo",3.15F); //Instantiation
      Student s3 = new Student();

      Lecturer lec = new Lecturer("Tong Sam Pah",4500,880);
    }
  }
}

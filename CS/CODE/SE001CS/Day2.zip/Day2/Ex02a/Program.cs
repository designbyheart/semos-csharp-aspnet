﻿using System;

namespace Ex02a {
  internal class Program {
    static void Main(string[] args) {
      Console.Write("Radius?>>");
      double r = double.Parse(Console.ReadLine());

      Console.WriteLine("Radius:{0:f4}", r);
      Console.WriteLine("Area:{0:f4}", Math.PI * r * r);
      Console.WriteLine("Circumference:{0:f4}", 2 * Math.PI * r);
      Console.ReadKey();
    }
  }
}

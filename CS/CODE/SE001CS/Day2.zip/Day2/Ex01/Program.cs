﻿//Bitwise operation
using System;

namespace Ex01 {
  internal class Program {
    static void ShowBits(string prompt, int bits32) {
      Console.Write("{0}\t:",prompt);
      for(int i = 0; i < 32; i++) {
        Console.Write(((bits32 & 0x80000000)==0)?0:1);
        bits32 <<= 1;
      }
      Console.WriteLine();
    }

    static bool IsWellFormed(int state) {
      int flags = 0x000001FF;
      for (int i=0;i<9; i++) {
        int digit = state % 10;
        flags &= ~(1 << digit);
        state /= 10;
      }
      return (state==0) && (flags==0);
    }
    static void Main(string[] args) {
      int x = 5;
      int y = 3;
      //ShowBits("x", x);
      //ShowBits("y", y);
      //ShowBits("x&y", x&y);
      //ShowBits("x|y", x|y);
      //ShowBits("x^y", x^y);
      //ShowBits("x<<1", x << 1);//Shift Left
      //ShowBits("x>>1", x>>1);//Signed Shift Right
      //ShowBits("~x", ~x);//Invertion

      int mask = 6;
      //ShowBits("mask", mask);

      //SET
      //ShowBits("SET", x | mask);

      //TOGGLE
      //ShowBits("TOG", x ^ mask);

      //CLEAR
      //ShowBits("~mask", ~mask);
      //ShowBits("CLR", x & ~mask);


      //TEST
      //Console.WriteLine("Any bit on?:{0}", (x & mask) != 0);
      //Console.WriteLine("All bits on?:{0}", (x & mask) == mask);

      Console.WriteLine(IsWellFormed(576238410));
      
      Console.ReadKey();
    }
  }
}

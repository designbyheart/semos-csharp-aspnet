﻿//Generalization
//Key concepts:
//  1) Constructor Chaining (base or this)
//  2) Superclass
//  3) Subclass
//  4) Foundation
//  5) Single Assignment of Responsibilty
//  6) Inheritance (IS-A Reuse)
//  7) Default Base class
//  8) Inrect/Indirect Instance
using System;

namespace OOP3 {
  class Person:Object {
    public string Name;
    public Person(string name) {
      if (name.Length > 50) throw new Exception("Name too long!");
      Name = name;
    }
  }
  class Student:Person {
    public float CGPA;
    public Student(string name, float cgpa):base(name) {
      CGPA = cgpa;
      /*
       * Another 100 lines of common initialization logic
       */ 
    }
    public Student():this("", 0.0F) {
    }
  }
  class Staff:Person {
    public double Salary;
    public Staff(string name, double salary):base(name) {
      if (salary < 1500) throw new Exception("Salary too low!");
      Salary = salary;
    }
  }
  class Lecturer:Staff {
    public float Allowance;
    public Lecturer(string name, double salary, float allowance):base(name, salary) {
      Allowance = allowance;
    }
  }

  class Clerk:Staff {
    public float OTRate;
    public ushort OTHours;
    public Clerk(string name, double salary, float oTRate, ushort oTHours = 0):base(name, salary){
      OTRate = oTRate;
      OTHours = oTHours;
    }
  }

  internal class Program {
    static void Main(string[] args) {
      Student s1 = new Student("Yong Tau Foo", 3.15F); //Instantiation
      Student s3 = new Student();

      Lecturer lec = new Lecturer("Tong Sam Pah", 4500, 880);


    }
  }
}

﻿using System;

namespace TestPerson {
  class AgeTooHighException:AgeException {
    public AgeTooHighException(String msg) : base(msg) { }
  }
}

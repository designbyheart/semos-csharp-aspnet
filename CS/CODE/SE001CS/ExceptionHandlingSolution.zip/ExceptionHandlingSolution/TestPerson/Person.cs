﻿using System;

namespace TestPerson {
  class Person {
    public readonly String Name;
    public Person(String name) {
      Name = name;
    }
    private byte _Age;//byte: 0..255
    public byte Age {
      get {
        return _Age;
      }
      set {
        if (value == 0) throw new AgeZeroException("Age can't be zero!");
        if (value >128) throw new AgeTooHighException("Is this human?!");
        _Age = value;
      }
    }
  }
}

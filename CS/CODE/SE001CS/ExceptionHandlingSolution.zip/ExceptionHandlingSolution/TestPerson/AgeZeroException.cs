﻿using System;

namespace TestPerson {
  class AgeZeroException:AgeException {
    public AgeZeroException(String msg) : base(msg) { }
  }
}

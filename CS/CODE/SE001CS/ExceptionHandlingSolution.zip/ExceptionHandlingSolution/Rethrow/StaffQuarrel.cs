﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rethrow {
  class StaffQuarrel:SomethingBad {
    public readonly String Who1;
    public readonly String Who2;
    public StaffQuarrel(string who1,string who2){
      Who1 = who1;
      Who2 = who2;
    }
    override public String Message {
      get {
        return Who1 + " quarrel with " + Who2;
      }
    }
  }
}

﻿using System;

namespace Rethrow {
  class StaffDie:SomethingBad {
    public readonly String Who;
    public StaffDie(String who,String reason) : base(who +" die due to " +reason) {
      Who = who;
    }
  }
}

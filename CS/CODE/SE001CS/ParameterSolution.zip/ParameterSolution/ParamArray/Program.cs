﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ParamArray {
  class Program {
    static double Sum(params double[] items) {
      double sum = 0;
      foreach (double item in items) sum += item;
      return sum;
    }
    static double Max(double max, params double[] items) {
      foreach (double item in items){
        if (max < item) max = item;
      }
      return max;
    }
    static void Main(string[] args) {
      Console.WriteLine("The max value is {0}", Max(4, 3, 6, 2, 1, 5));
      Console.WriteLine("The max value is {0}", Max(4));
      Console.ReadKey();
    }
    //static void Main(string[] args) {
    //  Console.WriteLine("Sum(1,2,3)={0}", Sum(1, 2, 3));
    //  Console.WriteLine("Sum(1,2,3,4,5)={0}", Sum(1, 2, 3, 4, 5));
    //  double[] data = { 1.1, 2.2, 3.3, 4.4 };
    //  Console.WriteLine("Sum(data)={0}", Sum(data));
    //  Console.WriteLine("Sum(data)={0}", Sum(1.1, 2.2, 3.3, 4.4));
    //  Console.ReadKey();
    //}
  }
}

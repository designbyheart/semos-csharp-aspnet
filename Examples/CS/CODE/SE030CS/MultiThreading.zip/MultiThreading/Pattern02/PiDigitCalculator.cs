﻿using System;

namespace Pattern02 {
  class PiDigitCalculator {
    //...
  }
}

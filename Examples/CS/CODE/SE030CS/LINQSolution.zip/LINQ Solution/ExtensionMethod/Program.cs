﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtensionMethod {
  static class SpecialString {
    public static bool IsCountryCode(this string source) {
      string[] codes ={
                       "my",
                       "sp",
                       "jp",
                       "us",
                     };
      if(source==null) return false;
      source = source.ToLower();
      foreach (string s in codes) if (source == s) return true;
      return false;
    }
  }
  class Program {
    static void showTest(string code) {
      string format = "You entered: {0}. It is country code: {1}";
      //Console.WriteLine(format, code, SpecialString.IsCountryCode(code));
      Console.WriteLine(format, code, code.IsCountryCode());
    }
    static void Main(string[] args) {
      showTest("my");
      Console.ReadKey();
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQAnonymousType {
  class Customer {
    public String CustomerID;
    public String Name;
    public int Age;
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YieldReturn {
  class Program {
    static bool isPrime(int n) {
      int i;
      for (i = 2; i < n; i++) if ((n % i) == 0) break;
      return (i == n);
    }
    static IEnumerable<int> GetPrimes(int n) {
      for (int i = 1; i < n; i++) {
        if(isPrime(i)) yield return i;
      }
    }
    static void Main(string[] args) {
      foreach(int prime in GetPrimes(1000)){
        Console.WriteLine(prime);
      }
      Console.ReadKey();
    }
  }
}

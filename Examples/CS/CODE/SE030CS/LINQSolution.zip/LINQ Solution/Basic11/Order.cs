﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQJoin {
  class Order {
    public int OrderId { get; set; }
    public int MusicianId { get; set; }
    public int InstrumentId { get; set; }
  }
}

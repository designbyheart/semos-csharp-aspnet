﻿using System;
using System.Collections.Generic;

namespace UniversityDelegate {
    delegate bool Swap(object lhs, object rhs);
    class AgeException : Exception {
        public AgeException(string msg) : base(msg) { }
    }
    class AgeTooLowException : AgeException {
        public AgeTooLowException(string msg) : base(msg) { }
    }
    class AgeTooHighException : AgeException {
        public AgeTooHighException(string msg) : base(msg) { }
    }


    class Person {
        public readonly string Name;

        //public void ChangeName(string newName) {
        //    Name = newName;
        //}

        private int _Age;
        virtual public int Age {
            get {
                return _Age;
            }
            set {
                if (value < 1) throw new AgeTooLowException("Age must be>0!");
                if (value > 128) throw new AgeTooHighException("Is this human?!");
                _Age = value;
            }
        }
        public Person(string name) {
            Name = name;
        }
    }
    class Student : Person {
        public float CGPA;
        public Student(string name, float cgpa) : base(name) {
            CGPA = cgpa;
            //Another 100 lines of common initialization
        }
        public Student() : this("", 0.0F) { }
    }
    abstract class Staff : Person{
        public double Salary;
        protected double EPF_CONTRIBUTION = 0.11;
        public Staff(string name, double salary) : base(name) {
            Salary = salary;
        }

        abstract public double MonthlySalary { get; }  // Operation (WHAT) 

        override public int Age {
            set {
                if (value < 16) throw new AgeTooLowException("Too young to be Staff!");
                if (value > 60) throw new AgeTooHighException(
                    "Give chance to the young one-lah!");
                base.Age = value;
            }
        }
    }
    class Lecturer : Staff {
        public float Allowance;
        public Lecturer(string name, double salary, float allowance) :
            base(name, salary) {
            Allowance = allowance;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + Allowance; // Method (HOW)
            }
        }
    }
    class Clerk : Staff {
        public float OTRate;
        public ushort OTHours;
        public Clerk(string name, double salary, float otRate) :
            base(name, salary) {
            OTRate = otRate;
            OTHours = 0;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + (OTHours * OTRate); // Method (HOW)
            }
        }
    }

    class Manager : Staff {
        public float CarAllowance;
        public Manager(string name, double salary, float carAllowance) :
            base(name, salary) {
            CarAllowance = carAllowance;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * Salary + CarAllowance; // Method (HOW)
            }
        }
    }

    class HRManager : Manager {
        public HRManager(string name, double salary) :
            base(name, salary, 500) { }
    }

    class SalesManager : Manager {
        public float PetrolAllowance;
        public double MonthlySales;
        public SalesManager(string name, double salary, float carAllowance,
            float petrolAllowance) : base(name, salary, carAllowance) {
            PetrolAllowance = petrolAllowance;
            MonthlySales = 0.0;
        }
        override public double MonthlySalary  // Operation (WHAT) 
        {
            get {
                return (1.0 - EPF_CONTRIBUTION) * (0.6 * Salary) +
                    (0.1 * MonthlySales) + CarAllowance + PetrolAllowance; // Method (HOW)
            }
        }
    }

    class Program {
        static void ShowAllStudentsInfo(Student[] students) {
            foreach (Student student in students)
                Console.WriteLine("Name:{0,-20} CGPA:{1:f2}",
                    student.Name, student.CGPA);
            Console.WriteLine();
        }

        static bool ByStudentName(object lhs, object rhs) {
            return ((Student)lhs).Name.CompareTo(((Student)rhs).Name) > 0;
        }
        static bool ByStudentNameDesc(object lhs, object rhs) {
            return ((Student)lhs).Name.CompareTo(((Student)rhs).Name) < 0;
        }
        static bool ByCGPA(object lhs, object rhs) {
            return ((Student)lhs).CGPA > ((Student)rhs).CGPA;
        }
        static bool ByCGPADesc(object lhs, object rhs) {
            return ((Student)lhs).CGPA < ((Student)rhs).CGPA;
        }
        static void Main(string[] args) {
            Student[] students = {
                new Student("Steven", 3.1F),
                new Student("Peter", 2.7F),
                new Student("Afendi", 1.8F),
                new Student("Mary", 3.4F),
                new Student("Panda", 3.2F),
            };
            ShowAllStudentsInfo(students);

            Sort(students, ByStudentName);
            ShowAllStudentsInfo(students);

            Sort(students, ByStudentNameDesc);
            ShowAllStudentsInfo(students);

            Console.WriteLine("------ Normal Delegate -------");
            Sort(students, ByCGPA);
            ShowAllStudentsInfo(students);

            Console.WriteLine("------ Anonymous Delegate -------");
            Sort(students, delegate(object lhs, object rhs) {
                return ((Student)lhs).CGPA > ((Student)rhs).CGPA; });
            ShowAllStudentsInfo(students);

            Console.WriteLine("------ Lambda Expression -------");
            Sort(students, (lhs,rhs)=>((Student)lhs).CGPA > ((Student)rhs).CGPA);
            ShowAllStudentsInfo(students);


            Sort(students, ByCGPADesc);
            ShowAllStudentsInfo(students);

            ShowAllStudentsInfo(students);

            Console.ReadKey();
        }

        static void ShowAllStaffInfo(Staff[] allStaff) {
            foreach (Staff staff in allStaff)
                Console.WriteLine("Name:{0,-20} Monthly Salary:{1:c}",
                    staff.Name, staff.MonthlySalary);
            Console.WriteLine();
        }
        static void Sort(object[] items, Swap swap) {
            int n = items.Length;
            for (int x = 0; x < (n - 1); x++) {
                for (int y = 0; y < (n - 1 - x); y++) {
                    if (swap(items[y],items[y + 1])) {
                        object item = items[y];
                        items[y] = items[y + 1];
                        items[y + 1] = item;
                    }
                }
            }
        }

        static bool ByMonthlySalary(object lhs, object rhs) {
            return ((Staff)lhs).MonthlySalary > ((Staff)rhs).MonthlySalary;
        }
        static bool ByMonthlySalaryDesc(object lhs, object rhs) {
            return ((Staff)lhs).MonthlySalary < ((Staff)rhs).MonthlySalary;
        }
        static bool ByName(object lhs, object rhs) {
            return ((Staff)lhs).Name.CompareTo(((Staff)rhs).Name)>0;
        }
        static bool ByNameDesc(object lhs, object rhs) {
            return ((Staff)lhs).Name.CompareTo(((Staff)rhs).Name)<0;
        }

        static void Main2(string[] args) {
            Staff[] staff2022 = new Staff[] {
                new Lecturer("Afendi", 3500, 550),
                new Clerk("Abu Bakar", 2000, 15),
                new Manager("Ahmad", 5000, 550),
                new HRManager("Abu", 4500),
                new SalesManager("Ali", 4000, 600, 800),
            };
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, ByMonthlySalary);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, ByMonthlySalaryDesc);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, ByName);
            ShowAllStaffInfo(staff2022);

            Sort(staff2022, ByNameDesc);
            ShowAllStaffInfo(staff2022);

            Console.ReadKey();
        }
    }
}

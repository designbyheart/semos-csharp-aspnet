﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FlyweightExAnswer {
  struct ShapeExState {
    public Shape shape;
    public int x, y;
    public ShapeExState(Shape shape, int x, int y) {
      this.shape = shape;
      this.x = x;
      this.y = y;
    }
  }
  public partial class Form1 : Form {
    ShapeFactory shapes = new ShapeFactory();
    List<ShapeExState> shapeExStates = new List<ShapeExState>();
    public Form1() {
      InitializeComponent();
      for(int i=0; i<12; i++) {
        shapeExStates.Add(new ShapeExState(shapes["Red Circle"], 50 * i + 40, 20));
      }
      for (int i = 0; i < 8; i++) {
        shapeExStates.Add(new ShapeExState(shapes["Magenta Circle"], 50 * i + 40, 70));
      }
      for (int i = 0; i < 15; i++) {
        shapeExStates.Add(new ShapeExState(shapes["Blue Rectangle"], i * 30 + 10, 150));
      }

      //Unshare Flyweight
      shapeExStates.Add(new ShapeExState(new Circle(40, Color.Black), 200, 200));
    }

    private void Form1_Load(object sender, EventArgs e) {

    }

    private void Form1_Paint(object sender, PaintEventArgs e) {
      foreach(ShapeExState sexs in shapeExStates) {
        sexs.shape.Show(e.Graphics, sexs.x, sexs.y);
      }
    }
  }
}

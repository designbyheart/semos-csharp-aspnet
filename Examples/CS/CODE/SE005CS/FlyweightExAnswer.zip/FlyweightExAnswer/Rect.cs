﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyweightExAnswer {
  class Rect : Shape {
    int w, h;
    Color color;
    public Rect(int w, int h, Color color) {
      this.w = w;
      this.h = h;
      this.color = color;
    }
    public override void Show(Graphics g,int x, int y) {
      g.DrawRectangle(new Pen(color), new Rectangle(x, y, w, h));
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace FlyweightExAnswer {
  class Circle : Shape {
    int radius;
    Color color;
    public Circle(int r, Color color) {
      radius = r;
      this.color = color;
    }
    public override void Show(Graphics g, int cx, int cy) {
      Rectangle r = new Rectangle(cx - radius, cy - radius, 2 * radius, 2 * radius);
      g.DrawEllipse(new Pen(color), r);
    }
  }
}

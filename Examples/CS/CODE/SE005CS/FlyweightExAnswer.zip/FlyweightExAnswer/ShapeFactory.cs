﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace FlyweightExAnswer {
  class ShapeFactory {
    private Dictionary<String, Shape> shapes =
        new Dictionary<String, Shape>();
    public ShapeFactory() {
      shapes.Add("Red Circle",     new Circle(20, Color.Red));
      shapes.Add("Magenta Circle", new Circle(20, Color.Magenta));
      shapes.Add("Blue Rectangle", new Rect(20, 15, Color.Blue));
    }
    public Shape this[string name] {//Indexer
      get {
        return shapes.ContainsKey(name) ? shapes[name] : null;
      }
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BayanLepas {
  public class House {
    //Bed Room
    private int Bed;
    private void Sister() { }

    //Dining Room
    protected int Table;
    protected void Mother() { }

    //Garden
    public int Flower;
    public void Father() { }

    //Backyard
    internal int Bonsai;
    internal void Brother(){}

    //Home Theathre
    protected internal int OLED100InchTV;
    internal protected int BlurayPlay;

  }
}

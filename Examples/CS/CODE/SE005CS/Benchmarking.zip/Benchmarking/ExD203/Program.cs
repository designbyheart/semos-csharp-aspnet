﻿using System;
using Benchmarking;
namespace ExD203 {
  class Program {
    static void Main(string[] args) {
      const uint NoOfIteration = 1_000_000;
      long x = 1000;
      Console.WriteLine("x / 16 is {0}", x / 16);
      Console.WriteLine("x >> 4 is {0}", x >> 4);
      Profiler.Profile("x / 16", NoOfIteration, () => {
        double result = x / 16;
      });
      Profiler.Profile("x >> 4", NoOfIteration, () => {
        double result = x >> 4;
      });
    }
  }
}

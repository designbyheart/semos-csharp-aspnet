﻿//Class Members
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test27 {
    class Account {
      public double Balance;
      public float InterestRate = 0.05F;
      public Account(double initAmount) {
        Balance = initAmount;
      }
      public Account() : this(0.0) { }
    }
    class Account2 {
      public double Balance;
      static public float InterestRate = 0.05F;
      public Account2(double initAmount) {
        Balance = initAmount;
      }
      public Account2() : this(0.0) { }
    }

    [Params(100, 1_000, 10_000)]
    public int Size { get; set; }


    [GlobalSetup]
    public void Setup() {
    }


    [Benchmark(Baseline=true)]
    public void useInstanceMember() {
      List<Account> accounts = new List<Account>();
      for (int i = 0; i < Size; i++) {
        accounts.Add(new Account());
      }
      foreach (var account in accounts) account.InterestRate = 0.06F;
    }

    [Benchmark]
    public void useClassMember() {
      List<Account2> accounts = new List<Account2>();
      for (int i = 0; i < Size; i++) {
        accounts.Add(new Account2());
      }
      Account2.InterestRate = 0.06F;
    }
  }
}
/*
|            Method |  Size |       Mean |     Error |    StdDev | Ratio | RatioSD |   Gen 0 |   Gen 1 | Allocated |
|------------------ |------ |-----------:|----------:|----------:|------:|--------:|--------:|--------:|----------:|
| useInstanceMember |   100 |   1.963 us | 0.0376 us | 0.0386 us |  1.00 |    0.00 |  1.9760 |       - |      3 KB |
|    useClassMember |   100 |   1.334 us | 0.0232 us | 0.0258 us |  0.68 |    0.02 |  1.7204 |       - |      3 KB |
|                   |       |            |           |           |       |         |         |         |           |
| useInstanceMember |  1000 |  16.766 us | 0.2290 us | 0.2030 us |  1.00 |    0.00 | 18.0054 |       - |     28 KB |
|    useClassMember |  1000 |  11.452 us | 0.1536 us | 0.1361 us |  0.68 |    0.01 | 15.4572 |       - |     24 KB |
|                   |       |            |           |           |       |         |         |         |           |
| useInstanceMember | 10000 | 223.975 us | 3.3930 us | 2.8333 us |  1.00 |    0.00 | 93.2617 | 28.5645 |    324 KB |
|    useClassMember | 10000 | 153.321 us | 2.0212 us | 1.7917 us |  0.68 |    0.01 | 74.2188 | 36.8652 |    285 KB |
 */

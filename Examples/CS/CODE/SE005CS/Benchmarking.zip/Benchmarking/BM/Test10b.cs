﻿//Using bitwise operators
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test10b {
    static bool isWellFormed1(uint n) {
      bool[] flags = new bool[] {
        false, false, false, false, false, false, false, false, false};
      for (int i = 0; i < 9; i++) {
        uint d = n % 10;
        n /= 10;
        flags[d] = true;
      }
      for (int i = 0; i < 9; i++) {
        if (flags[i] == false) return false;
      }
      return (n == 0);
    }
    static bool isWellFormed2(uint n) {
      int flags = 0x000001FF;
      for (int i = 0; i < 9; i++) {
        uint d = n % 10;
        n /= 10;
        flags &= ~(1 << (int)d);
      }
      return (n == 0) && (flags == 0);
    }

    [Benchmark(Baseline = true)]
    public void useArray() {
      bool result = isWellFormed1(514076823);
    }

    [Benchmark]
    public void useBitwise() {
      bool result = isWellFormed2(514076823);
    }
    //void Main() {
    //  Console.WriteLine("isWellFormed1(514076823):" + isWellFormed1(514076823));
    //  Console.WriteLine("isWellFormed2(514076823):" + isWellFormed2(514076823));
    //}
  }
}
/*
|     Method |      Mean |    Error |   StdDev | Ratio | RatioSD |  Gen 0 | Allocated |
|----------- |----------:|---------:|---------:|------:|--------:|-------:|----------:|
|   useArray | 114.53 ns | 2.877 ns | 8.301 ns |  1.00 |    0.00 | 0.0153 |      24 B |
| useBitwise |  92.36 ns | 1.487 ns | 1.391 ns |  0.80 |    0.06 |      - |         - |
*/

﻿// Using proper collections: Access
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test17b {
    List<int> items1;
    LinkedList<int> items2;
    [Params(100, 1_000, 2_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
      items1 = new List<int>();
      items2 = new LinkedList<int>();
      for (var i = 0; i < Size; i++) {
        items1.Add(i);
        items2.AddLast(i);
      }
    }

    [Benchmark]
    public void accessListWithForEach() {
      int result = 0;
      foreach (var item in items1) result += item;
    }
    [Benchmark]
    public void accessListWithLoopIndexer() {
      int result = 0;
      for(var i = 0; i < items1.Count; i++) result += items1[i];
    }
    [Benchmark]
    public void accessListWithExtensionMethod() {
      int result = 0;
      items1.ForEach(e => result += e);
    }

    [Benchmark]
    public void accessLinkedListWithForEach() {
      int result = 0;
      foreach (var item in items2) result += item;
    }
    [Benchmark]
    public void iterateThroughLinkedList() {
      int result = 0;
      var item = items2.First;
      while (item != null) {
        result += item.Value;
        item = item.Next;
      }
    }
  }
}
/*

|                        Method | Size |      Mean |    Error |    StdDev |    Median |  Gen 0 | Allocated |
|------------------------------ |----- |----------:|---------:|----------:|----------:|-------:|----------:|
|         accessListWithForEach |   10 |  64.70 ns | 1.245 ns |  1.164 ns |  64.79 ns |      - |         - |
|     accessListWithLoopIndexer |   10 |  18.88 ns | 0.428 ns |  0.379 ns |  18.99 ns |      - |         - |
| accessListWithExtensionMethod |   10 |  67.70 ns | 3.075 ns |  8.773 ns |  65.72 ns | 0.0280 |      44 B |
|   accessLinkedListWithForEach |   10 | 113.34 ns | 2.321 ns |  5.240 ns | 113.01 ns |      - |         - |
|      iterateThroughLinkedList |   10 |  21.78 ns | 0.484 ns |  0.629 ns |  21.77 ns |      - |         - |
|         accessListWithForEach |   20 | 151.26 ns | 5.788 ns | 16.701 ns | 152.30 ns |      - |         - |
|     accessListWithLoopIndexer |   20 |  51.13 ns | 4.123 ns | 12.157 ns |  46.44 ns |      - |         - |
| accessListWithExtensionMethod |   20 | 108.64 ns | 1.994 ns |  4.418 ns | 108.66 ns | 0.0279 |      44 B |
|   accessLinkedListWithForEach |   20 | 211.05 ns | 4.245 ns |  6.222 ns | 210.66 ns |      - |         - |
|      iterateThroughLinkedList |   20 |  50.38 ns | 1.298 ns |  3.464 ns |  50.94 ns |      - |         - |
|         accessListWithForEach |   30 | 187.62 ns | 3.730 ns |  6.334 ns | 186.79 ns |      - |         - |
|     accessListWithLoopIndexer |   30 |  55.88 ns | 1.182 ns |  1.840 ns |  55.75 ns |      - |         - |
| accessListWithExtensionMethod |   30 | 182.28 ns | 3.664 ns |  7.060 ns | 181.98 ns | 0.0279 |      44 B |
|   accessLinkedListWithForEach |   30 | 293.93 ns | 5.868 ns | 11.022 ns | 292.04 ns |      - |         - |
|      iterateThroughLinkedList |   30 |  98.29 ns | 3.860 ns | 11.075 ns |  96.78 ns |      - |         - |
 */


/*
 * Conclusion: If the collection is large (Say > 10,000), and involve many insert
 *             or remove elements in between (No the last element), Linked-List is
 *             Better. Other than that, use List
 */ 
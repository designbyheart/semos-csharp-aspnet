﻿//Avoid costly functions
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test32 {
    double x = 100;
    double result;

    [Benchmark(Baseline=true,  Description = "Math.Pow(x, 2)")]
    public void Method1() {
      result = Math.Pow(x, 2);
    }

    [Benchmark(Description = "x * x")]
    public void Method2() {
      result = x * x;
    }
  }
}
/*
|           Method |      Mean |     Error |    StdDev | Allocated |
|----------------- |----------:|----------:|----------:|----------:|
| 'Math.Pow(x, 2)' | 50.151 ns | 1.0205 ns | 0.8522 ns |         - |
|          'x * x' |  1.820 ns | 0.0830 ns | 0.2328 ns |         - |
*/


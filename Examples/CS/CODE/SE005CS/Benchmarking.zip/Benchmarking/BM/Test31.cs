﻿//Meta Programming: (Need to set the project to unsafe mode)
using System.Reflection.Emit;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  unsafe public class Test31 {
    public delegate void MemCpyFunction(void* des, void* src, uint n);
    private static readonly MemCpyFunction memcpy;
    static Test31() {
      var dynamicMethod = new DynamicMethod(
        "memcpy",
        typeof(void),
        new[] { typeof(void*), typeof(void*), typeof(uint) },
        typeof(Program)
        );
      var ilGenerator = dynamicMethod.GetILGenerator();
      ilGenerator.Emit(OpCodes.Ldarg_0);
      ilGenerator.Emit(OpCodes.Ldarg_1);
      ilGenerator.Emit(OpCodes.Ldarg_2);
      ilGenerator.Emit(OpCodes.Cpblk);
      ilGenerator.Emit(OpCodes.Ret);
      memcpy = (MemCpyFunction)dynamicMethod.CreateDelegate(
                   typeof(MemCpyFunction));
    }

    int[] Source;
    int[] Destination;

    [Params(100, 1000, 10_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
      Source = new int[Size];
      Destination = new int[Size];
    }



    [Benchmark(Baseline = true)]
    public void normalAssignment() {
      for (int i = 0; i < Size; i++) {
        Destination[i] = Source[i];
      }
    }

    [Benchmark]
    public void useMetaMethod() {
      fixed (int* ps = &Source[0], pd = &Destination[0]) {
        memcpy(pd, ps, (uint)(sizeof(int) * Size));
      }
    }
  }
}
/*
|           Method |  Size |         Mean |      Error |       StdDev |       Median | Ratio | Allocated |
|----------------- |------ |-------------:|-----------:|-------------:|-------------:|------:|----------:|
| normalAssignment |   100 |    116.37 ns |   1.639 ns |     1.453 ns |    116.15 ns |  1.00 |         - |
|    useMetaMethod |   100 |     25.45 ns |   0.281 ns |     0.249 ns |     25.47 ns |  0.22 |         - |
|                  |       |              |            |              |              |       |           |
| normalAssignment |  1000 |  1,074.60 ns |  21.431 ns |    21.048 ns |  1,070.12 ns |  1.00 |         - |
|    useMetaMethod |  1000 |    118.18 ns |   2.281 ns |     2.133 ns |    117.85 ns |  0.11 |         - |
|                  |       |              |            |              |              |       |           |
| normalAssignment | 10000 | 11,837.67 ns | 452.650 ns | 1,313.221 ns | 11,389.13 ns |  1.00 |         - |
|    useMetaMethod | 10000 |  1,992.63 ns |  38.227 ns |    33.887 ns |  2,000.78 ns |  0.17 |         - |
 */

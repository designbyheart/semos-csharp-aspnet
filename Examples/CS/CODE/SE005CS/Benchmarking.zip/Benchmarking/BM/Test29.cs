﻿//Using Pointer: Array.Clear and memset 
using System;
using System.Runtime.InteropServices;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  unsafe public class Test29 {
    [DllImport("msvcrt.dll", EntryPoint = "memset",
        CallingConvention = CallingConvention.Cdecl,
        SetLastError = false)]
    public static extern IntPtr memset(void* dest, int c, int size_t);

    [Params(100, 1_000, 10_000)]
    public int Size { get; set; }

    int[] Data;

    [GlobalSetup]
    public void Setup() {
      Data = new int[Size];
    }


    [Benchmark]
    public void conventionalWay() {
      for (var i = 0; i < Data.Length; i++) Data[i] = 0;
    }

    [Benchmark]
    public void useArrayClear() {
      Array.Clear(Data, 0, Data.Length);
    }

    [Benchmark]
    public void useMemset() {
      fixed (void* p = &Data[0]) {
        memset(p, 0, sizeof(int) * Data.Length);
      }
    }

    //class X {
    //  int a;
    //}

    //void Main() {
    //  X x = new X();
    //  X y = x;
    //  x = new X();
    //  y = x;
    //}
  }
}
/*
|          Method |  Size |         Mean |      Error |     StdDev |       Median | Allocated |
|---------------- |------ |-------------:|-----------:|-----------:|-------------:|----------:|
| conventionalWay |   100 |     77.05 ns |   4.472 ns |  12.904 ns |     71.98 ns |         - |
|   useArrayClear |   100 |    304.71 ns |  10.040 ns |  28.482 ns |    293.73 ns |         - |
|       useMemset |   100 |     65.49 ns |   2.829 ns |   8.116 ns |     63.51 ns |         - |

| conventionalWay |  1000 |    462.18 ns |   9.278 ns |   9.528 ns |    460.92 ns |         - |
|   useArrayClear |  1000 |  2,453.31 ns |  28.345 ns |  23.669 ns |  2,450.58 ns |         - |
|       useMemset |  1000 |    132.71 ns |   1.928 ns |   1.610 ns |    132.38 ns |         - |

| conventionalWay | 10000 |  4,401.84 ns |  79.942 ns |  70.867 ns |  4,382.06 ns |         - |
|   useArrayClear | 10000 | 24,309.71 ns | 150.257 ns | 117.311 ns | 24,324.16 ns |         - |
|       useMemset | 10000 |  1,371.85 ns |  17.154 ns |  14.325 ns |  1,368.23 ns |         - |
 */

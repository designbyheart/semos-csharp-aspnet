﻿//The impact of constructor chaining
using System.Runtime.CompilerServices;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test05 {
    class Person {
      public string Name;

      [MethodImplAttribute(MethodImplOptions.NoInlining)]
      public Person(string name) {
        Name = name;
      }
    }
    class Staff : Person {
      public double Salary;

      [MethodImplAttribute(MethodImplOptions.NoInlining)]
      public Staff(string name, double salary) : base(name) {
        Salary = salary;
      }
    }
    class Staff2 {
      public string Name;
      public double Salary;

      [MethodImplAttribute(MethodImplOptions.NoInlining)]
      public Staff2(string name, double salary) {
        Name = name;
        Salary = salary;
      }
    }
    class Manager : Staff {
      public float CarAllowance;
      public Manager(string name, double salary, float carAllowance) :
        base(name, salary) {
        CarAllowance = carAllowance;
      }
    }
    class Manager2 : Staff2 {
      public float CarAllowance;
      public Manager2(string name, double salary, float carAllowance) :
        base(name, salary) {
        CarAllowance = carAllowance;
      }
    }
    class Manager3 {
      public string Name;
      public double Salary;
      public float CarAllowance;
      public Manager3(string name, double salary, float carAllowance) {
        Name = name;
        Salary = salary;
        CarAllowance = carAllowance;
      }
    }

    object obj;
    [Benchmark(Description = "3-Levels", Baseline = true)]
    public void callManager1() {
      obj = new Manager("Ali", 5000.0, 500.0F);
    }

    [Benchmark(Description = "2-Levels")]
    public void callManager2() {
      obj = new Manager2("Ali", 5000.0, 500.0F);
    }

    [Benchmark(Description = "1-Level")]
    public void callManager3() {
      obj = new  Manager3("Ali", 5000.0, 500.0F);
    }
  }
}
/*
|   Method |     Mean |     Error |    StdDev | Ratio | RatioSD |  Gen 0 | Allocated |
|--------- |---------:|----------:|----------:|------:|--------:|-------:|----------:|
| 3-Levels | 9.994 ns | 0.1143 ns | 0.0892 ns |  1.00 |    0.00 | 0.0153 |      24 B |
| 2-Levels | 8.505 ns | 0.1514 ns | 0.1264 ns |  0.85 |    0.02 | 0.0153 |      24 B |
|  1-Level | 6.960 ns | 0.1669 ns | 0.1562 ns |  0.70 |    0.02 | 0.0153 |      24 B |
*/

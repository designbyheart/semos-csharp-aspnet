﻿//Lookup Tables Exercise
//Challange: Total up first 50 positive prime numbers
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Engines;

namespace BM {
  [SimpleJob(RunStrategy.ColdStart, targetCount: 1)]
  [MemoryDiagnoser]
  public class Test35Ex {
    [Params(200, 200, 250, 180)]
    public int Size { get; set; }

    static List<long> primes = new List<long>();

    [GlobalSetup]
    public void Setup() {
    }

    static bool isPrime(long n) {
      long x;
      if (n < 0) n = -n;
      for (x = 2; (x < n) && ((n % x) != 0); x++) ;
      return x == n;
    }

    [Benchmark(Baseline = true)]
    public void withoutCache() {
      long p = 0, total = 0;
      for (var i = 0; i < Size; i++) {
        while (!isPrime(p)) p++;
        total += p++;
      }
      //System.Console.WriteLine("withoutCache():{0}", total);//First 50 positive primes total is 5517
    }

    [Benchmark]
    public void withCache() {
      long total = 0;
      int n = primes.Count;
      for (var i = 0; i < ((n < Size) ? n : Size); i++) total += primes[i];
      if (Size > n) {
        long p = (n > 0) ? (primes[n - 1] + 1):0;
        for (var i = n; i < Size; i++) {
          while (!isPrime(p)) p++;
          primes.Add(p);
          total += p++;
        }
      }
      //System.Console.WriteLine("withCache():{0}", total);
    }

    //void Main() {
    //  Setup();
    //  Size = 50;
    //  withoutCache();
    //  withCache();
    //}
  }
}

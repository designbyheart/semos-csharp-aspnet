﻿//Using TryParse() method
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test20 {
    [Params("123", "Hello")]
    public string s { get; set; }

    [Benchmark(Baseline = true)]
    public void useExceptionHandling() {
      try {
        int n = int.Parse(s);
        //Use the n to do something
      } catch (Exception) {
        //Do something else
      }
    }

    [Benchmark]
    public void useTryParse() {
      int n;
      if (int.TryParse(s, out n)) {
        //Use the n to do something
      } else {
        //Do something else
      }
    }
  }
}
/*
|               Method |        Mean |       Error |      StdDev | Ratio |  Gen 0 | Allocated |
|--------------------- |------------:|------------:|------------:|------:|-------:|----------:|
| useExceptionHandling | 60,630.7 ns | 1,195.42 ns | 2,414.81 ns | 1.000 | 0.2441 |     409 B |
|          useTryParse |    124.7 ns |     3.80 ns |    10.22 ns | 0.002 |      - |         - |
 */

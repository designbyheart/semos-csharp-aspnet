﻿//Refactor to less costly expresion
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test33 {
    double a = 13;
    double x = 40;
    double y = 15;

    //ax - ay - 2x + 2y => (x - y)(a - 2)
    [Benchmark(Baseline = true, Description = "ax - ay - 2x + 2y")]
    public void original() {
      double result;
      for(var i=0;i<1000;i++) result = a*x - a*y - 2*x + 2*y;
    }

    [Benchmark(Description = "(x - y)(a -2)")]
    public void refactored() {
      double result;
      for (var i = 0; i < 1000; i++) result = (x-y)*(a-2);
    }

    //int Main() {
    //  Console.WriteLine("original:" + original());
    //  Console.WriteLine("refactored:" + refactored());
    //  return 0;
    //}
  }
}
/*
|              Method |      Mean |     Error |    StdDev |    Median | Ratio | RatioSD | Allocated |
|-------------------- |----------:|----------:|----------:|----------:|------:|--------:|----------:|
| 'ax - ay - 2x + 2y' | 1.6133 ns | 0.2353 ns | 0.2086 ns | 1.5950 ns |  1.00 |    0.00 |         - |
|     '(x - y)(a -2)' | 0.0676 ns | 0.1442 ns | 0.1278 ns | 0.0000 ns |  0.05 |    0.09 |         - |
*/


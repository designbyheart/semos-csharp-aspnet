﻿//The impact of boxing and unboxing
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test08 {
    const int N = 100;
    object[] data1 = new object[N];
    int[] data2 = new int[N];

    [Benchmark(Baseline = true)]
    public void boxing() {
      var total = 0;
      for (int i = 0; i < data1.Length; i++) data1[i] = i;//Boxing
      foreach (var item in data1) total += (int)item;//Unboxing
    }

    [Benchmark]
    public void stronglyType() {
      var total = 0;
      for (int i = 0; i < data2.Length; i++) data2[i] = i;
      foreach (var item in data2) total += item;
    }
  }
}
/*
|       Method |     Mean |    Error |    StdDev |   Median | Ratio |  Gen 0 | Allocated |
|------------- |---------:|---------:|----------:|---------:|------:|-------:|----------:|
|       boxing | 878.7 ns | 48.62 ns | 139.50 ns | 806.5 ns |  1.00 | 0.7639 |   1,202 B |
| stronglyType | 108.8 ns |  1.28 ns |   1.07 ns | 108.7 ns |  0.11 |      - |         - |
*/

﻿using System;
using System.Linq;
using System.Reflection;

using BenchmarkDotNet.Running;

namespace BM {
  class Program {
    static void Main(string[] args) {
      string testClassName = "BM." + args[0];
      Type genericType = Type.GetType(testClassName);
      MethodInfo methodInfo = genericType.GetMethod("Main",
        BindingFlags.Instance | BindingFlags.NonPublic);
      if (methodInfo != null) {
        if (methodInfo.Invoke(Activator.CreateInstance(genericType), null) == null) return;
        //If the class's Main() return something, the Benchmarking will continue
      }
      methodInfo = typeof(BenchmarkRunner).
      GetMethods(BindingFlags.Public | BindingFlags.Static).
          Single(m => (m.Name == "Run") &&
                    (m.GetGenericArguments().Length == 1)).
                      MakeGenericMethod(genericType);
      _ = methodInfo.Invoke(null, new object[] { null, null });

      //_ = BenchmarkRunner.Run<Test>();
    }
  }
}

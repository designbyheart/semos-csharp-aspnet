﻿//Asynchronous coding
using System;

using System.Collections.Generic;
using System.Net.Sockets;
using System.Threading;

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Engines;

namespace BM {
  [SimpleJob(RunStrategy.ColdStart, targetCount: 1)]  //https://benchmarkdotnet.org/articles/guides/choosing-run-strategy.html
  [MemoryDiagnoser]
  public class Test30 {
    [Params(100)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
    }

    List<int> openedPorts = new List<int>();

    [Benchmark(Baseline = true)]
    public void PortsScan() {
      openedPorts.Clear();
      TcpClient Scan = new TcpClient();
      for (int port=1;port<=Size;port++) {
        //Console.Write("{0} ", port);
        try {
          Scan.Connect("localhost", port);
          openedPorts.Add(port);
        } catch {
        }
      }
    }

    void ScanPorts(object obj) {
      int[] ports = (int[])obj;
      for (int port = ports[0]; port <= ports[1]; port++) {
        //if ((port%100)==0) Console.Write("{0} ",port);
        TcpClient Scan = new TcpClient();
        try {
          Scan.Connect("localhost", port);
          openedPorts.Add(port);
        } catch {
        }
      }
    }

    [Benchmark]
    public void PortsScanEx() {
      const int N = 10;
      openedPorts.Clear();
      int NoOfThread = (Size>N)?N:Size;
      int sz = Size / NoOfThread;  //Segmentize the port range
      int start = 1; //Port zero is not really a port
      Thread[] threads = new Thread[NoOfThread];
      for(int i = 0; i< NoOfThread; i++) threads[i] = new Thread(new ParameterizedThreadStart(ScanPorts)) { IsBackground = true };
      for(int i = 0; i<(NoOfThread - 1);i++) {
        int end = start + (sz - 1);
        threads[i].Start(new int[] { start, end });
        start = end + 1;
      }
      threads[NoOfThread - 1].Start(new int[] { start, Size});
      for (int i = 0; i < NoOfThread; i++) threads[i].Join();
    }

    //void Main() {
    //  Size = 100;// 65535;
    //  //PortsScan();
    //  //Console.WriteLine("\n--------------PortsScan Done-------------------\nPorts Found:");
    //  //openedPorts.ForEach(p => Console.Write("{0}\t", p)); Console.WriteLine();
    //  PortsScanEx();
    //  Console.WriteLine("\n--------------PortsScanEx Done-------------------\nPorts Found:");
    //  openedPorts.ForEach(p => Console.Write("{0}\t", p)); Console.WriteLine();
    //}
  }
}
/*
|      Method | Size |     Mean |   Error |  StdDev | Ratio | Allocated |
|------------ |----- |---------:|--------:|--------:|------:|----------:|
|   PortsScan |  100 | 160.18 s | 0.210 s | 0.186 s |  1.00 |    224 KB |
| PortsScanEx |  100 |  20.33 s | 0.023 s | 0.021 s |  0.13 |    328 KB |

IterationCount=1  RunStrategy=ColdStart
|      Method | Size |     Mean | Error | Ratio | Allocated |
|------------ |----- |---------:|------:|------:|----------:|
|   PortsScan |  100 | 164.48 s |    NA |  1.00 |    224 KB |
| PortsScanEx |  100 |  20.40 s |    NA |  0.12 |    328 KB |
 */ 
﻿//Using Buffer.BlockCopy
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test21 {
    [Params(100, 500, 1_000)]
    public int Size { get; set; }
    int[] Source;
    int[] Destinaton;

    [GlobalSetup]
    public void Setup() {
      Source = new int[Size];
      Destinaton = new int[Size + 10];
    }

    [Benchmark(Baseline = true)]
    public void useLoop() {
      for (int i = 0; i < Size; i++) {
        Destinaton[i] = Source[i];
      }
    }

    [Benchmark]
    public void useArrayCopy() {
      Array.Copy(Source, Destinaton, Size);
    }

    [Benchmark]
    public void useBufferBlockCopy() {
      Buffer.BlockCopy(Source, 0, Destinaton, 0, Size);
    }

    //void Main() {
    //  int[] data = { 1, 3, 5, 7, 9 };
    //  int[] data1 = new int[data.Length];
    //  int[] data2 = new int[data.Length];
    //  int[] data3 = new int[data.Length];
    //  /*Perform the 3 copying methods here...*/
    //  foreach (var item in data) System.Console.Write("{0}\t", item);
    //  System.Console.WriteLine();
    //  foreach (var item in data1) System.Console.Write("{0}\t", item);
    //  System.Console.WriteLine();
    //  foreach (var item in data2) System.Console.Write("{0}\t", item);
    //  System.Console.WriteLine();
    //  foreach (var item in data3) System.Console.Write("{0}\t", item);
    //  System.Console.WriteLine();
    //}
  }
}
/*
|             Method | Size |        Mean |     Error |     StdDev |      Median | Ratio | RatioSD | Allocated |
|------------------- |----- |------------:|----------:|-----------:|------------:|------:|--------:|----------:|
|            useLoop |  100 |   241.67 ns | 14.987 ns |  44.190 ns |   227.99 ns |  1.00 |    0.00 |         - |
|       useArrayCopy |  100 |   143.88 ns |  7.406 ns |  21.835 ns |   146.45 ns |  0.61 |    0.14 |         - |
| useBufferBlockCopy |  100 |    52.78 ns |  1.115 ns |   2.838 ns |    52.65 ns |  0.22 |    0.04 |         - |
|                    |      |             |           |            |             |       |         |           |
|            useLoop |  500 | 1,320.32 ns | 28.470 ns |  82.143 ns | 1,316.37 ns |  1.00 |    0.00 |         - |
|       useArrayCopy |  500 |   221.42 ns |  6.131 ns |  17.981 ns |   219.28 ns |  0.17 |    0.02 |         - |
| useBufferBlockCopy |  500 |    94.36 ns |  3.934 ns |  11.600 ns |    92.86 ns |  0.07 |    0.01 |         - |
|                    |      |             |           |            |             |       |         |           |
|            useLoop | 1000 | 1,814.62 ns | 50.170 ns | 139.021 ns | 1,795.76 ns |  1.00 |    0.00 |         - |
|       useArrayCopy | 1000 |   250.83 ns |  8.584 ns |  25.311 ns |   246.44 ns |  0.14 |    0.02 |         - |
| useBufferBlockCopy | 1000 |    73.64 ns |  1.532 ns |   3.490 ns |    73.18 ns |  0.04 |    0.00 |         - |
 */

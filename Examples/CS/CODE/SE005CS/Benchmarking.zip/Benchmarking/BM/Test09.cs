﻿//==, Equals and ReferenceEquals

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test09 {
    private class X {
      int v;
      public X(int v) {
        this.v = v;
      }
      public override bool Equals(object obj) {
        return this.v == ((X)obj).v;
      }
      static public bool operator ==(X lhs, X rhs) {
        return lhs.v == rhs.v;
      }
      static public bool operator !=(X lhs, X rhs) {
        return lhs.v != rhs.v;
      }
      public override int GetHashCode() {
        return base.GetHashCode();
      }
    }
    static X x1 = new X(100);
    static X x2 = new X(100);
    bool result;

    [Benchmark(Baseline = true)]
    public void useOperatorOverloading() {
      for (var i = 0; i < 10; i++) result = (x1 == x2);
    }

    [Benchmark]
    public void useEqualsMethod() {
      for (var i = 0; i < 10; i++) result = x1.Equals(x2);
    }

    [Benchmark]
    public void useReferenceEqualsMethod() {
      for (var i = 0; i < 10; i++) result = X.ReferenceEquals(x1, x2);
    }
  }
}
/*
|                   Method |      Mean |     Error |    StdDev |    Median | Ratio | RatioSD | Allocated |
|------------------------- |----------:|----------:|----------:|----------:|------:|--------:|----------:|
|   useOperatorOverloading | 11.217 ns | 0.3903 ns | 1.1008 ns | 10.799 ns |  1.00 |    0.00 |         - |
|          useEqualsMethod | 26.453 ns | 0.3867 ns | 0.3229 ns | 26.475 ns |  2.15 |    0.16 |         - |
| useReferenceEqualsMethod |  7.030 ns | 0.1310 ns | 0.1162 ns |  7.024 ns |  0.58 |    0.05 |         - |
*/

﻿//Class Vs Struct: Benchmark just the member access 
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test22b {
    class C1 {//Reference Type
      double r;
      public C1(double r) { Radius = r; }
      public double Radius {
        get {
          return r;
        }
        set {
          if (value < 0) throw new Exception("Radius can't be -ve!");
          r = value;
        }
      }
      public double Area { get { return Math.PI * r * r; } }
      public double Circumference { get { return 2 * Math.PI * r; } }
      public override string ToString() {
        return String.Format("Radius:{0:F2} Area:{1:F2} Circumference:{2:F2}",
          Radius, Area, Circumference);
      }
    }
    struct C2 {//Value Type
      double r;
      public C2(double r) {
        this.r = 0;
        Radius = r;
      }
      public double Radius {
        get {
          return r;
        }
        set {
          if (value < 0) throw new Exception("Radius can't be -ve!");
          r = value;
        }
      }
      public double Area { get { return Math.PI * r * r; } }
      public double Circumference { get { return 2 * Math.PI * r; } }
      public override string ToString() {
        return String.Format("Radius:{0:F2} Area:{1:F2} Circumference:{2:F2}",
          Radius, Area, Circumference);
      }
    }
    [Params(10, 100, 1000)]
    public int Size { get; set; }

    static C1 c1 = new C1(100);
    static C2 c2 = new C2(100);

    [GlobalSetup]
    public void Setup() {
    }
    [Benchmark(Baseline = true)]
    public void useClass() {
      for (var i = 0; i < Size; i++) {
        double area = c1.Area;
        double circumference = c1.Circumference;
      }
    }
    [Benchmark]
    public void useStruct() {
      for (var i = 0; i < Size; i++) {
        double area = c2.Area;
        double circumference = c2.Circumference;
      }
    }
  }
}
/*
|    Method | Size |        Mean |     Error |    StdDev | Ratio | RatioSD | Allocated |
|---------- |----- |------------:|----------:|----------:|------:|--------:|----------:|
|  useClass |   10 |    19.03 ns |  0.435 ns |  0.407 ns |  1.00 |    0.00 |         - |
| useStruct |   10 |    20.93 ns |  0.490 ns |  0.458 ns |  1.10 |    0.03 |         - |
|           |      |             |           |           |       |         |           |
|  useClass |  100 |   176.71 ns |  3.381 ns |  2.997 ns |  1.00 |    0.00 |         - |
| useStruct |  100 |   201.19 ns |  3.579 ns |  3.173 ns |  1.14 |    0.03 |         - |
|           |      |             |           |           |       |         |           |
|  useClass | 1000 | 1,565.40 ns | 30.944 ns | 34.394 ns |  1.00 |    0.00 |         - |
| useStruct | 1000 | 1,857.53 ns | 24.769 ns | 21.957 ns |  1.19 |    0.03 |         - |
*/




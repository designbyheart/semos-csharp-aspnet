﻿//The impact of inlining
using System.Runtime.CompilerServices;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test26 {
    [MethodImplAttribute(MethodImplOptions.NoInlining)]
    static int Sum1(int x, int y) {
      return x + y;
    }
    [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
    static int Sum2(int x, int y) {
      return x + y;
    }
    static int Sum3(int x, int y) {
      return x + y;
    }

    int result;

    [Benchmark(Baseline = true)]
    public void noInlining() {
      int x = 10, y = 20;
      for (var i = 0; i < 10; i++) result = Sum1(x, y);
    }

    [Benchmark]
    public void withInlining() {
      int x=10, y=20;
      for (var i = 0; i < 10; i++) result = Sum2(x, y);
    }

    [Benchmark]
    public void theDefault() {
      int x = 10, y = 20;
      for (var i = 0; i < 10; i++) result = Sum3(x, y);
    }

    [Benchmark]
    public void noMathod() {
      int x = 10, y = 20;
      for (var i = 0; i < 10; i++) result = x + y;
    }
  }
}
/*
|       Method |      Mean |     Error |    StdDev | Ratio | Allocated |
|------------- |----------:|----------:|----------:|------:|----------:|
|   noInlining | 17.508 ns | 0.3192 ns | 0.2492 ns |  1.00 |         - |
| withInlining |  6.849 ns | 0.0936 ns | 0.0829 ns |  0.39 |         - |
|   theDefault |  6.892 ns | 0.1182 ns | 0.1048 ns |  0.39 |         - |
|     noMathod |  6.945 ns | 0.0941 ns | 0.0880 ns |  0.40 |         - |
 */

﻿//The impact of overflow check
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test24 {
    const int N = 1_000_000;

    [Benchmark(Baseline = true)]
    public void noCheck() {
      for (var i = 0; i < N; i++) {
        var x = i + 2;
        x--;
        x *= 10;
      }
    }

    [Benchmark]
    public void withCheck() {
      for (var i = 0; i < N; i++) {
        checked {
          var x = i + 2;
          x--;
          x *= 10;
        }
      }
    }
    //void Main() {
    //  int n = int.MaxValue;
    //  Console.WriteLine("n:" + n);
    //  checked {

    //    unchecked {
    //      n++;
    //    }

    //  }
    //  Console.WriteLine("n:" + n);
    //}
  }
}
/*
|    Method |     Mean |   Error |  StdDev | Ratio | RatioSD | Allocated |
|---------- |---------:|--------:|--------:|------:|--------:|----------:|
|   noCheck | 347.5 us | 2.92 us | 2.59 us |  1.00 |    0.00 |         - |
| withCheck | 999.4 us | 9.66 us | 8.57 us |  2.88 |    0.04 |         - |
 */

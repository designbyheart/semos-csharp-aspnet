﻿//Using StringBuilder (Exercise)
using System.Text;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test14Ex {
    static string CreateTable1(uint nRow, uint nCol) {
      string html = "<table border='1'>\n";
      for(var r=0; r<nRow; r++) {
        html += "<tr>";
        for (var c = 0; c < nCol; c++) {
          html += "<td>&nbsp;</td>";
        }
        html += "</tr>\n";
      }
      return html;
    }
    static string CreateTable2(uint nRow, uint nCol) {
      StringBuilder html = new StringBuilder("<table border='1'>\n");
      for (var r = 0; r < nRow; r++) {
        html.Append("<tr>");
        for (var c = 0; c < nCol; c++) {
          html.Append("<td>&nbsp;</td>");
        }
        html.Append("</tr>\n");
      }
      return html.ToString();
    }
    [Params(3, 4)]
    public uint Row { get; set; }

    [Params(2, 3)]
    public uint Col { get; set; }

    [GlobalSetup]
    public void Setup() {
    }

    [Benchmark(Baseline = true)]
    public void useStringConcatenation() {
      CreateTable1(Row, Col);
    }

    [Benchmark]
    public void useStringBuilder() {
      CreateTable2(Row, Col);
    }
  }
}
/*
|                 Method | Row | Col |     Mean |     Error |    StdDev | Ratio | RatioSD |  Gen 0 | Allocated |
|----------------------- |---- |---- |---------:|----------:|----------:|------:|--------:|-------:|----------:|
| useStringConcatenation |   3 |   2 | 1.783 us | 0.0322 us | 0.0573 us |  1.00 |    0.00 | 1.3828 |   2,175 B |
|       useStringBuilder |   3 |   2 | 1.038 us | 0.0205 us | 0.0409 us |  0.58 |    0.03 | 0.4826 |     761 B |
|                        |     |     |          |           |           |       |         |        |           |
| useStringConcatenation |   3 |   3 | 2.454 us | 0.0488 us | 0.0893 us |  1.00 |    0.00 | 2.1706 |   3,417 B |
|       useStringBuilder |   3 |   3 | 1.379 us | 0.0279 us | 0.0759 us |  0.56 |    0.04 | 0.7610 |   1,198 B |
|                        |     |     |          |           |           |       |         |        |           |
| useStringConcatenation |   4 |   2 | 2.669 us | 0.0510 us | 0.0763 us |  1.00 |    0.00 | 2.2507 |   3,541 B |
|       useStringBuilder |   4 |   2 | 1.359 us | 0.0268 us | 0.0357 us |  0.51 |    0.02 | 0.7534 |   1,186 B |
|                        |     |     |          |           |           |       |         |        |           |
| useStringConcatenation |   4 |   3 | 4.332 us | 0.1579 us | 0.4631 us |  1.00 |    0.00 | 3.5934 |   5,657 B |
|       useStringBuilder |   4 |   3 | 1.691 us | 0.0508 us | 0.1450 us |  0.39 |    0.05 | 0.8297 |   1,306 B |

 */ 
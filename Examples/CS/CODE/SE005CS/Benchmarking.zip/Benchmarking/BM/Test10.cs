﻿//Using bitwise operators:Multiply and Floor Divide
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test10 {
    int x = 1000;
    int y;
    [Benchmark]
    public void useFloorDiv() {
      for (var i = 0; i < 10; i++) y = x / 16;
    }

    [Benchmark]
    public void useShiftRight() {
      for (var i = 0; i < 10; i++) y = x >> 4;
    }

    [Benchmark]
    public void useMultiply() {
      for (var i = 0; i < 10; i++) y = x * 16;
    }

    [Benchmark]
    public void useShiftLeft() {
      for (var i = 0; i < 10; i++) y = x << 4;
    }
  }
}
/*
|        Method |      Mean |     Error |    StdDev |    Median | Allocated |
|-------------- |----------:|----------:|----------:|----------:|----------:|
|   useFloorDiv | 10.787 ns | 0.2559 ns | 0.5509 ns | 10.588 ns |         - |
| useShiftRight |  7.014 ns | 0.0871 ns | 0.0772 ns |  6.985 ns |         - |
|   useMultiply |  7.045 ns | 0.1703 ns | 0.1510 ns |  7.027 ns |         - |
|  useShiftLeft |  7.025 ns | 0.1749 ns | 0.1551 ns |  6.975 ns |         - |
*/

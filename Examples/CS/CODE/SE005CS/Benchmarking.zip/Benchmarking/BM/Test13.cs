﻿//Normal return Vs return by out
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test13 {
    static int ByReturn(int x) {
      return 2 * x;
    }
    static void ByOut(int x, out int result) {
      result = 2 * x;
    }

    [Benchmark(Baseline = true)]
    public void ByReturn() {
      for (int i = 0; i < 1000; i++) {
        int result = ByReturn(i);
      }
    }

    [Benchmark]
    public void ByOut() {
      for (int i = 0; i < 1000; i++) {
        int result;
        ByOut(i, out result);
      }
    }
  }
}
/*
|   Method |       Mean |    Error |   StdDev | Ratio | RatioSD | Allocated |
|--------- |-----------:|---------:|---------:|------:|--------:|----------:|
| ByReturn |   615.9 ns | 11.19 ns | 16.41 ns |  1.00 |    0.00 |         - |
|    ByOut | 1,027.3 ns | 20.47 ns | 26.62 ns |  1.67 |    0.05 |         - |
 */ 
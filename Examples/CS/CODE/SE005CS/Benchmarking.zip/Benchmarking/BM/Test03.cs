﻿//Row-First Vs Column-First iteration:: Array of Array
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  [RyuJitX64Job, LegacyJitX86Job] // let's run the benchmarks for 32 & 64 bit
  public class Test03 {
    [Params(100, 200)]
    public int Size { get; set; }

    int[][] grid;
    [GlobalSetup]
    public void Setup() {
      grid = new int[Size][];
      for (int r = 0; r < Size; r++) grid[r] = new int[Size];
    }

    [Benchmark(Baseline = true)]
    public void rowFirst() {
      int total = 0;
      for (var r = 0; r < Size; r++) {
        for (var c = 0; c < Size; c++) {
          total += grid[r][c];
        }
      }
    }

    [Benchmark]
    public void columnFirst() {
      int total = 0;
      for (var c = 0; c < Size; c++) {
        for (var r = 0; r < Size; r++) {
          total += grid[r][c];
        }
      }
    }
  }
}
/*
|      Method | Size |      Mean |     Error |    StdDev |    Median | Ratio | RatioSD | Allocated |
|------------ |----- |----------:|----------:|----------:|----------:|------:|--------:|----------:|
|    rowFirst |  100 |  6.901 us | 0.3187 us | 0.9347 us |  6.655 us |  1.00 |    0.00 |         - |
| columnFirst |  100 |  8.480 us | 0.4886 us | 1.4096 us |  7.856 us |  1.25 |    0.27 |         - |
|             |      |           |           |           |           |       |         |           |
|    rowFirst |  200 | 20.220 us | 0.6214 us | 1.7321 us | 19.657 us |  1.00 |    0.00 |         - |
| columnFirst |  200 | 28.093 us | 0.5532 us | 1.4573 us | 27.788 us |  1.40 |    0.13 |         - |
*/ 
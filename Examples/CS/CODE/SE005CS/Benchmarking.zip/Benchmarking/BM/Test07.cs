﻿//Leverage on short circuit

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test07 {
    static bool isPrime(long n) {
      long i;
      if (n < 0) n = -n;
      for (i = 2; i < n; i++) if ((n % i) == 0) break;
      return (i == n);
    }
    static bool isEven(long n) {
      return (n % 2) == 0;
    }

    const int N = 100;

    [Benchmark(Baseline = true)]
    public void EvenANDPrime() {
      var count = 0;
      for (long n = 0; n < N; n++) {
        if (isPrime(n) && isEven(n)) count++;
      }
    }

    [Benchmark]
    public void PrimeANDEven() {
      var count = 0;
      for (long n = 0; n < N; n++) {
        if (isEven(n) && isPrime(n)) count++;
      }
    }


    //void Main() {
    //  for(int i = 0; i < 100; i++) {
    //    if (isPrime(i)) System.Console.WriteLine(i);
    //  }
    //}

  }
}
/*
|        Method |      Mean |     Error |    StdDev | Ratio | RatioSD | Allocated |
|-------------- |----------:|----------:|----------:|------:|--------:|----------:|
| ThreeANDPrime | 12.553 us | 0.5731 us | 1.6807 us |  1.00 |    0.00 |         - |
| PrimeANDThree |  3.437 us | 0.0395 us | 0.0330 us |  0.31 |    0.02 |         - |
*/

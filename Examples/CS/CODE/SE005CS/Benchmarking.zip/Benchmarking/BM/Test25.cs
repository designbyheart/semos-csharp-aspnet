﻿//Loop Vs Extension Method
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test25 {
    [Params(10, 100)]
    public int Size { get; set; }

    List<int> data;
    int N;
    [GlobalSetup]
    public void Setup() {
      data = new List<int>();
      N = Size;
      for (var i = 0; i < N; i++) data.Add(i);
    }

    [Benchmark(Baseline = true)]
    public void useLoop() {
      int total = 0;
      for (var i = 0; i < data.Count; i++) total += data[i];
    }

    [Benchmark]
    public void useExtensionMethod() {
      int total = 0;
      data.ForEach(e => total += e);
    }


    //void Main() {
    //  string code = "my";
    //  Console.WriteLine(Utils.isCountryCode(code));
    //  Console.WriteLine(code.isCountryCode());
    //}
  }
  static class Utils {
    static public bool isCountryCode(this string code) {
      string[] codes = { "my", "cn", "jp", "kr" };
      foreach (string c in codes)
        if (c == code) return true;
      return false;
    }
  }

}
/*
|             Method | Size |        Mean |      Error |     StdDev |      Median | Ratio | RatioSD |  Gen 0 | Allocated |
|------------------- |----- |------------:|-----------:|-----------:|------------:|------:|--------:|-------:|----------:|
|            useLoop |   10 |    14.92 ns |   0.110 ns |   0.092 ns |    14.96 ns |  1.00 |    0.00 |      - |         - |
| useExtensionMethod |   10 |    36.60 ns |   0.714 ns |   0.633 ns |    36.58 ns |  2.45 |    0.05 | 0.0280 |      44 B |
|                    |      |             |            |            |             |       |         |        |           |
|            useLoop |  100 |   154.19 ns |   8.291 ns |  24.315 ns |   152.51 ns |  1.00 |    0.00 |      - |         - |
| useExtensionMethod |  100 |   413.25 ns |  19.377 ns |  57.133 ns |   426.67 ns |  2.75 |    0.57 | 0.0277 |      44 B |
|                    |      |             |            |            |             |       |         |        |           |
|            useLoop | 1000 | 1,345.28 ns |  66.144 ns | 192.946 ns | 1,293.30 ns |  1.00 |    0.00 |      - |         - |
| useExtensionMethod | 1000 | 3,246.59 ns | 155.367 ns | 455.664 ns | 3,170.23 ns |  2.46 |    0.51 | 0.0267 |      44 B |
*/

﻿//The impact of Recursion
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test04 {
    static ulong FactRec(byte n) {
      return (n < 2) ? 1 : (n * FactRec((byte)((int)n - 1)));
    }
    static ulong FactLoop(byte n) {
      ulong f = 1;
      for (uint i = 2; i <= n; i++) {
        f *= i;
      }
      return f;
    }

    [Benchmark(Baseline = true)]
    public void useRecursion() {
      var result = FactRec(12);
    }

    [Benchmark]
    public void useLoop() {
      var result = FactLoop(12);
    }
  }
}
/*
|       Method |     Mean |    Error |   StdDev | Ratio | RatioSD | Allocated |
|------------- |---------:|---------:|---------:|------:|--------:|----------:|
| useRecursion | 54.52 ns | 1.009 ns | 0.788 ns |  1.00 |    0.00 |         - |
|      useLoop | 31.35 ns | 0.640 ns | 0.684 ns |  0.58 |    0.02 |         - |
 */

﻿//Row-First Vs Column-First iteration: 2-Dimentional Array
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test03b {
    [Params(100, 200)]
    public int Size { get; set; }

    int[,] grid;
    [GlobalSetup]
    public void Setup() {
      grid = new int[Size,Size];
    }

    [Benchmark(Baseline = true)]
    public void rowFirst() {
      int total = 0;
      for (var r = 0; r < Size; r++) {
        for (var c = 0; c < Size; c++) {
          total += grid[r,c];
        }
      }
    }

    [Benchmark]
    public void columnFirst() {
      int total = 0;
      for (var c = 0; c < Size; c++) {
        for (var r = 0; r < Size; r++) {
          total += grid[r,c];
        }
      }
    }
  }
}
/*
|      Method | Size |     Mean |    Error |    StdDev |   Median | Ratio | RatioSD | Allocated |
|------------ |----- |---------:|---------:|----------:|---------:|------:|--------:|----------:|
|    rowFirst |  100 | 13.78 us | 0.196 us |  0.164 us | 13.79 us |  1.00 |    0.00 |         - |
| columnFirst |  100 | 15.86 us | 0.752 us |  2.169 us | 15.15 us |  1.13 |    0.17 |         - |
|             |      |          |          |           |          |       |         |           |
|    rowFirst |  200 | 66.18 us | 3.155 us |  9.303 us | 65.91 us |  1.00 |    0.00 |         - |
| columnFirst |  200 | 65.41 us | 3.751 us | 10.821 us | 63.05 us |  1.01 |    0.21 |         - |
*/ 
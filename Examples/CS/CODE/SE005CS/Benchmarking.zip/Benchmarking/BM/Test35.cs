﻿//Caching
using System;
using System.Data;
using System.Runtime.Caching;
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test35 {
    static string Path = @"..\..\Data.XML";
    static string Key = "Data";
    static DataSet NoCahce() {
      DataSet ds = new DataSet();
      ds.ReadXml(Path);
      return ds;
    }
    static DataSet WithCache() {
      ObjectCache cache = MemoryCache.Default;
      DataSet ds = cache[Key] as DataSet;
      if (ds == null) {
        ds = new DataSet();
        ds.ReadXml(Path);
        CacheItemPolicy policy = new CacheItemPolicy();
        policy.AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(1);
        cache.Add(Key, ds, policy);
      }
      return ds;
    }

    [Benchmark(Baseline = true)]
    public void noCache() {
      DataSet ds = NoCahce();
    }

    [Benchmark]
    public void withCache() {
      DataSet ds = WithCache();
    }
  }
}
/*
|    Method |         Mean |       Error |      StdDev | Ratio |   Gen 0 |  Gen 1 |  Gen 2 | Allocated |
|---------- |-------------:|------------:|------------:|------:|--------:|-------:|-------:|----------:|
|   noCache | 596,481.6 ns | 6,615.60 ns | 5,165.02 ns | 1.000 | 31.2500 |      - |      - |  49,468 B |
| withCache |     674.5 ns |     8.01 ns |     6.69 ns | 0.001 |  0.0076 | 0.0019 | 0.0010 |      16 B |
*/

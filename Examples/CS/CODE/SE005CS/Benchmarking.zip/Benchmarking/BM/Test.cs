﻿using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test {
    int x = 0;

    [Benchmark(Description = "++", Baseline = true)]
    public void Method1() {
      x++;
    }

    [Benchmark(Description = "+=1")]
    public void Method2() {
      x+=1;
    }

    [Benchmark(Description = " = + 1 ")]
    public void Method3() {
      x = x + 1;
    }

    void Main() {
      System.Console.WriteLine("Calling Test class...");
    }
  }
}
/*
|    Method |      Mean |     Error |    StdDev | Ratio | RatioSD | Allocated |
|---------- |----------:|----------:|----------:|------:|--------:|----------:|
|        ++ | 0.5956 ns | 0.0468 ns | 0.0945 ns |  1.00 |    0.00 |         - |
|       +=1 | 0.5554 ns | 0.0365 ns | 0.0323 ns |  0.87 |    0.14 |         - |
| ' = + 1 ' | 0.5421 ns | 0.0225 ns | 0.0199 ns |  0.85 |    0.14 |         - |
*/ 
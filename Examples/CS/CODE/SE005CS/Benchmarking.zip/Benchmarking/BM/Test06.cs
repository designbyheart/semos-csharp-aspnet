﻿//Remove Redundant Code
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test06 {
    static double Pmt1(double p, float r, int n) {
      return p * ((r * Math.Pow(1.0 + r, n)) / (Math.Pow(1.0 + r, n) - 1));
    }
    static double Pmt2(double p, float r, int n) {
      double d = Math.Pow(1.0 + r, n);
      return p * ((r * d) / (d - 1));
    }

    double loan = 1_000_000;
    float annualRate = 0.046F;
    int durationInYears = 30;
    double monthlyInstallment;
    [Benchmark(Baseline = true)]
    public void original() {
      monthlyInstallment = Pmt1(loan, annualRate / 12, 12 * durationInYears);
    }

    [Benchmark]
    public void eliminateRedundantCode() {
      monthlyInstallment = Pmt2(loan, annualRate / 12, 12 * durationInYears);
    }
  }
}
/*
|                 Method |      Mean |    Error |   StdDev |    Median | Ratio | RatioSD | Allocated |
|----------------------- |----------:|---------:|---------:|----------:|------:|--------:|----------:|
|               original | 118.86 ns | 2.488 ns | 7.138 ns | 115.30 ns |  1.00 |    0.00 |         - |
| eliminateRedundantCode |  62.02 ns | 0.771 ns | 0.721 ns |  61.92 ns |  0.52 |    0.03 |         - |
*/

﻿//Using Array.Copy
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test19 {
    int[] source;
    int[] target;
    [Params(100, 1000, 10_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
      source = new int[Size];
      target = new int[Size];
    }

    [Benchmark(Baseline = true)]
    public void useLoop() {
      for (int i = 0; i < source.Length; i++) {
        target[i] = source[i];
      }
    }

    [Benchmark]
    public void useArrayCopy() {
      Array.Copy(source, target, source.Length);
    }
  }
}
/*
|       Method |  Size |        Mean |     Error |      StdDev |      Median | Ratio | RatioSD | Allocated |
|------------- |------ |------------:|----------:|------------:|------------:|------:|--------:|----------:|
|      useLoop |   100 |    148.9 ns |   7.52 ns |    22.04 ns |    142.4 ns |  1.00 |    0.00 |         - |
| useArrayCopy |   100 |    113.3 ns |   6.08 ns |    17.83 ns |    110.1 ns |  0.78 |    0.18 |         - |
|              |       |             |           |             |             |       |         |           |
|      useLoop |  1000 |  1,303.2 ns |  51.91 ns |   145.57 ns |  1,239.1 ns |  1.00 |    0.00 |         - |
| useArrayCopy |  1000 |    253.9 ns |   9.65 ns |    28.15 ns |    247.7 ns |  0.20 |    0.03 |         - |
|              |       |             |           |             |             |       |         |           |
|      useLoop | 10000 | 11,458.2 ns | 776.50 ns | 2,289.52 ns | 10,133.4 ns |  1.00 |    0.00 |         - |
| useArrayCopy | 10000 |  2,943.9 ns |  58.40 ns |    79.93 ns |  2,928.5 ns |  0.20 |    0.02 |         - |
 */

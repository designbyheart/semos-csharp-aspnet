﻿//getter Vs readonly field
using System.Runtime.CompilerServices;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test23 {
    [Params(100, 500)]
    public int Size { get; set; }

    static int N;

    [GlobalSetup]
    public void Setup() {
      N = Size;
    }

    class Person {
      string _Name1;

      public string Name1 {
        [MethodImplAttribute(MethodImplOptions.NoInlining)]
        //[MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
        get {
          return _Name1;
        }
        private set {
          _Name1 = value;
        }
      }
      public readonly string Name2;
      public Person(string name) {
        Name1 = name;
        Name2 = name;
      }
      public void ChangeName(string newName) {
        Name1 = newName;
      }
    }

    static Person p = new Person("Tong Sam Pah");

    [Benchmark(Baseline = true)]
    public void readonlyProperty() {
      string name;
      for (var i = 0; i < N; i++) name = p.Name1;
    }

    [Benchmark]
    public void readonlyField() {
      string name;
      for (var i = 0; i < N; i++) name = p.Name2;
    }
  }
}
/*
|           Method |  Size |         Mean |      Error |     StdDev | Ratio | Allocated |
|----------------- |------ |-------------:|-----------:|-----------:|------:|----------:|
| readonlyProperty |   100 |    240.69 ns |   3.468 ns |   2.896 ns |  1.00 |         - |
|    readonlyField |   100 |     43.20 ns |   0.308 ns |   0.273 ns |  0.18 |         - |
|                  |       |              |            |            |       |           |
| readonlyProperty |  1000 |  1,741.43 ns |  20.755 ns |  18.399 ns |  1.00 |         - |
|    readonlyField |  1000 |    355.47 ns |   6.423 ns |   6.308 ns |  0.20 |         - |
|                  |       |              |            |            |       |           |
| readonlyProperty | 10000 | 17,337.41 ns | 273.774 ns | 228.613 ns |  1.00 |         - |
|    readonlyField | 10000 |  3,457.97 ns |  39.593 ns |  33.062 ns |  0.20 |         - |
 
 With Inlining:
|           Method |  Size |         Mean |      Error |     StdDev | Ratio | RatioSD | Allocated |
|----------------- |------ |-------------:|-----------:|-----------:|------:|--------:|----------:|
| readonlyProperty |   100 |    126.33 ns |   2.552 ns |   3.493 ns |  1.00 |    0.00 |         - |
|    readonlyField |   100 |     95.32 ns |   1.650 ns |   1.463 ns |  0.75 |    0.03 |         - |
|                  |       |              |            |            |       |         |           |
| readonlyProperty |  1000 |  1,085.61 ns |  20.844 ns |  23.169 ns |  1.00 |    0.00 |         - |
|    readonlyField |  1000 |    741.49 ns |  12.345 ns |  11.547 ns |  0.68 |    0.02 |         - |
|                  |       |              |            |            |       |         |           |
| readonlyProperty | 10000 | 10,837.29 ns | 207.874 ns | 184.275 ns |  1.00 |    0.00 |         - |
|    readonlyField | 10000 |  7,314.46 ns | 133.103 ns | 168.333 ns |  0.68 |    0.02 |         - |
*/

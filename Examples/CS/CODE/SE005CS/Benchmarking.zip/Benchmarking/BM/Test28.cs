﻿//Using cloning
using System.Threading;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test28 {
    class X {
      public int a, b, c;
      public X() {
        a = 10;
        b = 100;
        c = 2000;

        //Uncomment the following to re-run the benchmarking again
        //Thread.Sleep(1);//Simulate the delay in object creation
      }
      public X Clone() {
        return (X)this.MemberwiseClone();  //Shallow Copy
      }
    }
    static X x = new X();
    static X x2 = new X() { a = x.a, b = x.b, c = x.c };
    static X x3 = x.Clone();


    [Benchmark(Baseline = true)]
    public void normalInstantiation() {
      for (int i = 0; i < 1000; i++) new X() { a = x.a, b = x.b, c = x.c };
    }

    [Benchmark]
    public void onjectCloning() {
      for (int i = 0; i < 1000; i++) x.Clone();
    }
  }
}
/*
|              Method |      Mean |    Error |   StdDev | Ratio | RatioSD |   Gen 0 | Allocated |
|-------------------- |----------:|---------:|---------:|------:|--------:|--------:|----------:|
| normalInstantiation |  14.55 us | 0.279 us | 0.274 us |  1.00 |    0.00 | 12.7258 |     20 KB |
|       onjectCloning | 157.21 us | 3.017 us | 2.963 us | 10.81 |    0.21 | 12.6953 |     20 KB |

With heavy constructor:

|              Method |            Mean |        Error |       StdDev | Ratio |   Gen 0 | Allocated |
|-------------------- |----------------:|-------------:|-------------:|------:|--------:|----------:|
| normalInstantiation | 15,588,406.8 us | 25,865.52 us | 24,194.62 us | 1.000 |       - |     24 KB |
|       onjectCloning |        160.5 us |      3.17 us |      3.39 us | 0.000 | 12.6953 |     20 KB |
*/

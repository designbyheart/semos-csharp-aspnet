﻿//Lookup Tables
using System;
using System.Collections.Generic;
using static BM.Test34.Month;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test34 {
    internal enum Month { JAN = 0, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC }
    static bool isLeapYear(int year) {
      if ((year % 4) != 0) return false;
      if ((year % 100) != 0) return true;
      if ((year % 400) != 0) return false;
      return true;
    }
    int[] NoOfDays = {
        31,isLeapYear(DateTime.Now.Year) ? 29 : 28,31,30,31,30,31,31,30,31,30,31
    };
    Dictionary<Month, int> NoOfDaysDict = new Dictionary<Month, int>() {
        {JAN,31},{FEB, isLeapYear(DateTime.Now.Year) ? 29 : 28},{MAR,31},{APR,30},
        {MAY,31},{JUN,30},{JUL,31 },{AUG,31 },{SEP,30},{OCT,31},{NOV,30},{DEC,31}
    };


    [Benchmark(Baseline = true)]
    public int useSwitchCase() {
      int totalDays = 0;
      foreach (Month m in Enum.GetValues(typeof(Month))) {
        switch (m) {
          case FEB:
            totalDays += isLeapYear(DateTime.Now.Year) ? 29 : 28;
            break;
          case APR:
          case JUN:
          case SEP:
          case NOV:
            totalDays += 30;
            break;
          default:
            totalDays += 31;
            break;
        }
      }
      return totalDays;
    }

    [Benchmark]
    public int useLookup() {
      int totalDays = 0;
      foreach (Month m in Enum.GetValues(typeof(Month))) {
        totalDays += NoOfDaysDict[m];
      }
      return totalDays;
    }

    [Benchmark]
    public int useLookup2() {
      int totalDays = 0;
      for (Month m = JAN; m <= DEC; m++) {
        totalDays += NoOfDaysDict[m];
      }
      return totalDays;
    }

    [Benchmark]
    public int useLookupFromArray() {
      int totalDays = 0;
      for (Month m = JAN; m <= DEC; m++) {
        totalDays += NoOfDays[(int)m];
      }
      return totalDays;
    }

    //void Main() {
    //  Console.WriteLine("useSwitchCase:" + useSwitchCase());
    //  Console.WriteLine("useLookup:" + useLookup());
    //  Console.WriteLine("useLookup2:" + useLookup2());
    //  Console.WriteLine("useLookupFromArray:" + useLookupFromArray());
    //}
  }
}
/*
|             Method |         Mean |      Error |     StdDev | Ratio |  Gen 0 | Allocated |
|------------------- |-------------:|-----------:|-----------:|------:|-------:|----------:|
|      useSwitchCase | 13,754.31 ns | 138.670 ns | 122.928 ns | 1.000 | 0.2289 |     369 B |
|          useLookup | 13,201.70 ns | 178.784 ns | 167.235 ns | 0.958 | 0.2289 |     369 B |
|         useLookup2 |    441.81 ns |   5.831 ns |   4.869 ns | 0.032 |      - |         - |
| useLookupFromArray |     14.21 ns |   0.366 ns |   0.796 ns | 0.001 |      - |         - |
*/

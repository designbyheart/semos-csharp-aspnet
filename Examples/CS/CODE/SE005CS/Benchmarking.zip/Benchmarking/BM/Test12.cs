﻿//ByVal Vs ByRef
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test12 {
    struct Rec {
      public int v1;
      public double v2;
      public long v3;
      public float v4;
      public double v5, v6, v7, v8, v9, v10;
      public Rec(int v1, double v2, long v3, float v4) {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.v4 = v4;
        v5 = v6 = v7 = v8 = v9 = v10 = 0;
      }
    }
    static void ByValue(Rec rec1, Rec rec2) {
      var v = rec1.v3 + rec2.v3;
    }
    static void ByRef(ref Rec rec1, ref Rec rec2) {
      var v = rec1.v3 + rec2.v3;
    }
    Rec r1 = new Rec(100, 200, 3000, 400);
    Rec r2 = new Rec(100, 200, 3000, 400);

    [Benchmark(Baseline = true)]
    public void passByValue() {
      for(var i=0;i<100_000;i++) ByValue(r1, r2);
    }

    [Benchmark]
    public void passByReference() {
      for (var i = 0; i < 100_000; i++) ByRef(ref r1, ref r2);
    }
  }
}
/*
| Method | Mean | Error | StdDev | Median | Ratio | RatioSD | Allocated |
| ---------------- | ----------:| ----------:| ----------:| -------:| ------:| --------:| ----------:|
| passByValue | 0.0124 ns | 0.0225 ns | 0.0251 ns | 0.0 ns |     ? |       ? | - |
| passByReference | 0.0000 ns | 0.0000 ns | 0.0000 ns | 0.0 ns |     ? |       ? | - |
 */ 
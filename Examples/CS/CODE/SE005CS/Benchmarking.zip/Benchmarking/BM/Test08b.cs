﻿//ArrayList vs Generic List
using System.Collections;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test08b {
    [Params(10, 100, 1_000)]
    public int Size { get; set; }

    ArrayList list1;
    List<int> list2;

    [GlobalSetup]
    public void Setup() {
      list1 = new ArrayList();
      list2 = new List<int>();
    }

    [Benchmark(Baseline = true)]
    public void useArrayList() {
      int total = 0;
      list1.Clear();
      for (int i = 0; i < Size; i++) list1.Add(i);
      foreach (var item in list1) total += (int)item;
    }

    [Benchmark]
    public void useGenericList() {
      int total = 0;
      list2.Clear();
      for (int i = 0; i < Size; i++) list2.Add(i);
      foreach (var item in list2) total += item;
    }
  }
}
/*
|         Method | Size |        Mean |       Error |      StdDev |      Median | Ratio | RatioSD |  Gen 0 | Allocated |
|--------------- |----- |------------:|------------:|------------:|------------:|------:|--------:|-------:|----------:|
|   useArrayList |   10 |    569.6 ns |    11.45 ns |    21.79 ns |    563.9 ns |  1.00 |    0.00 | 0.0935 |     148 B |
| useGenericList |   10 |    254.3 ns |     5.13 ns |    13.96 ns |    248.7 ns |  0.46 |    0.03 |      - |         - |
|                |      |             |             |             |             |       |         |        |           |
|   useArrayList |  100 |  5,601.5 ns |   326.01 ns |   961.25 ns |  5,697.0 ns |  1.00 |    0.00 | 0.7782 |   1,230 B |
| useGenericList |  100 |  1,725.0 ns |    31.73 ns |    57.22 ns |  1,726.8 ns |  0.36 |    0.05 |      - |         - |
|                |      |             |             |             |             |       |         |        |           |
|   useArrayList | 1000 | 42,515.7 ns | 1,023.76 ns | 2,819.74 ns | 41,649.4 ns |  1.00 |    0.00 | 7.6294 |  12,046 B |
| useGenericList | 1000 | 16,076.5 ns |   303.44 ns |   349.44 ns | 16,111.8 ns |  0.37 |    0.03 |      - |         - |
 */

﻿//Using StringBuilder
using System.Text;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test14 {
    [Params(100, 1000, 10_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
    }

    [Benchmark(Baseline = true)]
    public void useStringConcatenation() {
      string s = "";
      for (int i = 0; i < Size; i++) s += i;
    }

    [Benchmark]
    public void useStringBuilder() {
      StringBuilder sb = new StringBuilder("");
      for (int i = 0; i < Size; i++) sb.Append(i);
      string s = sb.ToString();
    }
    //void Main() {
    //  string s = "";
    //  for (int i = 0; i < 100; i++) s += i;
    //  System.Console.WriteLine(s);
    //  System.Console.WriteLine("Length:{0}",s.Length);

    //  StringBuilder sb = new StringBuilder("");
    //  for (int i = 0; i < 100; i++) sb.Append(i);
    //  s = sb.ToString();
    //  System.Console.WriteLine(s);
    //  System.Console.WriteLine("Length:{0}", s.Length);
    //}
  }

}

/*
                 Method |  Size |         Mean |        Error |       StdDev | Ratio | RatioSD |       Gen 0 |  Allocated |
|----------------------- |------ |-------------:|-------------:|-------------:|------:|--------:|------------:|-----------:|
| useStringConcatenation |   100 |     32.23 us |     0.639 us |     1.136 us |  1.00 |    0.00 |     13.8550 |      21 KB |
|       useStringBuilder |   100 |     18.68 us |     0.373 us |     0.672 us |  0.58 |    0.02 |      1.9226 |       3 KB |
|                        |       |              |              |              |       |         |             |            |
| useStringConcatenation |  1000 |    927.90 us |    18.547 us |    28.324 us |  1.00 |    0.00 |   1796.8750 |   2,769 KB |
|       useStringBuilder |  1000 |    205.62 us |     3.444 us |     5.561 us |  0.22 |    0.01 |     21.7285 |      34 KB |
|                        |       |              |              |              |       |         |             |            |
| useStringConcatenation | 10000 | 98,316.16 us | 1,953.246 us | 4,120.060 us |  1.00 |    0.00 | 238200.0000 | 372,151 KB |
|       useStringBuilder | 10000 |  2,216.88 us |    43.062 us |    71.947 us |  0.02 |    0.00 |    246.0938 |     386 KB |
 */ 
﻿//Lookup Tables Exercise
//Challange: Total up first 50 positive prime numbers
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test34Ex {
    [Params(50)]
    public int Size { get; set; }
    
    static List<long> primes = new List<long>();
    
    [GlobalSetup]
    public void Setup() {
      long p = 0;
      for (var i = 0; i < 100; i++) {
        while (!isPrime(p)) p++;
        primes.Add(p++);
      }
    }

    static bool isPrime(long n) {
      long x;
      if (n < 0) n = -n;
      for (x = 2; (x < n) && ((n % x) != 0); x++) ;
      return x == n;
    }

    [Benchmark(Baseline = true)]
    public void withOutLookUp() {
      long p = 0, total = 0;
      for (var i = 0; i < Size; i++) {
        while (!isPrime(p)) p++;
        total += p++;
      }
      //System.Console.WriteLine("withOutLookUp():{0}", total);//First 50 positive primes total is 5517
    }

    [Benchmark]
    public void withLookUp() {
      long total = 0;
      for (var i = 0; i < Size; i++) total += primes[i];
      //System.Console.WriteLine("withLookUp():{0}", total);
    }

    //void Main() {
    //  Setup();
    //  Size = 50;
    //  withOutLookUp();
    //  withLookUp();
    //}
  }
}

﻿//Conventional for Vs foreach
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test01 {
    int[] data;

    [Params(100, 1_000, 20_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
      data = new int[Size];
    }

    [Benchmark(Description="for()",Baseline = true)]
    public void useFor() {
      int v = 0;
      for (int i = 0; i < data.Length; i++) {
        v += data[i];
      }
    }

    [Benchmark]
    public void useForEach() {
      int v = 0;
      foreach (var item in data) {
        v += item;
      }
    }
  }
}
/*
| Method      | Size    | Mean          | Error       | StdDev        | Median        | Ratio   | RatioSD   | Allocated   |
| ----------- | ------  | -------------:| -----------:| -------------:| -------------:| ------: | --------: | ----------: |
|      for () | 100     | 62.72 ns      | 2.443 ns    | 7.089 ns      | 61.54 ns      | 1.00    | 0.00      | -           |
| useForEach  | 100     | 70.04 ns      | 3.470 ns    | 10.177 ns     | 68.10 ns      | 1.13    | 0.21      | -           |
|             |         |               |             |               |               |         |           |             |
|      for () | 1000    | 408.66 ns     | 17.413 ns   | 50.796 ns     | 389.98 ns     | 1.00    | 0.00      | -           |
| useForEach  | 1000    | 544.12 ns     | 20.364 ns   | 58.427 ns     | 524.91 ns     | 1.35    | 0.21      | -           |
|             |         |               |             |               |               |         |           |             |
|      for () | 20000   | 7,746.05 ns   | 256.299 ns  | 731.236 ns    | 7,374.16 ns   | 1.00    | 0.00      | -           |
| useForEach  | 20000   | 10,761.94 ns  | 557.221 ns  | 1,607.709 ns  | 10,427.69 ns  | 1.39    | 0.24      | -           |
*/

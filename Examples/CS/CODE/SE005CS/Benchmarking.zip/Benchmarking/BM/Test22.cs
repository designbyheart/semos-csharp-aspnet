﻿//Class Vs Struct
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test22 {
    class C1 {//Reference Type
      double r;
      public C1(double r) { Radius = r; }
      public double Radius{
        get {
          return r;
        }
        set {
          if (value < 0) throw new Exception("Radius can't be -ve!");
          r = value;
        }
      }
      public double Area { get { return Math.PI * r * r; } }
      public double Circumference { get { return 2 * Math.PI * r; } }
      public override string ToString() {
        return String.Format("Radius:{0:F2} Area:{1:F2} Circumference:{2:F2}",
          Radius,Area,Circumference);
      }
    }
    struct C2 {//Value Type
      double r;
      public C2(double r) {
        this.r = 0;
        Radius = r; 
      }
      public double Radius {
        get {
          return r;
        }
        set {
          if (value < 0) throw new Exception("Radius can't be -ve!");
          r = value;
        }
      }
      public double Area { get { return Math.PI * r * r; } }
      public double Circumference { get { return 2 * Math.PI * r; } }
      public override string ToString() {
        return String.Format("Radius:{0:F2} Area:{1:F2} Circumference:{2:F2}",
          Radius, Area, Circumference);
      }
    }
    [Params(10, 100, 1000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
    }

    [Benchmark(Baseline = true)]
    public void useClass() {
      for (var i = 0; i < Size; i++) {
        var c1 = new C1(100);
        double area = c1.Area;
        double circumference = c1.Circumference;
      }
    }

    [Benchmark]
    public void useStruct() {
      for (var i = 0; i < Size; i++) {
        var c2 = new C2(100);
        double area = c2.Area;
        double circumference = c2.Circumference;
      }
    }

    //void Main() {
    //  //var c1 = new C1(10);
    //  var c1 = new C2(10);
    //  var c1x = c1;

    //  c1x.Radius = 20;
    //  Console.WriteLine(c1);
    //  Console.WriteLine(c1x);
    //}
  }
}
/*
|    Method | Size |        Mean |      Error |     StdDev | Ratio |   Gen 0 | Allocated |
|---------- |----- |------------:|-----------:|-----------:|------:|--------:|----------:|
|  useClass |   10 |    96.91 ns |   1.970 ns |   1.934 ns |  1.00 |  0.1018 |     160 B |
| useStruct |   10 |    11.38 ns |   0.244 ns |   0.300 ns |  0.12 |       - |         - |
|           |      |             |            |            |       |         |           |
|  useClass |  100 |   973.14 ns |  15.322 ns |  14.332 ns |  1.00 |  1.0185 |   1,602 B |
| useStruct |  100 |    94.84 ns |   1.719 ns |   1.523 ns |  0.10 |       - |         - |
|           |      |             |            |            |       |         |           |
|  useClass | 1000 | 9,315.19 ns | 182.242 ns | 216.947 ns |  1.00 | 10.1776 |  16,024 B |
| useStruct | 1000 |   733.11 ns |  10.351 ns |   8.644 ns |  0.08 |       - |         - |
*/

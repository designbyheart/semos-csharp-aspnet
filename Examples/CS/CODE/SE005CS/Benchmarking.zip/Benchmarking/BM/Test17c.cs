﻿//Array Vs List accessing
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test17c {
    [Params(100, 1000, 10_000)]
    public int Size { get; set; }

    int[] arr;
    List<int> list;
    [GlobalSetup]
    public void Setup() {
      arr = new int[Size];
      list = new List<int>(arr);
    }

    [Benchmark(Baseline = true)]
    public void arrAccess() {
      int total = 0;
      for (int i = 0; i < arr.Length; i++) total += arr[i];
    }

    [Benchmark]
    public void listAccess() {
      int total = 0;
      for (int i = 0; i < list.Count; i++) total += list[i];
    }
  }
}
/*
| Method      | Size    | Mean          | Error       | StdDev        | Median        | Ratio   | RatioSD   | Allocated   |
| ----------- | ------  | -------------:| -----------:| -------------:| -------------:| ------: | --------: | ----------: |
| arrAccess   |   100   |     54.51 ns  |   1.121 ns  |     1.534 ns  |     54.07 ns  | 1.00    | 0.00      | -           |
| listAccess  |   100   |    120.53 ns  |   2.459 ns  |     5.294 ns  |    119.07 ns  | 2.26    | 0.13      | -           |
|             |         |               |             |               |               |         |           |             |
| arrAccess   |  1000   |    398.49 ns  |   8.801 ns  |    24.092 ns  |    390.43 ns  | 1.00    | 0.00      | -           |
| listAccess  |  1000   |  1,243.95 ns  |  57.779 ns  |   166.706 ns  |  1,186.94 ns  | 3.13    | 0.45      | -           |
|             |         |               |             |               |               |         |           |             |
| arrAccess   | 10000   |  3,841.27 ns  | 120.192 ns  |   329.024 ns  |  3,772.57 ns  | 1.00    | 0.00      | -           |
| listAccess  | 10000   | 12,481.15 ns  | 526.444 ns  | 1,484.845 ns  | 12,200.68 ns  | 3.25    | 0.47      | -           |
*/

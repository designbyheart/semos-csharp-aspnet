﻿//Generic List initial internal buffer size
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test15 {
    [Params(100, 1000, 10_000)]
    public int Size { get; set; }

    [GlobalSetup]
    public void Setup() {
    }

    [Benchmark(Baseline = true)]
    public void useDefaultSize() {
      List<int> items = new List<int>();
      for (int i = 0; i < Size; i++) items.Add(i);
      items.TrimExcess();
    }

    [Benchmark]
    public void initialzedBufferSize() {
      List<int> items = new List<int>(Size);
      for (int i = 0; i < Size; i++) items.Add(i);
      items.TrimExcess();
    }
  }
}
/*
|               Method |  Size |        Mean |       Error |      StdDev |      Median | Ratio | RatioSD |   Gen 0 | Allocated |
|--------------------- |------ |------------:|------------:|------------:|------------:|------:|--------:|--------:|----------:|
|       useDefaultSize |   100 |    810.0 ns |    25.49 ns |    72.73 ns |    778.5 ns |  1.00 |    0.00 |  0.7019 |   1,106 B |
| initialzedBufferSize |   100 |    470.5 ns |    25.28 ns |    69.21 ns |    443.3 ns |  0.59 |    0.11 |  0.2775 |     437 B |
|                      |       |             |             |             |             |       |         |         |           |
|       useDefaultSize |  1000 | 10,279.1 ns |   659.69 ns | 1,945.12 ns | 10,658.2 ns |  1.00 |    0.00 |  5.2795 |   8,321 B |
| initialzedBufferSize |  1000 |  5,204.9 ns |   474.28 ns | 1,390.98 ns |  4,420.7 ns |  0.54 |    0.28 |  2.5635 |   4,043 B |
|                      |       |             |             |             |             |       |         |         |           |
|       useDefaultSize | 10000 | 94,686.4 ns | 1,883.82 ns | 4,929.63 ns | 93,635.5 ns |  1.00 |    0.00 | 83.2520 | 131,396 B |
| initialzedBufferSize | 10000 | 70,930.7 ns | 1,409.42 ns | 3,123.17 ns | 70,647.7 ns |  0.75 |    0.05 | 24.9023 |  40,229 B |
 */

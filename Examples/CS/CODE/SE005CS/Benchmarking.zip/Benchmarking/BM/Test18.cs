﻿//Using String.Compare method
using System;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test18 {
    string s1 = "Hyderabad";
    string s2 = "hyderabad";
    [Benchmark(Baseline = true)]
    public void toLower() {
      for (var i = 0; i < 1_000; i++) {
        if (s1.ToLower() == s2.ToLower()) {
        }
      }
    }

    [Benchmark]
    public void compare() {
      for (var i = 0; i < 1_000; i++) {
        if (String.Compare(s1, s2, true) == 0) {
        }
      }
    }
  }
}
/*
|  Method |     Mean |    Error |    StdDev |   Median | Ratio | RatioSD |  Gen 0 | Allocated |
|-------- |---------:|---------:|----------:|---------:|------:|--------:|-------:|----------:|
| toLower | 591.2 ns | 37.62 ns | 110.92 ns | 601.7 ns |  1.00 |    0.00 | 0.0405 |      64 B |
| compare | 255.3 ns | 13.83 ns |  39.90 ns | 240.0 ns |  0.45 |    0.14 |      - |         - |
 */

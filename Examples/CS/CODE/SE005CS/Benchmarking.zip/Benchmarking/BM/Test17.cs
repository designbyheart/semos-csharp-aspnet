﻿// Using proper collections: Insert
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test17 {
    List<int> list;
    LinkedList<int> linkedList;
    [Params(1_000, 10_000, 100_000)]
    public int Size { get; set; }

    //[GlobalSetup]
    [IterationSetup]  //Collection items changed for each iteration
    public void Setup() {
      list = new List<int>();
      linkedList = new LinkedList<int>();
      for (var i = 0; i < Size; i++) {
        list.Add(i);
        linkedList.AddLast(i);
      }
    }

    [Benchmark]
    public void insertFrontList() {
      list.Insert(0, 100);
    }

    [Benchmark]
    public void insertFrontLinkedList() {
      linkedList.AddFirst(100);
    }

    [Benchmark]
    public void insertBackList() {
      list.Add(100);
    }

    [Benchmark]
    public void insertBackLinkedList() {
      linkedList.AddLast(100);
    }
  }
}
/*
|                Method |   Size |        Mean |       Error |      StdDev |      Median | Allocated |
|---------------------- |------- |------------:|------------:|------------:|------------:|----------:|
|       insertFrontList |   1000 |  1,570.7 ns |   159.47 ns |    449.8 ns |  1,500.0 ns |         - |
| insertFrontLinkedList |   1000 |  4,364.0 ns | 1,049.73 ns |  3,095.1 ns |  2,600.0 ns |         - |
|        insertBackList |   1000 |    445.9 ns |    66.80 ns |    194.9 ns |    400.0 ns |         - |
|  insertBackLinkedList |   1000 |  4,521.2 ns | 1,032.82 ns |  3,029.1 ns |  3,000.0 ns |         - |
|       insertFrontList |  10000 |  7,142.4 ns |   916.15 ns |  2,584.0 ns |  7,000.0 ns |         - |
| insertFrontLinkedList |  10000 |  2,855.3 ns |   383.25 ns |  1,093.4 ns |  2,750.0 ns |         - |
|        insertBackList |  10000 |    531.6 ns |    76.64 ns |    219.9 ns |    500.0 ns |         - |
|  insertBackLinkedList |  10000 |  2,657.7 ns |   311.05 ns |    902.4 ns |  2,500.0 ns |         - |
|       insertFrontList | 100000 | 54,633.7 ns | 4,437.94 ns | 12,517.3 ns | 49,700.0 ns |         - |
| insertFrontLinkedList | 100000 |  2,973.7 ns |   233.40 ns |    677.1 ns |  2,750.0 ns |         - |
|        insertBackList | 100000 |    568.7 ns |    91.34 ns |    267.9 ns |    500.0 ns |         - |
|  insertBackLinkedList | 100000 |  2,825.8 ns |   221.66 ns |    628.8 ns |  2,700.0 ns |         - |
*/
﻿//Overloading Vs Optional parameters Vs ParamArray
using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test11 {
    static double Sum1(double x = 0, double y = 0, double z = 0) {
      return x + y + z;
    }
    static double Sum2(double x, double y, double z) {
      return x + y + z;
    }
    static double Sum2(double x, double y) {
      return x + y;
    }
    static double Sum2(double x) {
      return x;
    }
    static double Sum2() {
      return 0;
    }

    static double Sum3(params double[] items) {
      double result = 0;
      foreach (double item in items) result += item;
      return result;
    }

    [Benchmark(Baseline = true)]
    public void useOptionalParameter() {
      Sum1(1, 2, 3);
      Sum1(1, 2);
      Sum1(1);
      Sum1();
    }

    [Benchmark]
    public void useOverloading() {
      Sum2(1, 2, 3);
      Sum2(1, 2);
      Sum2(1);
      Sum2();
    }

    [Benchmark]
    public void useParamArray() {
      Sum3(1, 2, 3);
      Sum3(1, 2);
      Sum3(1);
      Sum3();
    }
  }
}
/*
|               Method |       Mean |     Error |    StdDev |     Median | Ratio | RatioSD |  Gen 0 | Allocated |
|--------------------- |-----------:|----------:|----------:|-----------:|------:|--------:|-------:|----------:|
| useOptionalParameter |  0.0710 ns | 0.0615 ns | 0.1774 ns |  0.0000 ns |     ? |       ? |      - |         - |
|       useOverloading |  0.0654 ns | 0.0455 ns | 0.0843 ns |  0.0299 ns |     ? |       ? |      - |         - |
|        useParamArray | 72.1196 ns | 1.4954 ns | 3.5249 ns | 71.5219 ns |     ? |       ? | 0.0762 |     120 B | 
*/ 
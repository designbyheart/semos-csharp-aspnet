﻿//Using Dictionary
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test16 {
    [Params(100, 1_000, 10_0000)]
    public int Size { get; set; }

    List<int> list;
    Dictionary<int, int> dict;
    [GlobalSetup]
    public void Setup() {
      list = new List<int>();
      dict = new Dictionary<int, int>();
      for (var i = 0; i < Size; i++) {
        list.Add(i);
        dict[i] = i;
      }
    }

    int result;
    [Benchmark(Baseline = true)]
    public void serchByList() {
      result = list.Find(e => e == (0)) +
               list.Find(e => e == (Size / 2)) +
               list.Find(e => e == (Size - 1));
    }

    [Benchmark]
    public void serchByDictionary() {
      result = dict[0] + dict[Size / 2] + dict[Size - 1];
    }
  }
}
/*
|            Method |   Size |          Mean |         Error |        StdDev |  Gen 0 | Allocated |
|------------------ |------- |--------------:|--------------:|--------------:|-------:|----------:|
|       serchByList |    100 |   1,018.14 ns |     20.279 ns |     28.428 ns | 0.0401 |      64 B |
| serchByDictionary |    100 |      88.77 ns |      1.849 ns |      3.287 ns |      - |         - |
|       serchByList |   1000 |   9,044.14 ns |    176.080 ns |    330.722 ns | 0.0305 |      64 B |
| serchByDictionary |   1000 |      88.24 ns |      1.782 ns |      4.536 ns |      - |         - |
|       serchByList | 100000 | 881,587.05 ns | 17,142.343 ns | 25,127.024 ns |      - |      72 B |
| serchByDictionary | 100000 |      88.74 ns |      1.826 ns |      2.619 ns |      - |         - |
 */

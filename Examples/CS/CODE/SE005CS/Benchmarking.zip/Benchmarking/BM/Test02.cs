﻿//IEnumerable, yield return and foreach
using System;
using System.Collections.Generic;

using BenchmarkDotNet.Attributes;

namespace BM {
  [MemoryDiagnoser]
  public class Test02 {
    [Params(10, 100, 1_000)]
    public int Size { get; set; }

    int[] data;
    [GlobalSetup]
    public void Setup() {
      data = new int[Size];
      for (int i = 0; i < data.Length; i++) data[i] = i;
    }

    static List<int> Even1(int[] data) {
      List<int> items = new List<int>();
      foreach (var item in data) {
        if ((item % 2) == 0) {
          //Console.Write("*");
          items.Add(item);
        }
      }
      return items;
    }
    static IEnumerable<int> Even2(int[] data) {
      foreach (var item in data) {
        if ((item % 2) == 0) {
          //Console.Write("*");
          yield return item;
        }
      }
    }

    [Benchmark(Baseline = true)]
    public void useList() {
      int n = 0;
      foreach (var item in Even1(data)) {
        n += item;
      }
    }

    [Benchmark]
    public void useYieldReturn() {
      int n = 0;
      foreach (var item in Even2(data)) {
        n += item;
      }
    }

    //void Main() {
    //  int[] data = { 4, 1, 5, 6, 8, 9, 0, 2, 7 };
    //  Console.Write("Even1():");
    //  foreach (var item in Even1(data)) Console.Write("{0}\t", item);
    //  Console.Write("\nEven2():");
    //  foreach (var item in Even2(data)) Console.Write("{0}\t", item);
    //}
  }
}
/*

|         Method | Size |        Mean |      Error |     StdDev |      Median | Ratio | RatioSD |  Gen 0 | Allocated |
|--------------- |----- |------------:|-----------:|-----------:|------------:|------:|--------:|-------:|----------:|
|        useList |   10 |   192.90 ns |  10.999 ns |  31.382 ns |   192.82 ns |  1.00 |    0.00 | 0.0610 |      96 B |
| useYieldReturn |   10 |    94.72 ns |   7.519 ns |  21.693 ns |    87.86 ns |  0.50 |    0.14 | 0.0229 |      36 B |
|                |      |             |            |            |             |       |         |        |           |
|        useList |  100 | 1,263.44 ns | 141.393 ns | 416.901 ns | 1,170.85 ns |  1.00 |    0.00 | 0.3691 |     581 B |
| useYieldReturn |  100 |   484.91 ns |   9.683 ns |   8.584 ns |   483.57 ns |  0.34 |    0.10 | 0.0229 |      36 B |
|                |      |             |            |            |             |       |         |        |           |
|        useList | 1000 | 5,622.44 ns | 265.087 ns | 752.008 ns | 5,338.07 ns |  1.00 |    0.00 | 2.6703 |   4,207 B |
| useYieldReturn | 1000 | 5,059.55 ns | 273.228 ns | 797.020 ns | 4,677.44 ns |  0.92 |    0.19 | 0.0229 |      36 B |
 */

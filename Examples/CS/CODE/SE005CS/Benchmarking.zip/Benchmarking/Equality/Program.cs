﻿using System;

namespace Equality {
  class Circle {
    private double _r;
    public Circle(double r) {
      Radius = r;
    }
    public double Radius {
      get {
        return _r;
      }
      set {
        if (value < 0) throw new Exception("Radius must be >=0!");
        _r = value;
      }
    }
    public double Area {
      get { return Math.PI * _r * _r; }
    }
    public double Circumference {
      get { return 2 * Math.PI * _r; }
    }
    override public string ToString() {
      return String.Format("Radius:{0:F2} Area:{1:F2} Circumference:{2:F2}",
        Radius, Area, Circumference);
    }
    public override bool Equals(object obj) {
      Circle rhs = obj as Circle;
      return _r==rhs._r;
    }
    static public bool operator ==(Circle lhs, Circle rhs) {
      return (lhs.Radius == rhs.Radius);
    }
    static public bool operator !=(Circle lhs, Circle rhs) {
      return (lhs.Radius != rhs.Radius);
    }
  }
  class Program {
    static void Main(string[] args) {
      Circle c1 = new Circle(10);
      Circle c2 = c1;
      Circle c3 = new Circle(10);
      Console.WriteLine("c1=>{0}", c1);
      Console.WriteLine("c2=>{0}", c2);
      Console.WriteLine("c3=>{0}", c3);
      Console.WriteLine("c1==c2:{0}", (c1 == c2));
      Console.WriteLine("c1==c3:{0}", (c1 == c3));
      Console.WriteLine("c1.Equals(c3):{0}", (c1.Equals(c3)));
      Console.WriteLine("Circle.ReferenceEquals(c1,c3):{0}", Circle.ReferenceEquals(c1,c3));
    }
  }
}

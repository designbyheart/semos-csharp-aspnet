﻿using System;
using Benchmarking;
namespace ExD202 {
  class Program {

    static void Main(string[] args) {
      const uint NoOfIteration = 1_000_000;
      double x = 100;
      Console.WriteLine("Math.Pow(x, 2) is {0}", Math.Pow(x, 2));
      Console.WriteLine("x * x is {0}", x * x);
      Profiler.Profile("Math.Pow(x, 2)", NoOfIteration, () => {
        double result = Math.Pow(x, 2);
      });
      Profiler.Profile("x * x", NoOfIteration, () => {
        double result = x * x;
      });
    }
  }
}

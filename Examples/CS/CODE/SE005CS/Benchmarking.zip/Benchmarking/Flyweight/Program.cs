﻿/*-------------------------------------------------------------------------------------------------------------------------------------------------
Provides a unified interface to a set of interfaces in a subsystem. Façade defines a higher-level 
interface that makes the subsystem easier to use.

This structural code demonstrates the Facade pattern which provides a simplified and uniform 
interface to a large subsystem of classes.
-------------------------------------------------------------------------------------------------------------------------------------------------*/
using System;
using System.Collections.Generic;

namespace FlyWeight{
  class Program{
    static void Main(){
      //Arbitrary extrinsic state 
      int extrinsicstate = 22;

      FlyweightFactory f = new FlyweightFactory();

      // Work with different flyweight instances 
      Flyweight fx = f.GetFlyweight("X");
      fx.Operation(--extrinsicstate);

      Flyweight fy = f.GetFlyweight("Y");
      fy.Operation(--extrinsicstate);

      Flyweight fz = f.GetFlyweight("Z");
      fz.Operation(--extrinsicstate);

      UnsharedConcreteFlyweight uf = new UnsharedConcreteFlyweight();

      uf.Operation(--extrinsicstate);
      Console.ReadKey();
    }
  }

  class FlyweightFactory{
    private Dictionary<String,Flyweight> flyweights =
        new Dictionary<String, Flyweight>();
    public FlyweightFactory(){
      flyweights.Add("X", new ConcreteFlyweight());
      flyweights.Add("Y", new ConcreteFlyweight());
      flyweights.Add("Z", new ConcreteFlyweight());
    }
    public Flyweight GetFlyweight(string key){
      if (!flyweights.ContainsKey(key)) flyweights.Add(key,new ConcreteFlyweight());
      return flyweights[key];
    }
  }

  abstract class Flyweight{
    public abstract void Operation(int extrinsicstate);
  }

  class ConcreteFlyweight:Flyweight{
    public override void Operation(int extrinsicstate){
      Console.WriteLine("ConcreteFlyweight: " + extrinsicstate);
    }
  }

  class UnsharedConcreteFlyweight:Flyweight{
    public override void Operation(int extrinsicstate){
      Console.WriteLine("UnsharedConcreteFlyweight: " + extrinsicstate);
    }
  }
}
/*=================== OUTPUT ===================
ConcreteFlyweight: 21
ConcreteFlyweight: 20
ConcreteFlyweight: 19
UnsharedConcreteFlyweight: 18
=================================================*/
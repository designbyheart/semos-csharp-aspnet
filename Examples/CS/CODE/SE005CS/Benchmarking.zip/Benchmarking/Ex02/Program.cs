﻿using System;
using System.Collections.Generic;

using Benchmarking;

namespace Ex02 {
  class Program {
    static List<int> Even1(int[] items) {
      List<int> result = new List<int>();
      foreach(var item in items) {
        if ((item % 2) == 0) {
          Console.Write("*");
          result.Add(item);
        }
      }
      return result;
    }
    static IEnumerable<int> Even2(int[] items) {
      foreach (var item in items) {
        if ((item % 2) == 0) {
          Console.Write("*");
          yield return item;
        }
      }
    }
    static void Main(string[] args) {
      int[] data = { 2, 3, 5, 1, 6, 8, 7, 9, 0, 4 };

      foreach (var item in Even1(data)) {
        Console.Write("\t{0}", item);
      }
      Console.WriteLine();
      foreach (var item in Even2(data)) {
        Console.Write("\t{0}", item);
      }
      Console.WriteLine("\nProgram ended...");

      //const uint NoOfIteration = 10_000_000;

      //int counter1, counter2;
      //Profiler.Profile("Even1", NoOfIteration, () => {
      //  foreach (var item in Even1(data)) {
      //    //Console.Write("\t{0}", item);
      //  }
      //}, out counter1);
      //Profiler.Profile("Even2", NoOfIteration, () => {
      //  foreach (var item in Even2(data)) {
      //    //Console.Write("\t{0}", item);
      //  }
      //}, out counter2);
      //Console.WriteLine("Even1 caused {0} times GC activation", counter1);
      //Console.WriteLine("Even2 caused {0} times GC activation", counter2);
    }
  }
}

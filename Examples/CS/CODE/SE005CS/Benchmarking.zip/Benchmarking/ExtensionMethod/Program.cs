﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod {
  static class Utils {
    static public bool IsCountryCode(this string code) {
      string[] codes = {"my","jp","cn","uk","kr" };
      foreach(var c in codes) {
        if (c == code) return true;
      }
      return false;
    }
  }
  class Program {
    static void Main(string[] args) {
      Console.WriteLine(Utils.IsCountryCode("jp"));
      Console.WriteLine("jp".IsCountryCode());
      Console.ReadKey();
    }
  }
}

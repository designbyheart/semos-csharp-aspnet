﻿using System;

namespace BitwiseOperations {
  class Program {
    static void ShowBits(string prompt, int bits) {
      Console.Write("{0}:\t",prompt);
      for(int i = 0; i < 32; i++) {
        Console.Write((bits & 0x80000000) == 0 ? 0 : 1);
        bits <<= 1;
      }
      Console.WriteLine();
    }
    static void Main(string[] args) {
      int x = 3;
      int y = 5;
      //ShowBits("x", x);
      ShowBits("y", y);
      //ShowBits("x&y", x&y);
      //ShowBits("x|y", x|y);
      //ShowBits("x^y", x^y);
      //ShowBits("y>>1", y >> 1);
      //ShowBits("y<<1", y<<1);
      int mask = 6;
      ShowBits("mask", ~mask);
      //ShowBits("SET", y | mask);
      //ShowBits("TOG", y ^ mask);
      //ShowBits("CLR", y & ~mask);

      if ((y & mask)!=0) { } //Test for at least one of the bit is on
      if ((y & mask)==mask) { } //Test for all bits must on


      Console.ReadKey();
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeTown=BayanLepas;

namespace Ipoh {
  class PeterHouse {
    void Peter() {
      HomeTown.House h = new HomeTown.House();
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank {
  class Account {
    public double Balance;
    static public float InterestRate=0.05F;
    public Account(double initAmount) {
      Balance = initAmount;
    }
    public Account() : this(0.0) { }

    public void Withdraw(double amount) {
      Balance = Balance - amount;
    }
    public void Deposit(double amount) {
      Balance = Balance + amount;
    }
    public void Update() {
      Balance = Balance * (1.0 + InterestRate);
    }

  }
  class Program {
    static void Main(string[] args) {
      Account acc1 = new Account(1000);
      Account acc2 = new Account();

      acc1.Withdraw(200);
      acc2.Deposit(100);

      Account.InterestRate = 0.10F;

      acc1.Update();
      acc2.Update();

      Console.WriteLine("acc1.Balance is {0:c}", acc1.Balance);
      Console.WriteLine("acc2.Balance is {0:c}", acc2.Balance);
      Console.ReadKey();
    }
  }
}

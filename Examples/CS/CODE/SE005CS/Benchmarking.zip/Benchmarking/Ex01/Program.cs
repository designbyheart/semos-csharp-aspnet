﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Benchmarking;

namespace Ex01 {
  class Program {
    static void Main(string[] args) {
      const uint NoOfIteration = 1_000_000_000;
      int n = 0;
      Profiler.Profile("use +=", NoOfIteration, () => {
        n += 1;
      });
      Profiler.Profile("use ++", NoOfIteration, () => {
        n++;
      });
      Profiler.Profile("use + 1", NoOfIteration, () => {
        n = n + 1;
      });
      Console.WriteLine("Done! Press any key to end");
      Console.ReadKey();
    }
  }
}

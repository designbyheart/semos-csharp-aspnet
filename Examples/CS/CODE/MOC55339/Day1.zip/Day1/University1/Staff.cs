﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal abstract class Staff : Person {
    public double Salary;

    protected const double EPF_CONTRIBUTION = 0.13;
    public Staff(string name, double salary) : base(name) {
      if (salary < 1500) throw new Exception("Invalid Salary!");
      Salary = salary;
    }
    abstract public double getMonthlySalary();//Operation (WHAT)

    override public int Age {
      set {
        if (value <16) throw new Exception("Too young to be Staff!");
        if (value >60) throw new Exception("Give chance to the young one-lah!");

        base.Age = value;
      }
    }

  }
}

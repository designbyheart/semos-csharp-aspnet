﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal class Clerk: Staff {
    public float  OTRate;
    public ushort OTHours;
    public Clerk(string name, double salary, float otRate):base(name,salary) {
      OTRate = otRate;
      OTHours = 0;
    }

    override public double getMonthlySalary() //Operation (WHAT)
    {
      return (1.0 - EPF_CONTRIBUTION) * Salary + (OTHours * OTRate);  // Method (HOW)
    }
  }
}

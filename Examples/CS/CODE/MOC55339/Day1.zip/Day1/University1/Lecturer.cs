﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal class Lecturer:Staff {
    public float  Allowance;
    public Lecturer(string name, double salary, float allowance):base(name,salary) {
      Allowance = allowance;
    }

    override public double getMonthlySalary() //Operation (WHAT)
    {
      return (1.0 - EPF_CONTRIBUTION) * Salary + Allowance;  // Method (HOW)
    }

  }
}

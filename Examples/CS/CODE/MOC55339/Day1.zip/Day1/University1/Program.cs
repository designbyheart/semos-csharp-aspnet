﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal class Program {

    static void SortStaffByMonthlySalary(Staff[] items) {
      int n = items.Length;
      for(int x=0;x<(n-1);x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (items[y].getMonthlySalary() > items[y + 1].getMonthlySalary()) {
            Staff item = items[y];
            items[y] = items[y + 1];
            items[y+1] = item;
          }
        }
      }
    }

    static void ShowAllStaff(Staff[] allStaff) {
      foreach (var staff in allStaff)
        Console.WriteLine("Name:{0,-10} Monthly Salary:{1:c}",
          staff.Name, staff.getMonthlySalary());
      Console.WriteLine();
    }
    static void Main(string[] args) {
      Staff[] staff2023 = new Staff[]{
        new Lecturer("Peter", 2500, 450),
        new Clerk("Steven", 1800, 25),
        new Manager("Ahmad", 5000, 650),
        new HRManager("Abu", 5000),
        new SalesManager("Ali", 5000, 650, 800, 0),
      };
      ShowAllStaff(staff2023);
      SortStaffByMonthlySalary(staff2023);
      ShowAllStaff(staff2023);
      Console.ReadKey();
    }

    static void Main3(string[] args) {
      Person p = new Person("Alibaba");

      //p.Name = "Abumama";

      Console.Write("Age?>>");
      int age = int.Parse(Console.ReadLine());

      p.Age = age;

      Console.WriteLine("{0}'s age is {1}",p.Name, p.Age);
      Console.ReadKey();
    }

    static void ShowManagerInfo(Manager m) {
      Console.WriteLine("Name:{0,-10} Monthly Salary:{1:c}",
          m.Name, m.getMonthlySalary());
    }
    static void Main2(string[] args) {
      Manager m = new Manager("Ahmad", 5000, 650);
      HRManager hrm = new HRManager("Abu", 5000);
      SalesManager sm = new SalesManager("Ali", 5000, 650, 800, 0);

      ShowManagerInfo(m);

      ShowManagerInfo(hrm);

      sm.MonthlySales = 100_000.00;
      ShowManagerInfo(sm);

      Console.ReadKey();
    }
    static void Main1(string[] args) {
      Student s1 = new Student("Tong Sam Pah", 2.7F);

      Student s2 = new Student();

      Clerk c = new Clerk("Ali", 1500, 25.0F);

    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal class Person:Object {
    public readonly string Name;
    private int _Age;
    virtual public int Age {
      get {
        return _Age;
      }
      set {
        if (value <= 0) throw new Exception("Age too low!");
        if (value > 128) throw new Exception("Is this human?!");

        _Age = value;
      }
    }

    public Person(string name) {
      Name = name;
    }

    //public void ChangeName(string newName) {
    //  Name = newName;
    //}
  }
}

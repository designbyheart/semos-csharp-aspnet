﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace University1 {
  internal class Manager:Staff {
    public float CarAllowance;
    public Manager(string name, double salary, float carAllowance):base(name, salary) {
      CarAllowance = carAllowance;
    }

    override public double getMonthlySalary() //Operation (WHAT)
    {
      return (1.0- EPF_CONTRIBUTION) *Salary + CarAllowance;  // Method (HOW)
    }
  }
}

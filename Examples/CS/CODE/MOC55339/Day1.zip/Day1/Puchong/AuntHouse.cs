﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KualaLangat;

namespace Puchong {
  internal class AuntHouse: House {
    void Auntie() {
    }
  }
}

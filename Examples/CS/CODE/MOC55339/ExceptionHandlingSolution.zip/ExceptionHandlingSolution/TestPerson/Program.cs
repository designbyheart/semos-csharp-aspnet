﻿using System;

namespace TestPerson {
  class Program {
    static void Main(string[] args) {
      Console.Write("Person Name>>");
      String name = Console.ReadLine().Trim().ToUpper();
      Person p = new Person(name);
      while (true) {//Busy loop
        Console.Write("Age>>");
        try {
          byte age = byte.Parse(Console.ReadLine());
          p.Age = age;
          break;//out from while(true)
        } catch (AgeZeroException ex) {
          Console.WriteLine("In the AgeZeroException block");
        } catch (AgeException ex) {
          Console.WriteLine("In the AgeException block");
          Console.WriteLine("The actual exception is {0}", ex.GetType().Name);
        } catch (FormatException ex) {
          Console.WriteLine("In the FormatException block");
        } catch (OverflowException ex) {
          Console.WriteLine("In the OverflowException block");
        } catch (Exception ex) {
          Console.WriteLine("In the Exception block");
          Console.WriteLine("The actual exception is {0}", ex.GetType().Name);
        } finally {
          Console.WriteLine("In the finally block");
        }
        Console.WriteLine("Try again...");
      }
      Console.WriteLine("{0}'s age is {1}", p.Name, p.Age);
      Console.ReadKey();
    }
  }
}
﻿using System;

namespace TestPerson {
  class AgeException:Exception {
    public AgeException(String msg) : base(msg) { }
  }
}

﻿using System;


namespace Rethrow {
  class StaffResign:SomethingBad {
    public readonly String Who;
    public StaffResign(string who) {
      Who = who;
    }
    public override string Message {
      get {
        return Who + " resigned";
      }
    }
  }
}

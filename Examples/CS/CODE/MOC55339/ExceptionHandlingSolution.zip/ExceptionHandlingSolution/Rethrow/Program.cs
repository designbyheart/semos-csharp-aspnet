﻿using System;

namespace Rethrow {
  class Program {
    static void RunCompany() {
      try {
        ManageDepartment();
      } catch (Exception ex) {
        Console.Write("Chairman need to has press conference concerning ");
        Console.WriteLine(ex.Message);
      }
    }
    static void ManageDepartment() {
      for (int stage = 1; stage <= 10; stage++) {
        Console.WriteLine("Project at the stage #{0}", stage);
        try {
          DoProject(stage);
        } catch (StaffResign ex) {
          Console.WriteLine("Department will remove {0}'s payroll record", ex.Who);
        } catch (StaffDie ex) {
          Console.WriteLine("Department will remove {0}'s payroll record", ex.Who);
          Console.WriteLine("Department will organize to collect consolation money for {0}'s family", ex.Who);
          throw ex;//Acknowledge to company level
        }
      }
    }
    static void DoProject(int stage) {
      try {
        switch (stage) {
          case 2: throw new StaffQuarrel("Ali", "Abu");
          case 4: throw new StaffResign("Fatimah");
          case 8: throw new StaffDie("Peter", "too heavy work load");
        }
      } catch (StaffQuarrel ex) {
        Console.WriteLine(ex.Message);
        Console.WriteLine("Project manager try to settle the quarrel between {0} and {1}", ex.Who1, ex.Who2);
      } catch (StaffResign ex) {
        Console.WriteLine(ex.Message);
        Console.WriteLine("Project manager will find other team member take over the job handled by " + ex.Who);
        throw ex;//Acknowlege to the department level
      } catch (StaffDie ex) {
        Console.WriteLine(ex.Message);
        Console.WriteLine("Project manager will get someone to replace");
        throw ex;//Acknowlege to the department level
      } catch (Exception) {
        Console.WriteLine("Project manager will take care other abnormal situations");
      } finally {
        Console.WriteLine("Project stage #{0} completed", stage);
      }
    }
    static void Main(string[] args) {
      RunCompany();
      Console.ReadKey();
    }
  }
}

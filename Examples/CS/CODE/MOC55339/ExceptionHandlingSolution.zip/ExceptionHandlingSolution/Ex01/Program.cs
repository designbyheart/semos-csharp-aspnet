﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01 {
  public class Program {
    /// <summary>
    /// This method implements Euclain's Algoritm
    /// </summary>
    /// <param name="x">Must be > 0</param>
    /// <param name="y">Must be > 0</param>
    /// <returns>Greatest Common Divisor</returns>
    static public ulong GCD(ulong x, ulong y) {
      while (y != 0) {
        ulong oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }

    static public ulong LCM(ulong x, ulong y) {
      return (x * y) / GCD(x, y);
    }

    static void Main(string[] args) {
      ulong n = 60;
      ulong d = 96;
      ulong gcd = GCD(n, d);
      Console.WriteLine("GCD({0},{1})=>{2}", n, d, gcd);
      Console.WriteLine("{0}/{1}=>{2}/{3}", n, d, n / gcd, d / gcd);
      Console.WriteLine("LCM({0},{1})=>{2}", 6, 8, LCM(6,8));
      Console.ReadKey();
    }
  }
}

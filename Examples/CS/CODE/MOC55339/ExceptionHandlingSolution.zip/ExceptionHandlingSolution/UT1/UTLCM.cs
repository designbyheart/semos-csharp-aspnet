﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using Ex01;

namespace UT1 {
  [TestClass]
  public class UTLCM {
    [TestMethod]
    public void TC_LCM_6_8() {
      //Arrange
      ulong x = 6;
      ulong y = 8;
      ulong expected = 24;
      //Act
      ulong actual = Program.LCM(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }
  }
}

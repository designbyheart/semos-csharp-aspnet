﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using Ex01;

namespace UT1 {
  [TestClass]
  public class UTGCD {
    [TestMethod]
    public void TC_GCD_60_96() {
      //Arrange
      ulong n = 60;
      ulong d = 96;
      ulong expected = 12;
      //Act
      ulong actual = Program.GCD(n, d);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void TC_GCD_48_120() {
      //Arrange
      ulong n = 48;
      ulong d = 120;
      ulong expected = 24;
      //Act
      ulong actual = Program.GCD(n, d);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void TC_GCD_7_11() {
      //Arrange
      ulong n = 7;
      ulong d = 11;
      ulong expected = 1;
      //Act
      ulong actual = Program.GCD(n, d);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void TC_GCD_11_7() {
      //Arrange
      ulong n = 11;
      ulong d = 7;
      ulong expected = 1;
      //Act
      ulong actual = Program.GCD(n, d);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void TC_GCD_6_8() {
      //Arrange
      ulong n = 6;
      ulong d = 8;
      ulong expected = 2;
      //Act
      ulong actual = Program.GCD(n, d);
      //Assert
      Assert.AreEqual(expected, actual);
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex02 {
  internal class Program {
    static void OpX() {
      Console.WriteLine("OpX()---1");
      Console.WriteLine("OpX()---2");
      OpY();
      Console.WriteLine("OpX()---3");
      Console.WriteLine("OpX()---4");
    }
    static void OpY() {
      Console.WriteLine("OpY()---1");
      Console.WriteLine("OpY()---2");
      Console.WriteLine("OpY()---3");
      OpZ();
      Console.WriteLine("OpY()---4");
    }
    static void OpZ() {
      Console.WriteLine("OpZ()---1");
      Console.WriteLine("OpZ()---2");
      Console.Write("n?>>");
      int n = int.Parse(Console.ReadLine());
      Console.WriteLine("100/n is {0}", 100 / n);
      Console.WriteLine("OpZ()---3");
      Console.WriteLine("OpZ()---4");
    }

    static void Main(string[] args) {
      Console.WriteLine("Main() started...");
      OpX();
      Console.WriteLine("Main() ending...");
      Console.ReadKey();
    }
  }
}

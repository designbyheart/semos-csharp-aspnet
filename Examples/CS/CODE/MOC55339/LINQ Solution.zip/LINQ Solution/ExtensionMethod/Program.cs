﻿using System;
using System.Linq;

namespace ExtensionMethod {
  static class Utils {
    public static bool IsCountryCode(this string source) {
    //public static bool IsCountryCode(this string source) {
        string[] codes ={
                       "my",
                       "cn",
                       "jp",
                       "us",
                     };
      if(source==null) return false;
      source = source.ToLower();
      foreach (string s in codes) if (source == s) return true;
      return false;
    }
    public static T FirstX<T>(this T[] items, Predicate<T> found) {
      foreach (T item in items) {
        if (found(item)) return item;
      }
      throw new InvalidOperationException("Sequence contains no matching element");
    }
  }

  class Program {
    static void showTest(string code) {
      string format = "You entered: {0}. It is country code: {1}";
      Console.WriteLine(format, code, Utils.IsCountryCode(code));
      Console.WriteLine(format, code, code.IsCountryCode());
    }
    static void Main(string[] args) {
      //showTest("my");


      int[] data = { 6, 2, 3, 4, 5 };
      try {
        //int i;
        //for (i = 0; i < data.Length; i++) {
        //  if ((data[i] % 2) != 0) break;
        //}
        //if (i == data.Length)
        //  throw new InvalidOperationException("Sequence contains no matching element");
        //int odd = data[i];
        var odd = data.FirstX(x => (x % 2) != 0);
        Console.WriteLine("The first odd number is " + odd);
      } 
      catch(Exception ex){
        Console.WriteLine(ex.Message);
      }
      Console.ReadKey();
    }
  }
}

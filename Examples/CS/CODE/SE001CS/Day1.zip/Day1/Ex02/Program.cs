﻿//Floor Divide
using System;

namespace Ex02 {
  internal class Program {
    static void Main(string[] args) {
      int a = 22;
      int b = 7;
      double d = a / (float)b;
      Console.WriteLine("{0:f2}",d);
      Console.ReadKey();
    }
  }
}

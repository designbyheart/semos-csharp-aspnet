﻿//class Vs struct type
using System;

namespace Ex10 {
  struct Circle {//Try change the struct keyword to class and re-run the code
    double r;
    public Circle(double r) {//Constructor
      this.r = 0.0;
      Radius = r;
    }
    public double Area {//Read-only Property
      get { return Math.PI * r * r; }
    }
    public double Circumference {//Read-only Property
      get { return 2 * Math.PI * r; }
    }
    public double Radius {//Read-Write Property
      get { return r; }
      set {
        if (value < 0) throw new Exception("Radius can't must negative!");
        r = value;
      }
    }
    public override string ToString() {//Polymorphic ToString method
      return String.Format("Radius:{0:f2}\nArea:{1:f2}\nCircumerence:{2:f2}", 
        Radius, Area, Circumference);
    }
  }
  class Program {
    static void Main(string[] args) {
      Circle c1 = new Circle(10);
      Circle c2 = c1;//Pay attention to this line

      c2.Radius = 20;
      Console.WriteLine("c1:\n{0}\n", c1);
      Console.WriteLine("c2:\n{0}\n", c2);
      Console.ReadKey();
    }
  }
}

﻿//Iteration and Recursion
using System;
using System.Globalization;

namespace Ex07 {
  internal class Program {
    static ulong Fact1(uint n) {//For loop
      ulong result = 1;
      for (uint i = 2; i <= n; i++) result = result * i; 

      return result;
    }
    static ulong Fact2(uint n) {//Pre-Test Loop
      ulong result = 1;
      while (n > 1) result = result * n--;
      return result;
    }
    static ulong Fact3(uint n) {//Post-Test Loop
      ulong result = 1;
      uint i = 1;
      do {
        result = result * i++;
      } while (i <= n);
      return result;
    }
    static ulong Fact4(uint n) {//Recursion
      return (n < 2) ? 1 : Fact4(n - 1) * n;
    }


    static void Main(string[] args) {
      Console.WriteLine("  n       Fact1(n)          Fact2(n)           Fact3(n)           Fact4(n)      ");
      Console.WriteLine("----- ------------------ ------------------- ------------------- -------------------");
      for (uint i = 0; i <= 13; i++)
        Console.WriteLine("{0,4}{1,20}{2,20}{3,20}{4,20}",
            i, Fact1(i), Fact2(i), Fact3(i), Fact4(i));
      Console.ReadKey();
    }
  }
}

﻿//Value Type
using System;

namespace Ex11 {
  internal class Program {
    static void Main(string[] args) {
      int v1 = -2147483648;  //-2147483648 .. 2147483647
      short v2= -32768; // -32768 .. 32767
      long v3;
      sbyte v4;

      uint v5;
      ushort v6;
      ulong v7;
      byte v8;

      float v9 = 22.0F / 7;
      double v10 = 22.0 / 7;
      decimal v11 = (decimal)22.0 / 7;

      Console.WriteLine("v9:{0}", v9);
      Console.WriteLine("v10:{0}", v10);
      Console.WriteLine("v11:{0}", v11);

      Console.WriteLine("sizeof(float):{0}", sizeof(float));
      Console.WriteLine("sizeof(double):{0}", sizeof(double));
      Console.WriteLine("sizeof(decimal):{0}", sizeof(decimal));
      Console.WriteLine("sizeof(char):{0}", sizeof(char));
      Console.WriteLine("sizeof(bool):{0}", sizeof(bool));
      char name = '\u51CC'; //'凌';

      bool v12 = true;

      Console.ReadKey();
    }
  }
}


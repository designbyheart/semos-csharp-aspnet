﻿using System;
using System.Diagnostics;

namespace Ex13 {
  internal class Program {
    static void Main(string[] args) {
      int x = 22, y = 3;

      //Binary Arithmatic Operators
      Console.WriteLine(x + y);//Addition
      Console.WriteLine(x - y);//Subtraction
      Console.WriteLine(x * y);//Multiplication
      Console.WriteLine(x / y);//Floor Division
      Console.WriteLine(x / (double) y);//Real Division
      Console.WriteLine(x % y);//Modulus

      //Unary Arithmatic Operators
      Console.WriteLine(+x);//??
      Console.WriteLine(-x);//Negation

      //Arithmatic Functions
      Console.WriteLine(Math.Pow(x, y));//Power
      Console.WriteLine(Math.Sqrt(x));


      //Comparison Operators
      // ==  Equals
      // !=  Not Equals to
      // >
      // >=
      // <
      // <=

      //Logical Operators
      // &&   And
      // ||   Or
      // ^    XOr
      Console.WriteLine(true && true);
      Console.WriteLine(true && false);
      Console.WriteLine(false && true);
      Console.WriteLine(false && false);

      Console.WriteLine(true || true);
      Console.WriteLine(true || false);
      Console.WriteLine(false || true);
      Console.WriteLine(false || false);

      Console.WriteLine(true ^ true);
      Console.WriteLine(true ^ false);
      Console.WriteLine(false ^ true);
      Console.WriteLine(false ^ false);

      Console.WriteLine(!true);
      Console.WriteLine(!false);

      x = x + 1;
      x += 1;
      x++;
      ++x;


      x = 10;
      y = x++;
      Console.WriteLine("x:{0}\ty:{1}", x, y);
      y = ++x;
      Console.WriteLine("x:{0}\ty:{1}", x, y);

      int? result=null;

      int finalResult;

      if (result.HasValue)
        finalResult = result.Value;
      else
        finalResult = 0;

      finalResult = result.HasValue ? result.Value : 0;

      finalResult = result ?? 0;


      Console.ReadKey();
    }
  }
}

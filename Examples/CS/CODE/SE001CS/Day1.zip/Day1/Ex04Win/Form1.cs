namespace Ex04Win {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    public static ulong GCD(ulong x, ulong y) {
      while (y != 0) {
        ulong oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }
    private void btnGO_Click(object sender, EventArgs e) {
      ulong x = ulong.Parse(tbX.Text);
      ulong y = ulong.Parse(tbY.Text);
      ulong gcd = GCD(x, y);
      lblGCD.Text = gcd.ToString();
    }
  }
}
﻿namespace Ex04Win {
  partial class Form1 {
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      label1 = new Label();
      tbX = new TextBox();
      label2 = new Label();
      tbY = new TextBox();
      btnGO = new Button();
      lblGCD = new Label();
      SuspendLayout();
      // 
      // label1
      // 
      label1.AutoSize = true;
      label1.Location = new Point(53, 34);
      label1.Name = "label1";
      label1.Size = new Size(17, 15);
      label1.TabIndex = 0;
      label1.Text = "X:";
      // 
      // tbX
      // 
      tbX.Location = new Point(82, 33);
      tbX.Name = "tbX";
      tbX.Size = new Size(188, 23);
      tbX.TabIndex = 1;
      // 
      // label2
      // 
      label2.AutoSize = true;
      label2.Location = new Point(53, 75);
      label2.Name = "label2";
      label2.Size = new Size(17, 15);
      label2.TabIndex = 2;
      label2.Text = "Y:";
      // 
      // tbY
      // 
      tbY.Location = new Point(84, 72);
      tbY.Name = "tbY";
      tbY.Size = new Size(186, 23);
      tbY.TabIndex = 3;
      // 
      // btnGO
      // 
      btnGO.Location = new Point(88, 120);
      btnGO.Name = "btnGO";
      btnGO.Size = new Size(75, 23);
      btnGO.TabIndex = 4;
      btnGO.Text = "GO";
      btnGO.UseVisualStyleBackColor = true;
      btnGO.Click += btnGO_Click;
      // 
      // lblGCD
      // 
      lblGCD.AutoSize = true;
      lblGCD.Location = new Point(94, 173);
      lblGCD.Name = "lblGCD";
      lblGCD.Size = new Size(38, 15);
      lblGCD.TabIndex = 5;
      lblGCD.Text = "label3";
      // 
      // Form1
      // 
      AutoScaleDimensions = new SizeF(7F, 15F);
      AutoScaleMode = AutoScaleMode.Font;
      ClientSize = new Size(587, 330);
      Controls.Add(lblGCD);
      Controls.Add(btnGO);
      Controls.Add(tbY);
      Controls.Add(label2);
      Controls.Add(tbX);
      Controls.Add(label1);
      Name = "Form1";
      Text = "Form1";
      ResumeLayout(false);
      PerformLayout();
    }

    #endregion

    private Label label1;
    private TextBox tbX;
    private Label label2;
    private TextBox tbY;
    private Button btnGO;
    private Label lblGCD;
  }
}
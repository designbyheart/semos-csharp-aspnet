﻿//Debugging and Unit Test
using System;

namespace Ex03 {
  public class Program {
    public static ulong GCD(ulong x, ulong y) {
      while (y!=0){
        ulong oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }
    public static ulong LCM(ulong x, ulong y) {
      return (x * y) / GCD(x, y); 
    }
    static void Main(string[] args) {
      Console.WriteLine("GCD({0},{1}) is {2}", 60,  96, GCD(60,  96));
      /*
       Console.WriteLine("GCD({0},{1}) is {2}", 48, 120, GCD(48, 120));
      //Console.WriteLine("GCD({0},{1}) is {2}",  7,  11, GCD( 7,  11));
      //Console.WriteLine("GCD({0},{1}) is {2}", 11,   7, GCD(11,   7));
      Console.WriteLine("GCD({0},{1}) is {2}",  6,   8, GCD( 6,   8));
      Console.WriteLine("LCM({0},{1}) is {2}",  6,   8, LCM( 6,   8));
      */
      Console.ReadKey();
    }
  }
}

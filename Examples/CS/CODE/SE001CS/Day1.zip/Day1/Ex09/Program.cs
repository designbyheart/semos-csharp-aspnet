﻿//break and continue keywords
using System;

namespace Ex09 {
  internal class Program {
    static void UseContinue() {
      int i;
      for (i = 0; i < 10; i++) {
        if ((i % 2) == 0) continue;
        Console.Write("{0}\t", i);
      }
      Console.WriteLine("\nAfter loop, i is " + i);
    }
    static void UseBreak() {
      int i;
      for (i = 0; i < 10; i++) {
        if (i > 6) break;
        Console.Write("{0}\t", i);
      }
      Console.WriteLine("\nAfter loop, i is " + i);
    }
    static void Main(string[] args) {
      UseContinue();
      UseBreak();
      Console.ReadKey();
    }
  }
}

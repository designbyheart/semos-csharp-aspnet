﻿//checked and unchecked keyword
using System;

namespace Ex12 {
  internal class Program {
    static void Main(string[] args) {
      int i = int.MaxValue;
      Console.WriteLine("Before:{0}", i);
      checked {
        unchecked {
          i = i + 1;
        }
      }
      Console.WriteLine("After:{0}", i);
      Console.ReadKey();
    }
  }
}

﻿//For Loop Exercise
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex08 {
  internal class Program {
    static double FV(double pv, float r, int n) {
      for (int i = 0; i < n; i++) pv = pv * (1.0 + r);
      return pv;
    }

    static void Fibonacci(uint n) {
      if (n > 1) {
        uint x = 0, y = 1;
        for(uint i=0;i<n; i++) {
          Console.Write("{0} ", x);
          y = x + y;
          x = y - x;
        }
        Console.WriteLine();
      }
    }

    static bool IsPrime(long n) {
      if (n < 0) n = -n;
      int x;
      for (x = 2; (x < n) && ((n % x) != 0); x++) ;
      return (x == n);
    }


    static void Main(string[] args) {
      double Saving = 100.00;
      float AnnualRate = 0.05F;

      Console.WriteLine("Year      FV");
      Console.WriteLine("---- -------------");
      for (int year = 0; year <= 10; year++) {
        Console.WriteLine("{0,3}   {1:c}", year, FV(Saving, AnnualRate, year));
      }
      Console.WriteLine("--- Test Fibonacci -----");
      Fibonacci(2);
      Fibonacci(12);
      Fibonacci(1);
      Console.WriteLine("--- Test IsPrime -----");
      for (long n = -10; n<1000; n++)
        if (IsPrime(n)) Console.WriteLine(n);


      Console.ReadKey();
    }
  }
}

﻿//Sequential and Branching Flows
using System;

namespace Ex06 {
  internal class Program {
    static void Seq() {
      Console.WriteLine("---1");
      Console.WriteLine("---2"); Console.WriteLine("---3");
      Console.WriteLine("---4");
    }
    static int Max(int x, int y) {
      if (x > y) 
        return x;
      else 
        return y;
    }
    static int Max2(int x, int y) {
      return (x > y)?x:y;
    }

    static int Abs(int x) {
      if (x < 0) x = -x;
      return x;
    }

    static string WhatToEat1(string sDay) {
      string food = "";
      sDay = sDay.ToUpper();
      if (sDay == "MON")
        food = "Burger";
      else
        if (sDay == "WED")
          food = "Satay";
        else
          if (sDay == "FRI")
            food = "Pizza";
          else
            if ((sDay == "TUE") || (sDay == "THU") ||
                (sDay == "SAT") || (sDay == "SUN"))
              food = "Nasi Lemak";
            else
              Console.WriteLine("Invalid day::" + sDay);
      return food;
    }

    static string WhatToEat2(string sDay) {
      string food = "";
      sDay = sDay.ToUpper();
      switch (sDay) {
        case "MON": food = "Burger";  break;
        case "WED": food = "Satay";   break;
        case "FRI": food = "Pizza";   break;
        case "TUE":
        case "THU":
        case "SAT":
        case "SUN": food = "Nasi Lemak"; break;
        default:
          Console.WriteLine("Invalid day::" + sDay);
          break;
      }
      return food;
    }

    static void Main(string[] args) {
      //Seq();
      //Console.WriteLine(Max(5, 7));
      //Console.WriteLine(Max2(5, 7));

      //Console.WriteLine(Abs(-5));
      //Console.WriteLine(Abs(5));

      string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri",
                        "Sat", "Sun"};
      foreach (var day in days)
        Console.WriteLine("Day:{0}\tFood:{1}\tFood:{2}",
          day, WhatToEat1(day), WhatToEat2(day));

      Console.ReadKey();
    }
  }
}

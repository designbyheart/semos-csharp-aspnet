﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UTEx03 {
  [TestClass]
  public class UTGCD {
    [TestMethod]
    public void GCD_60_96() {
      //Arrange
      ulong x = 60;
      ulong y = 96;
      ulong expected = 12;
      //Act
      ulong actual = Ex03.Program.GCD(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GCD_48_120() {
      //Arrange
      ulong x = 48;
      ulong y = 120;
      ulong expected = 24;
      //Act
      ulong actual = Ex03.Program.GCD(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GCD_7_11() {
      //Arrange
      ulong x = 7;
      ulong y = 11;
      ulong expected = 1;
      //Act
      ulong actual = Ex03.Program.GCD(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GCD_11_7() {
      //Arrange
      ulong x = 11;
      ulong y = 7;
      ulong expected = 1;
      //Act
      ulong actual = Ex03.Program.GCD(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GCD_6_8() {
      //Arrange
      ulong x = 6;
      ulong y = 8;
      ulong expected = 2;
      //Act
      ulong actual = Ex03.Program.GCD(x, y);
      //Assert
      Assert.AreEqual(expected, actual);
    }
  }
}

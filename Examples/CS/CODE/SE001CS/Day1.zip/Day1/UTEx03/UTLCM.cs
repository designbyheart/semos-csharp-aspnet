﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Security.Cryptography.X509Certificates;

namespace UTEx03 {
  [TestClass]
  public class UTLCM {
    [TestMethod]
    public void LCM_6_8() {
      ulong x = 6;
      ulong y = 8;
      ulong expected = 24;

      ulong actual = Ex03.Program.LCM(x, y);

      Assert.AreEqual(expected, actual);
    }
  }
}

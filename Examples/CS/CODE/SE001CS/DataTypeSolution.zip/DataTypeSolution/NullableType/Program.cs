﻿using System;

namespace NullableType {
  class Program {
    static void Main(string[] args) {
      uint? examResult=null;
      uint result=examResult??0;
      //if (examResult.HasValue) {
      //  result = examResult.Value;
      //} else {
      //  result = 0;
      //}
      Console.ReadKey();
    }
  }
}

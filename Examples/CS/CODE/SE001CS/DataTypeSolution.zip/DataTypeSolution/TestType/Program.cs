﻿using System;

namespace TestType {
  class Program {
    static void Main(string[] args) {
      //int n; //-2,147,483,648 .. 2,147,483,647
      //uint n; //0..4,294,967,295
      //n = 12.34;
      //Console.WriteLine("uint is {0} bytes", sizeof(uint));
      int x = 22, y = 7;
      double d = x / (float)y;//C, C++. Java and C# => Floor Divide
      Console.WriteLine("d is {0:f2}", d);
      Console.ReadKey();
    }
  }
}

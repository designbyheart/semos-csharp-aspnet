﻿using System;

namespace TestInteger {
  class Program {
    static void Main(string[] args) {
      int   n = -2_147_483_648;  //-2,147,483,648 .. 2,147,483,647
      //long  n = 9223372036854775807;//-9,223,372,036,854,775,808..9223372036854775807
      //short n = 32767;//-32768 .. 32767
      //byte n = 127;  //-128 .. 127
      Console.WriteLine("n={0}", n);
      Console.ReadKey();
    }
  }
}

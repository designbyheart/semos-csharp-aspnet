﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleValueType {
  class Program {
    static void Main(string[] args) {
      sbyte b1;//-128..127
      int i1;//-2147483648..2147483647
      short i2;//-32768..32767
      long i3;//-9223372036854775808..9223372036854775807

      byte ub1;//0..255
      uint ui1;//0..4294967295
      ushort ui2;//0..65535
      ulong ui3;//0..18446744073709551615

      float f;
      double d;

      bool b=false;

      char c='A';
    }
  }
}

﻿using System;

namespace Overflow {
  class Program {
    static void Main(string[] args) {
      int n = int.MinValue;
      checked {
        n = n - 1;
      }
      Console.WriteLine("n={0}", n);
      Console.ReadKey();
    }
  }
}

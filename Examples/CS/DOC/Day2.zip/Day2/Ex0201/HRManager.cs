﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0201 {
  internal class HRManager:Manager {
    public HRManager(string name, double salary) :
      base(name, salary, 500) { }
  }
}

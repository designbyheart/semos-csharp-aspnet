﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0201 {
  internal class Program {
    static void Main(string[] args) {
      Person p = new Person("Alibaba");
      //p.Name = "Abumama";
      while (true) {
        try {
          Console.Write("Age?>>");
          int age = int.Parse(Console.ReadLine()); 
          p.Age = age;
          Console.WriteLine($"{p.Name}'s Age is {p.Age}");
          break;
        } catch (Exception ex) {
          Console.WriteLine("ERROR::"+ex.Message); 
        }
        Console.WriteLine("Try again....");
      }

      Lecturer lec = new Lecturer("Tong Sam Pah", 2500, 550);
      double monthlySalary = lec.MonthlySalary;
      Console.ReadKey();
    }
  }
}

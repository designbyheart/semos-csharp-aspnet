﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0201 {
  internal abstract class Staff:Person,ISortable {
    public double Salary;
    public Staff(string name, double salary):base(name) {
      if (salary < 1500) throw new Exception("Salary too low!");
      Salary = salary;
    }

    abstract public double MonthlySalary { get; }//Operation

    override public int Age {
      set {
        if (value < 16) throw new Exception("Too young to be Staff!");
        if (value > 60) throw new Exception("Give chance to the young one-lah!");
        base.Age = value;
      }
    }


    public enum SortCriteria { 
      ByName, ByNameDesc,
      ByMonthlySalary, ByMonthlySalaryDesc,
    }

    public bool Swap(object obj, object sortCriteria) {
      Staff lhs = this;
      Staff rhs = obj as Staff;
      switch ((SortCriteria)sortCriteria) {
        case SortCriteria.ByName: return lhs.Name.CompareTo(rhs.Name) > 0;
        case SortCriteria.ByNameDesc: return lhs.Name.CompareTo(rhs.Name) < 0;
        case SortCriteria.ByMonthlySalary:
          return lhs.MonthlySalary > rhs.MonthlySalary;
        case SortCriteria.ByMonthlySalaryDesc:
          return lhs.MonthlySalary < rhs.MonthlySalary;
      }
      throw new NotImplementedException("Missed case:" + sortCriteria);
    }
  }
}

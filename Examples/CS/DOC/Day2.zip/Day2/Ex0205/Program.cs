﻿
using System;
using System.Collections.Generic;

namespace Ex0205 {
  static class Utils {
    static public IEnumerable<T> Filter<T>(this IEnumerable<T> items, Predicate<T> accept) {
      foreach (var item in items) {
        if (accept(item)) yield return item;
      }
    }

  }
  internal class Program {
    //static IEnumerable<T> Filter<T>(IEnumerable<T> items, Predicate<T> accept) {
    //  foreach(var item in items) {
    //    if (accept(item)) yield return item;
    //  }
    //}
    static bool isPrime(int n) {
      int x;
      if (n < 0) n = -n;
      for (x = 2; (x < n) && ((n % x) != 0); x++) ;
      return (x==n);
    }
    static void Main(string[] args) {
      int[] data = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
      Console.Write("ODD:\t");
      //foreach (var item in Filter(data, n => (n % 2) != 0)) {
      foreach (var item in data.Filter(n => (n % 2) != 0)) {
          Console.Write("{0}\t",item);
      }
      Console.WriteLine();
      Console.Write("EVEN:\t");
      //foreach (var item in Filter(data, n => (n % 2) == 0)) {
      foreach (var item in data.Filter(n => (n % 2) == 0)) {
          Console.Write("{0}\t", item);
      }
      Console.WriteLine();
      Console.Write("PRIME:\t");
      //foreach (var item in Filter(data, isPrime)) {
      foreach (var item in data.Filter(isPrime)) {
          Console.Write("{0}\t", item);
      }
      Console.WriteLine();

      List<double> ddata = new List<double>() { 1.5, -3.1, 1.5, -1.1, -3.4 };
      Console.Write("+VE:\t");
      //foreach (var item in Filter(ddata, n => n >= 0)) {
      foreach (var item in data.Filter(n => n >= 0)) {
          Console.Write("{0}\t", item);
      }
      Console.WriteLine();


      Console.ReadKey();
    }
  }
}

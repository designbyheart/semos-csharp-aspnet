﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0202 {
  internal class Person:Object {
    public readonly string Name;
    private int _Age;
    virtual public int Age {
      get { return _Age; }
      set {
        if (value < 1) throw new Exception("Age must >0!");
        if (value >128) throw new Exception("Is this human?!");
        _Age = value; 
      }
    }
    public void ChangeName(string newName) {
      //Name = newName;
    }
    public Person(string name) {
      Name = name;
      /*Another 100 lines of common initialization*/
    }
    public Person() : this("") { }
  }
}

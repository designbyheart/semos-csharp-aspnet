﻿//#define USE_DELEGATE
//#define USE_ANONYMOUS_DELEGATE
//#define USE_LAMBDA
//#define USE_GENERIC
#define USE_GENERIC_FUNC

using System;

namespace Ex0202 {

  internal class Program {
    static void ShowAllStaffInfo(Staff[] allStaff) {
      foreach (var staff in allStaff) {
        Console.WriteLine("Name:{0,-12} Monthly Salary:{1:c}",
          staff.Name, staff.MonthlySalary);
      }
      Console.WriteLine();
    }
    static Staff[] staff2023 = new Staff[] {
        new Lecturer("Peter", 2500, 450),
        new Clerk("Mary", 1800,15),
        new Manager("Ahmad", 5000, 600),
        new HRManager("Abu", 4500),
        new SalesManager("Ali",5000, 600, 800),
    };

#if USE_DELEGATE
    delegate bool Swap(object lhs, object rhs);
    static void Sort(object[] items, Swap swap) {
      int n = items.Length;
      for (int x = 0; x < (n - 1); x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (swap(items[y],items[y + 1])) {
            object item = items[y];
            items[y] = items[y + 1];
            items[y + 1] = item;
          }
        }
      }
    }
    static bool ByMonthlySalary(object lhs, object rhs) {
      return ((Staff)lhs).MonthlySalary > ((Staff)rhs).MonthlySalary; 
    }
    static bool ByMonthlySalaryDesc(object lhs, object rhs) {
      return ((Staff)lhs).MonthlySalary < ((Staff)rhs).MonthlySalary;
    }
    static bool ByName(object lhs, object rhs) {
      return ((Staff)lhs).Name.CompareTo(((Staff)rhs).Name)>0;
    }

    static void Main(string[] args) {
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, ByMonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, ByMonthlySalaryDesc);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, ByName);
      ShowAllStaffInfo(staff2023);

      Console.ReadKey();
    }
#elif USE_ANONYMOUS_DELEGATE
    delegate bool Swap(object lhs, object rhs);
    static void Sort(object[] items, Swap swap) {
      int n = items.Length;
      for (int x = 0; x < (n - 1); x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (swap(items[y],items[y + 1])) {
            object item = items[y];
            items[y] = items[y + 1];
            items[y + 1] = item;
          }
        }
      }
    }
    static void Main(string[] args) {
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, delegate (object lhs, object rhs) { 
        return ((Staff)lhs).MonthlySalary > ((Staff)rhs).MonthlySalary; });
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, delegate (object lhs, object rhs) {
        return ((Staff)lhs).MonthlySalary < ((Staff)rhs).MonthlySalary;
      });
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, delegate (object lhs, object rhs) {
        return ((Staff)lhs).Name.CompareTo(((Staff)rhs).Name) > 0;
      });
      ShowAllStaffInfo(staff2023);

      Console.ReadKey();
    }
#elif USE_LAMBDA
    delegate bool Swap(object lhs, object rhs);
    static void Sort(object[] items, Swap swap) {
      int n = items.Length;
      for (int x = 0; x < (n - 1); x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (swap(items[y],items[y + 1])) {
            object item = items[y];
            items[y] = items[y + 1];
            items[y + 1] = item;
          }
        }
      }
    }
    static void Main(string[] args) {
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>((Staff)lhs).MonthlySalary > ((Staff)rhs).MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>((Staff)lhs).MonthlySalary < ((Staff)rhs).MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>((Staff)lhs).Name.CompareTo(((Staff)rhs).Name) > 0);
      ShowAllStaffInfo(staff2023);

      Console.ReadKey();
    }
#elif USE_GENERIC
    delegate bool Swap<T>(T lhs, T rhs);
    static void Sort<T>(T[] items, Swap<T> swap) {
      int n = items.Length;
      for (int x = 0; x < (n - 1); x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (swap(items[y],items[y + 1])) {
            T item = items[y];
            items[y] = items[y + 1];
            items[y + 1] = item;
          }
        }
      }
    }
    static void Main(string[] args) {
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.MonthlySalary > rhs.MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.MonthlySalary < rhs.MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.Name.CompareTo(rhs.Name) > 0);
      ShowAllStaffInfo(staff2023);

      Console.ReadKey();
    }
#elif USE_GENERIC_FUNC
    static void Sort<T>(T[] items, Func<T, T, bool> swap) {
      int n = items.Length;
      for (int x = 0; x < (n - 1); x++) {
        for (int y = 0; y < (n - 1 - x); y++) {
          if (swap(items[y],items[y + 1])) {
            T item = items[y];
            items[y] = items[y + 1];
            items[y + 1] = item;
          }
        }
      }
    }
    static void Main(string[] args) {
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.MonthlySalary > rhs.MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.MonthlySalary < rhs.MonthlySalary);
      ShowAllStaffInfo(staff2023);
      Sort(staff2023, (lhs, rhs)=>lhs.Name.CompareTo(rhs.Name) > 0);
      ShowAllStaffInfo(staff2023);

      Console.ReadKey();
    }
#else
    static void Main(string[] args) {
    }
#endif
  }
}

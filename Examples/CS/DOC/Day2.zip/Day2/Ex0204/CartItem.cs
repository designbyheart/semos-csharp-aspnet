﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0204 {
  internal class CartItem<T> where T:Product {
    public T Item;
    public uint Quantity;
    public float SubTotal {
      get {
        return Item.Price * Quantity;
      }
    }
    public void Add(uint n = 1) {
      Quantity += n;
    }

    public bool Del(uint n = 1) {
      if (Quantity < n) return false;
      Quantity -= n;
      return true;
    }

    public CartItem(T item, uint quantity=1) {
      Item = item;
      Quantity = quantity;
    }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0204 {
  internal class Program {
    static void Main(string[] args) {
      var books = new Dictionary<string, Book>();
      books["978-1-890-77495-0"] = new Book() {
        ISBN = "978-1-890-77495-0",
        Title = "Murach’s ASP.NET 4.6 web programming with C♯",
        Author = "Mary Delamater, Anne Boehm",
        Year = 2016,
        Publisher = "Publisher",
        Price = 42.33F
      };
      books["978-1-430-22611-6"] = new Book() {
        ISBN = "978-1-430-22611-6",
        Title = "Beginning ASP.NET 4 in C# 2010",
        Author = "Matthew MacDonald",
        Year = 2010,
        Publisher = "Apress",
        Price = 54.99F
      };
      books["978-1-119-07742-8"] = new Book() {
          ISBN="978-1-119-07742-8",
          Title="Beginning ASP.NET for Visual Studio 2015",
          Author="William Penberthy",
          Year=2016,
          Publisher="Wrox",
          Price=45.00F
      };

      var cart = new Cart<Book>();
      cart.Add(books["978-1-890-77495-0"],3);
      cart.Add(books["978-1-430-22611-6"]);
      cart.Add(books["978-1-119-07742-8"],2);
      cart.Del(books["978-1-119-07742-8"]);
      cart.Del(books["978-1-430-22611-6"]);
      Console.WriteLine("Types of books purchased:{0}",
        cart.CartItems.Count);
      Console.WriteLine("Total:{0:c}", cart.GandTotal);
      Console.ReadKey();
    }
  }
}

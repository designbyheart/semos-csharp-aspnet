﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0204 {
  internal class Book:Product {
    public string Title { get; set; }
    public string ISBN { get; set; }
    public string Author { get; set; }
    public int Year { get; set; }
    public string Publisher { get; set; }
    override public string Code {
      get {
        return ISBN;
      }
    }
  }
}

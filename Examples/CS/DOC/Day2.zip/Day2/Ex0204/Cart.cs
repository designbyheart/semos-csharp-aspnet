﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Ex0204 {
  internal class Cart<T> where T:Product {
    public List<CartItem<T>> CartItems = new List<CartItem<T>>();
    public float GandTotal {
      get {
        float total = 0;
        foreach (var ci in CartItems) total += ci.SubTotal;
        return total;
      }
    }
    public void Add(T product, uint n = 1) {
      var ci = this[product.Code];
      if (ci == null) CartItems.Add(new CartItem<T>(product, n));
      else ci.Add(n);
    }
    public bool Del(T product, uint n = 1) {
      var ci = this[product.Code];
      if(ci == null) return false;
      if (!ci.Del(n)) return false;
      if (ci.Quantity == 0) CartItems.Remove(ci);
      return true;
    }
    public CartItem<T> this[string code] {//Indexer
      get {
        foreach(var ci in CartItems) {
          if(ci.Item.Code.Equals(code)) return ci;
        }
        return null;
      }
    }
  }
}

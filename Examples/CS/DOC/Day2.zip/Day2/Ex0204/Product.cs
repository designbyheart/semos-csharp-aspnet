﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex0204 {
  internal abstract class Product {
    public abstract string Code { get; }
    public float Price;
  }
}

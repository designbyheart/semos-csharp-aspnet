﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;

using System.Data;
using System.Data.SqlClient;

using Ex0206.Models;

namespace Ex0206.Controllers {
  public class ServiceController : Controller {
    // GET: Service
    public ActionResult Index() {
      return View();
    }

    /// <summary>
    /// This method implements Euclean's Algorithm
    /// </summary>
    /// <param name="x">x must be >0</param>
    /// <param name="y">y must be >0</param>
    /// <returns>Greatest Common Divisor</returns>
    public long GCD(long x, long y) {
      while (y != 0) {
        var oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }

    public long LCM(long x, long y) {
      return (x * y) / GCD(x, y);
    }

    public string GCD2(long x, long y) {
      StringBuilder html = new StringBuilder("<table border='1'>");
      html.Append($"<tr><td>x</td><td>{x}</td></tr>");
      html.Append($"<tr><td>y</td><td>{y}</td></tr>");
      html.Append($"<tr><td>GCD(x,y)</td><td>{GCD(x, y)}</td></tr>");
      html.Append("</table>");
      return html.ToString();
    }

    public ActionResult GCD3(long x, long y) {
      ViewData["x"] = x;
      ViewData["y"] = y;
      ViewData["gcd"] = GCD(x, y);
      return View();
    }

    public ActionResult GCD4(long x, long y) {
      ViewBag.x = x;
      ViewBag.y = y;
      ViewBag.gcd = GCD(x, y);
      return View();
    }


    public ActionResult ShowList() {
      int[] data = { 1, 3, 6, 8, 9 };
      return View(data);
    }

    public ActionResult ShowBooks() {
      Book[] books = {
        new Book(){ 
          ISBN="11111",
          Title="C# is Fun",
          Author="Ali",
          Year=2022,
          Publisher="Wrox",
          Price=23.45F
        },
        new Book(){
          ISBN="22222",
          Title="Excel in Excel",
          Author="Peter",
          Year=2021,
          Publisher="XYZ",
          Price=22.22F
        },
        new Book(){
          ISBN="33333",
          Title="How to get rich in a week?",
          Author="C.K.Leng",
          Year=2023,
          Publisher="AAA",
          Price=999.99F
        },
      }; 
      return View(books);
    }

    public ActionResult ShowBooks2() {
      SqlConnection conn = new SqlConnection("Data Source=(local);Initial Catalog=MyDB;Integrated Security=True;");
      SqlCommand cmd = new SqlCommand("SELECT * FROM Book", conn);
      try {
        List<Book> books = new List<Book>();
        conn.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read()) {
          books.Add(
            new Book() { 
              ISBN = dr["ISBN"].ToString(),
              Title = dr["Title"].ToString(),
              Author = dr["Author"].ToString(),
              Publisher = dr["Publisher"].ToString(),
              Price = float.Parse(dr["Price"].ToString()),
              Year = int.Parse(dr["Year"].ToString())
            }
          );
        }
        dr.Close();
        return View(books);
      } catch (SqlException ex) {
      } finally {
        if ((conn != null) && (conn.State == ConnectionState.Open)) conn.Close();
      }
      return View("ShowBooks2Error");
    }
  }
}
﻿//#define USE_ARRAYLIST
using System;

namespace Ex0203 {
  internal class Program {
    static void Main(string[] args) {
#if USE_ARRAYLIST
      var data = new System.CollectionsArrayList(1000);
#else
      var data = new System.Collections.Generic.List<int>(1000);
#endif
      data.Add(3);
      data.Add(5);
      data.Add(7);
      data.Add(9);
#if USE_ARRAYLIST
      data.TrimToSize();
#else
      data.TrimExcess();
#endif
      data.Insert(0, 8);
      data.Insert(3, 99);
      data.RemoveAt(1);
      int total = 0;
      for(var i=0;i<data.Count;i++) {
        Console.WriteLine(data[i]);
#if USE_ARRAYLIST
        total += (int)data[i];
#else
        total += data[i];
#endif
      }
      Console.WriteLine("Total is {0}",total);
      Console.ReadKey();
    }
  }
}

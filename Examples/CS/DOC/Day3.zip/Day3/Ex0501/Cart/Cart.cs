﻿using System;
using System.Collections.Generic;


namespace Ex0501.Cart {
  public class Cart<T> where T : IProduct {
    public List<CartItem<T>> CartItems;
    public Cart() {
      CartItems = new List<CartItem<T>>();
    }
    public void Add(T product, uint n = 1) {
      var cartItem = CartItems.Find(
        ci => IProduct.ReferenceEquals(ci.Product, product));
      if (cartItem == null) CartItems.Add( new CartItem<T>(product, n));
      else cartItem.Add(n);
    }
    public bool Remove(T product, uint n = 1) {
      var cartItem = CartItems.Find(
        ci => IProduct.ReferenceEquals(ci.Product, product));
      if (cartItem != null) {
        if (cartItem.Remove(n)) {
          if (cartItem.Quantity == 0) CartItems.Remove(cartItem);
          return true;
        }
      }
      return false;
    }
    public float Total {
      get {
        float total = 0;
        CartItems.ForEach(ci => total += ci.SubTotal);
        return total;
      }
    }

    public void Clear() {
      CartItems.Clear();
    }
    public CartItem<T> this[string code] {
      get {
        return CartItems.Find(ci => ci.Product.Code.Equals(code));
      }
    }

    public bool IsEmpty {
      get {
        return CartItems.Count == 0;
      }
    }
  }
}
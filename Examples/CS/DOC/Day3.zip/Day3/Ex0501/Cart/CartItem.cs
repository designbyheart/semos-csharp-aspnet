﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ex0501.Cart {
  public class CartItem<T> where T : IProduct {
    public T Product;
    public uint Quantity;

    public CartItem(T product, uint n = 1) {
      Product = product;
      Quantity = n;
    }
    public float SubTotal {
      get {
        return Quantity * Product.Price;
      }
    }
    public void Add(uint n = 1) {
      Quantity += n;
    }
    public bool Remove(uint n = 1) {
      if (Quantity >= n) {
        Quantity -= n;
        return true;
      }
      return false;
    }
  }
}
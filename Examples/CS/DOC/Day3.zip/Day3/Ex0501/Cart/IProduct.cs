﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ex0501.Cart {
  public interface IProduct {
    string Code { get; }
    float Price { get; }
  }
}
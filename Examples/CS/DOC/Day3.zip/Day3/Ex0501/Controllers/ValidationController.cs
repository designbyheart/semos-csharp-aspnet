﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Ex0501.Models;

namespace Ex0501.Controllers {
  public class ValidationController : Controller {
    // GET: Validation
    public ActionResult Index() {
      return View(MyDB.Employees);
    }

    public ActionResult Edit(int eID) {
      Employee employee = MyDB.Employees.Find(e => e.EID == eID);
      return View(employee);
    }

    [HttpPost]
    public ActionResult Edit(Employee employee) {
      if (ModelState.IsValid) { //checking model state
        Employee emp = MyDB.Employees.Find(e => e.EID == employee.EID);
        if (emp != null) {
          //Method #1
          emp.EID = employee.EID;
          emp.EName = employee.EName;
          emp.Supervisor = employee.Supervisor;
          emp.Department = employee.Department;
          emp.Gender = employee.Gender;
          emp.DOB = employee.DOB;
          emp.Salary = employee.Salary;
          emp.HP = employee.HP;
          emp.EMail = employee.EMail;

          //Method #2
          //MyDB.Employees[MyDB.Employees.IndexOf(emp)] = employee;//Make sure no one refer to old object
          return RedirectToAction("Index");
        }
      }
      return View(employee);
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Ex0501.Models;
using Ex0501.Cart;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Ex0501.Controllers {
  public class BookstoreController : Controller {
    // GET: Bookstore
    public ActionResult Index() {
      return View(MyDB.Books.Values);
    }

    public ActionResult AddBook(string isbn) {
      var cart = (Cart<Book>)Session["cart"];
      cart.Add(MyDB.Books[isbn]);
      return RedirectToAction("Index", "Bookstore");
    }
    public ActionResult DelBook(string isbn) {
      var cart = (Cart<Book>)Session["cart"];
      cart.Remove(MyDB.Books[isbn]);
      return RedirectToAction("Index", "Bookstore");
    }
    public ActionResult ClearBook(string isbn) {
      var cart = (Cart<Book>)Session["cart"];
      cart.CartItems.Remove(cart[isbn]);
      return RedirectToAction("Index", "Bookstore");
    }
    public ActionResult Checkout() {
      var cart = (Cart<Book>)Session["cart"];
      return View(cart);
    }
    public ActionResult Payment() {
      string resultView = "";
      var cart = (Cart<Book>)Session["cart"];
      SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["MyDB"].ConnectionString);
      try {
        conn.Open();
        var trans = conn.BeginTransaction();
        SqlCommand cmd = new SqlCommand(
          @"UPDATE Book SET Inventory = Inventory - @quantity WHERE ISBN = @isbn", conn, trans);
        cmd.Parameters.Add("@quantity", SqlDbType.Int);
        cmd.Parameters.Add("@isbn", SqlDbType.VarChar, 15);
        try {
          foreach (var cartItem in cart.CartItems) {
            cmd.Parameters["@isbn"].Value = cartItem.Product.Code;
            cmd.Parameters["@quantity"].Value = cartItem.Quantity;
            cmd.ExecuteNonQuery();
          }
          trans.Commit();
          cart.Clear();
          resultView = "CheckoutSuccess";
        } catch (Exception) {
          trans.Rollback();
          resultView = "CheckoutInsufficientBook";
        }
      } catch (Exception) {
        resultView = "CheckoutDBError";
      } finally {
        if (conn.State == ConnectionState.Open) conn.Close();
      }
      return View(resultView);
    }
    public ActionResult ClearCart() {
      var cart = (Cart<Book>)Session["cart"];
      cart.Clear();
      return RedirectToAction("Index", "Bookstore");
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Ex0501.Models;
using System.Web.Caching;
using System.Data;

namespace ASP.NET_MVC.Controllers {
  public class CachingController : Controller {
    // GET: Caching
    public ActionResult Index() {
      return View();
    }

    [OutputCache(Duration = 10)]
    public ActionResult OutputCache() {
      return View(MyDB.Countries);
    }

    //[OutputCache(Duration = 10)]
    [ChildActionOnly]
    public string NoOfCountries() {
      return "No of countries is " + MyDB.Countries.Count.ToString() +
        " @ " + DateTime.Now.ToString("dd/MMM/yyyy hh:mm:ss");
    }

    [OutputCache(CacheProfile="Duration1")]
    public ActionResult CacheProfile() {
      return View();
    }

    public ActionResult CacheObject() {
      if (HttpRuntime.Cache["MyVar"] == null) {
        HttpRuntime.Cache.Add("MyVar", DateTime.Now, null,
          DateTime.Now.AddSeconds(10), Cache.NoSlidingExpiration,
          CacheItemPriority.Normal,null);
      }
      return View((DateTime)HttpRuntime.Cache["MyVar"]);
    }

    public ActionResult CacheObjectWithFileDependency() {
      string path = Server.MapPath(@"..\Data\Products.xml");
      if (HttpRuntime.Cache["Products"] == null) {
        DataSet ds = new DataSet();
        ds.ReadXml(path);
        var dt = DateTime.Now;
        ds.Tables[0].Rows.Add("Date Time",dt.ToString("dd/MMM/yyyy"),dt.ToString("hh:mm:ss"));

        HttpRuntime.Cache.Add("Products", ds, new CacheDependency(path),
          DateTime.Now.AddSeconds(30), Cache.NoSlidingExpiration,
          CacheItemPriority.Normal, null);
        ViewBag.DT = DateTime.Now;
      }

      ViewBag.Path = path;
      return View((DataSet)HttpRuntime.Cache["Products"]);
    }

  }
}


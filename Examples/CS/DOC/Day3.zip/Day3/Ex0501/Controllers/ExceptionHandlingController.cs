﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ex0501.Controllers {
  public class ExceptionHandlingController : Controller {
    // GET: ExceptionHandling
    public ActionResult Index() {
      return View();
    }

    public ActionResult NotHandle() {
      throw new Exception("Something went wrong!");
    }

    [HandleError]
    public ActionResult HandleException() {
      throw new Exception("Something went wrong!");
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ex0501.Models {
  public enum Gender {
    Male,
    Female,
    Others
  }
}
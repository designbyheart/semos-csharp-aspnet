﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;

namespace Ex0501.Models {
  public class Employee {
    [Required]
    public int EID { get; set; }

    [Required]
    [MaxLength(64, ErrorMessage = "Name Too Long")]
    public string EName { get; set; }

    [ValidSupervisor(ErrorMessage = "Supervisor not exist!")]
    public int? Supervisor { get; set; }

    public int? Department { get; set; }

    public string Gender { get; set; }

    //[DataType(DataType.Date)]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MMM/yyyy}")]
    [ValidDOB(ErrorMessage = "Invalid DOB")]
    public DateTime? DOB { get; set; }

    [Range(1200, 1_000_000, ErrorMessage = "Invalid Salary")]
    public float? Salary { get; set; }

    [DataType(DataType.PhoneNumber)]
    [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
    public string HP { get; set; }

    [EmailAddress(ErrorMessage = "Invalid Email Address")]
    public string EMail { get; set; }
  }

  sealed class ValidSupervisor : ValidationAttribute {
    public override bool IsValid(object value) {
      if (value == null) return true;
      try {
        int eid = int.Parse(value.ToString());
        return MyDB.Employees.Find(e => e.EID == eid) != null;
      } catch (Exception) {
      }
      return false;
    }
  }

  sealed class ValidDOB : ValidationAttribute {
    protected override ValidationResult IsValid(object value,
                                                ValidationContext validationContext) {
      if (value == null) return ValidationResult.Success;

      DateTime dt = Convert.ToDateTime(value);
      DateTime minDate = Convert.ToDateTime("25/Jan/1970");
      DateTime maxDate = DateTime.Now;

      return (dt > minDate && dt < maxDate) ? ValidationResult.Success :
        new ValidationResult(
          String.Format("DOB Should be between {0:d} & {1:d}!",
            minDate, maxDate));
    }
  }
}
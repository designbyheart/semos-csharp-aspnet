﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;

namespace Ex0501.Models {
  public class Student {
    public int StudentId { get; set; }
    [Display(Name = "Name")]
    public string StudentName { get; set; }
    public int Age { get; set; }
    public string Gender { get; set; }
    public bool isNewlyEnrolled { get; set; }
    public string Password { get; set; }
    public string Description { get; set; }
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MMM/yyyy}")]
    public DateTime DOB { get; set; }
  }
}
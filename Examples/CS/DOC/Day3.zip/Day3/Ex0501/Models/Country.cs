﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ex0501.Models {
  public class Country {
    public string Code { get; set; }
    public string Name { get; set; }
    public string Map { get; set; }
  }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Ex0501.Cart;

namespace Ex0501.Models {
  public class Book : IProduct {//POCO-Plain Old C# Object
    public string ISBN { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public string Publisher { get; set; }
    public int Year { get; set; }
    public float Price { get; set; }

    public Book(string isbn, string title, string author, string publisher, int? year, float? price) {
      ISBN = isbn;
      Title = title;
      Author = author;
      Publisher = publisher ?? String.Empty;
      Year = year ?? 0;
      Price = price ?? 0;
    }
    public Book() {//Parameterless constructor is need for Form entry and etc..
    }

    public string Code {
      get { return ISBN; }
    }
  }
}
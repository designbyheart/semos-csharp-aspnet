﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Globalization;

namespace Ex0501.Models {
  static class Utils {
    public static T? DbCast<T>(this object dbValue) where T : struct {
      if (dbValue == null) return null;
      if (dbValue is System.DBNull) return null;
      T? value = dbValue as T?;
      if (value != null) return value;
      var conv = dbValue as IConvertible;
      if (conv != null) {
        value = (T)conv.ToType(typeof(T), CultureInfo.InvariantCulture);
      }
      return value;
    }
  }
  static public class MyDB {
    static public Dictionary<string, Book> Books = new Dictionary<string, Book>();
    static public List<Employee> Employees = new List<Employee>();
    static public List<Country> Countries = new List<Country>();
    static public List<State> States = new List<State>();
    static MyDB() {//Class constructor
      SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["MyDB"].ConnectionString.ToString());
      SqlCommand cmd = new SqlCommand("SELECT * FROM Country", conn);
      try {
        conn.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read()) {
          Countries.Add(new Country() {
            Code = dr["Code"].ToString(),
            Name = dr["Name"].ToString(),
            Map = dr["Map"].ToString(),
          });
        }
        dr.Close();
        cmd = new SqlCommand("SELECT * FROM State", conn);
        dr = cmd.ExecuteReader();
        while (dr.Read()) {
          States.Add(new State() {
            ID = dr.GetInt32(0),
            Country = dr.GetString(1),
            Name = dr.GetString(2),
            LocalName = dr.GetString(3)
          });
        }
        dr.Close();
        cmd = new SqlCommand("SELECT * FROM Employee", conn);
        dr = cmd.ExecuteReader();
        while (dr.Read()) {
          Employees.Add(new Employee() {
            EID = dr.GetInt32(0),
            EName = dr.GetString(1),
            Supervisor = dr["Supervisor"].DbCast<int>(),
            Department = dr["Department"].DbCast<int>(),
            Gender = dr["Gender"].ToString(),
            DOB = dr["DOB"].DbCast<DateTime>(),
            Salary = dr["Salary"].DbCast<float>(),
            HP = dr["HP"].ToString(),
            EMail = dr["EMail"].ToString()
          });
        }
        dr.Close();
        cmd = new SqlCommand("SELECT * FROM Book", conn);
        dr = cmd.ExecuteReader();
        while (dr.Read()) {
          string isbn = dr.GetString(0);
          Books.Add(isbn, new Book(
              isbn,
              dr.GetString(1), //Title
              dr.GetString(2), //Author
              dr.IsDBNull(3) ? String.Empty : dr["Publisher"].ToString(),//Publisher
              dr.IsDBNull(4) ? 0 : int.Parse(dr["Year"].ToString()),    //Year
              dr.IsDBNull(5) ? 0 : float.Parse(dr["Price"].ToString())  //Price
            ));
        }
        dr.Close();
      } catch (Exception ex) {
        throw ex;
      } finally {
        if (conn.State == ConnectionState.Open) conn.Close();
      }
    }
    static public List<string> StateNamesByCountryName(string countryName, bool useLocalName = false) {
      SqlConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["MyDB"].ConnectionString);
      SqlCommand cmd = new SqlCommand("StateNamesByCountryName", conn);
      cmd.CommandType = CommandType.StoredProcedure;

      cmd.Parameters.Add("@countryName", SqlDbType.VarChar, 128);
      cmd.Parameters["@countryName"].Direction = ParameterDirection.Input;
      cmd.Parameters["@countryName"].Value = countryName;

      cmd.Parameters.Add("@useLocalName", SqlDbType.Bit);
      cmd.Parameters["@useLocalName"].Direction = ParameterDirection.Input;
      cmd.Parameters["@useLocalName"].Value = useLocalName;
      List<string> names = new List<string>();
      try {
        conn.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read()) {
          names.Add(dr.GetString(0));
        }
        dr.Close();
      } catch (Exception) {
      } finally {
        if (conn.State == ConnectionState.Open) conn.Close();
      }
      return names;
    }

  }
}
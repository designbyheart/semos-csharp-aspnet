﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using Ex0503.Models;

namespace Ex0503.Controllers {
  public class StateController : ApiController {
    // GET api/State
    MyDBEntities db = new MyDBEntities();
    public IEnumerable<State> Get() {
      foreach (var s in db.States) {
        yield return s;
      }
    }

    // GET api/State/5
    public State Get(int id) {
      return db.States.FirstOrDefault(s => s.ID == id);
    }

    // POST api/State
    //public void Post([FromBody] State state) {
    public void Post([FromUri] State state) {
      db.States.Add(state);
      db.SaveChanges();
    }

    // PUT api/State/5
    //public IHttpActionResult Put(int id, [FromUri] State state) {
    public IHttpActionResult Put(int id, [FromBody] State state) {
      var existingState = db.States.Where(s => s.ID == id).FirstOrDefault<State>();
      if (existingState != null) {
        if (state.Country != null) existingState.Country = state.Country;
        if (state.Name != null) existingState.Name = state.Name;
        if (state.LocalName != null) existingState.LocalName = state.LocalName;
        db.SaveChanges();
        return Ok();
      }
      return NotFound();
    }

    // DELETE api/State/5
    public IHttpActionResult Delete(int id) {
      var state = db.States.FirstOrDefault(s => s.ID == id);
      if (state == null) return NotFound();
      db.States.Remove(state);
      db.SaveChanges();
      return Ok();
    }
  }
}
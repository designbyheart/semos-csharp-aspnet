﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using Ex0502.Controllers;

namespace Ex0502Test {
  [TestClass]
  public class UTGCD {
    MathController math = new MathController();
 
    [TestMethod]
    public void GCD_60_96() {
      //Arrange
      ulong n = 60;
      ulong d = 96;
      ulong expected = 12;
      //Act
      ulong actual = math.GCD(n, d);
      //Assert
      Assert.AreEqual(actual, expected);
    }

    [TestMethod]
    public void GCD_48_120() {
      //Arrange
      ulong n = 48;
      ulong d = 120;
      ulong expected = 24;
      //Act
      ulong actual = math.GCD(n, d);
      //Assert
      Assert.AreEqual(actual, expected);
    }

    [TestMethod]
    public void GCD_7_11() {
      //Arrange
      ulong n = 7;
      ulong d = 11;
      ulong expected = 1;
      //Act
      ulong actual = math.GCD(n, d);
      //Assert
      Assert.AreEqual(actual, expected);
    }

    [TestMethod]
    public void GCD_11_7() {
      //Arrange
      ulong n = 11;
      ulong d = 7;
      ulong expected = 1;
      //Act
      ulong actual = math.GCD(n, d);
      //Assert
      Assert.AreEqual(actual, expected);
    }
  }
}

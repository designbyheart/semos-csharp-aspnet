﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using Ex0502.Controllers;

namespace Ex0502Test {
  [TestClass]
  public class UTLCM {
    MathController math = new MathController();

    [TestMethod]
    public void LCM_6_8() {
      //Arrange
      ulong x = 6;
      ulong y = 8;
      ulong expected = 24;
      //Act
      ulong actual = math.LCM(x,y);
      //Assert
      Assert.AreEqual(actual, expected);
    }
  }
}

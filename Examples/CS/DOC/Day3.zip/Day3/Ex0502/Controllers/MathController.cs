﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ex0502.Controllers {
  public class MathController : Controller {
    // GET: Math
    public ActionResult Index() {
      return View();
    }

    /// <summary>
    /// This method implements the Euclain's Algorithm
    /// </summary>
    /// <param name="x">Must be >0</param>
    /// <param name="y">Must be>0</param>
    /// <returns>The Greatest Common Divisor for x and y</returns>
    public ulong GCD(ulong x, ulong y) {
      while (y != 0) {
        ulong oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }

    public ulong LCM(ulong x, ulong y) {
      return (x * y) / GCD(x, y);
    }

    public double Average(params double[] values) {
      double total = 0;
      if (values != null) {
        foreach (var value in values) total += value;
        return total / values.Length;
      }
      return 0;
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ex0506 {
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {
    public MainWindow() {
      InitializeComponent();
    }
    static ulong GCD(ulong x, ulong y) {
      while (y != 0) {
        var oldX = x;
        x = y;
        y = oldX % y;
      }
      return x;
    }
    private void btnGO_Click(object sender, RoutedEventArgs e) {
      ulong x = ulong.Parse(tbX.Text);
      ulong y = ulong.Parse(tbY.Text);
      lblGCD.Content = GCD(x, y).ToString();
    }
  }
}

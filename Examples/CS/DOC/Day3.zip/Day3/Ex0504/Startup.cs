﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Ex0504.Startup))]
namespace Ex0504
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

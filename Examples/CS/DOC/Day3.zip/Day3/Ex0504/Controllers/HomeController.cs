﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ex504.Controllers {
  public class HomeController : Controller {
    public ActionResult Index() {
      return View();
    }

    public ActionResult Anonymous() {
      return View();
    }

    [Authorize]
    public ActionResult Secret() {
      return View();
    }

    [Authorize]
    public ActionResult AnotherSecret() {
      return View();
    }

    [Authorize(Users = "abu@abc.com")]
    public ActionResult AbuOnly() {
      return View();
    }

    [Authorize(Roles = "User")]
    public ActionResult UserPage() {
      return View();
    }

    [Authorize(Roles = "Administrator")]
    public ActionResult AdministratorPage() {
      return View();
    }

    [Authorize(Roles = "User,Administrator")]
    public ActionResult UserOrAdministratorPage() {
      return View();
    }

    [Authorize(Roles = "User")]
    [Authorize(Roles = "Administrator")]
    public ActionResult UserAndAdministratorPage() {
      return View();
    }

    public ActionResult About() {
      ViewBag.Message = "Your application description page.";

      return View();
    }

    public ActionResult Contact() {
      ViewBag.Message = "Your contact page.";

      return View();
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SgPetani;

namespace Ipoh{
  internal class AuntHouse:House{
    void Auntie() {
    }
  }
}

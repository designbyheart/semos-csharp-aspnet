﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SgPetani{
  public class House{
    class X{

    }
    //Bedroom
    private int Bed;
    private void Sister() {}

    //Dinning Room
    protected int Table;
    protected void Mother() { }

    //Garden
    public int Flower;
    public void Father() { }

    //Backyard
    internal int Bonsai;
    internal void Brother() { }

    //Home Theatre
    protected internal int OLEDTV;
    internal protected int BlurayPlayer;
  }
}
